const fs = require('fs');
const path = require('path');

function printTree(dir, prefix = '') {
    const files = fs.readdirSync(dir);
    
    files.forEach((file, index) => {
        // Explicitly ignore dependency and version control directories
        if (file === 'node_modules' || file === '.git') return;
        
        const filePath = path.join(dir, file);
        const stats = fs.statSync(filePath);
        const isLast = index === files.length - 1;
        const marker = isLast ? '└── ' : '├── ';
        
        console.log(`${prefix}${marker}${file}`);
        
        if (stats.isDirectory()) {
            const newPrefix = prefix + (isLast ? '    ' : '│   ');
            printTree(filePath, newPrefix);
        }
    });
}

console.log('.');
printTree(process.cwd());