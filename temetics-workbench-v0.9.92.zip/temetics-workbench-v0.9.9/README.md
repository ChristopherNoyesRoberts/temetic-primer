# Temetics Workbench — v0.9.9

This is the local, personal workbench — not the canonical Temetics repo.
Canon stays on GitHub. This is the founder's tool for turning raw R2
thinking into R3-tested candidates, batching them for Alliance parallax
review, and carrying what survives into local references or a public
Substack post.

**Read `AGENTS.md` for the actual rules.** This file is just orientation.

## What's here
00_Canon/         Read-only mirror of canonical docs (axioms, glossary)
01_Inbox/         Raw capture — anything, no structure required
02_Candidate/     Formal restatement + local gate, in progress
03_Promoted/      Cleared the local gate — holding stage, awaiting parallax
04_To_Parallax/   Outbound batch manifests, written by promoted-to-parallax.js
05_From_Parallax/ Inbound Alliance rfc_receipts, read by collate_parallax.js
06_References/    Local, parallax-approved working definitions — not the same as 07_Published
07_Published/     Actually pushed to Substack (external, real publication)
skills/           What the local agent can do — see _provenance.md
Templates/        Plain-markdown shapes for each stage, tool-agnostic
infra/            Local deterministic Controller and pipeline scripts
lexicons/         Mutable workspace lexicon accumulator (workspace-lexicon.json)

## v0.9.9 Controller

- `infra/inbox-to-candidate.js` runs as a hardened, background-aware daemon watching `01_Inbox/`.
- Copy `.env.example` to `.env` and configure your CORE_AGENT_* variables.
- The controller performs deterministic deduplication, enforces hyphen-case slugs, and routes to `02_Candidate/`.
- `infra/candidate-to-promoted.js` runs the exterior gate and moves cleared items into `03_Promoted/`.
- `infra/promoted-to-parallax.js` batches `awaiting_parallax: true` items from `03_Promoted/` into a manifest in `04_To_Parallax/`, applying the tiered blindness field-gating described in `AGENTS.md`.
- `infra/collate_parallax.js` reads receipts back from `05_From_Parallax/`, checks them against the Alliance allowlist and the originating manifest, and — once quorum's machine-approval half is met — prompts for founder sign-off before flipping `gate_status`.
- `infra/promote-to-references.js` moves `parallax_approved` items into `06_References/`.

## First-run checklist

1. Open this folder as an Obsidian vault. Confirm it opens clean — no errors, sidebar shows the folder tree above.
2. Open the *same* folder in VS Code. Run `npm install` if needed, then start the controller.
3. Copy `.env.example` to `.env` and fill in your CORE_AGENT_* values.
4. Drop a test `.md` file into `01_Inbox/` and watch it automatically process into `02_Candidate/`.
5. Verify the new note appears cleanly in Obsidian with proper frontmatter and wikilinks, and that `.obsidian/` remains untouched.
6. Confirm `00_Canon/` is never written to except via `refresh-canon`.
7. Run a candidate through to `03_Promoted/`, then run `promoted-to-parallax.js` to confirm a manifest lands cleanly in `04_To_Parallax/`.

If these hold, v0.9.9 is operational.

---
