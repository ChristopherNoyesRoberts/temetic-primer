# 03_Promoted

See `AGENTS.md` §4 for what a file landing here does and doesn't claim
(cleared the local gate vs. a P0 claim) — not restated here, so there's
only one copy of that rule to keep in sync.

CONTEXT — current scope, not a rule:
Landing here cleanly is a holding stage, not the finish line — it means a
file cleared the local gate (`candidate-to-promoted.js`) and is sitting
here with `gate_status: parallax_pending`, waiting to go out to the
Alliance. That next step is automated, not a manual paste into browser
tabs: `infra/promoted-to-parallax.js` batches items flagged
`awaiting_parallax: true` into a manifest written to `04_To_Parallax/`,
applying the tiered blindness field-gating (Tier 0–3, see `AGENTS.md`).
`infra/collate_parallax.js` then reads the Alliance's receipts back from
`05_From_Parallax/`, validates them, accumulates quorum signatures, and
prompts the founder for a manual sign-off before flipping `gate_status`
to `parallax_declined` or `parallax_approved`. An approved file is moved
out of here into `06_References/` by `infra/promote-to-references.js` —
this folder never keeps a retained copy of an approved item.

The one manual step left in this stage: per-item `founder_note` and any
batch-level `founder_directive`, entered inline when running
`promoted-to-parallax.js`. Everything downstream of that is scripted.

Substack adaptation (TT/AT/MMM voice) still happens by hand, later, and
only after a file has been through full parallax — see `07_Published/`.
