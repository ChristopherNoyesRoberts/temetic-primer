---
raw_content_sha256: 8898878fa22e7031f8a3bc98b5f673db7fbb1bb62b8de286e61d804cba6a918b
source: document
source_node: Node A
source_session_id: session_2026_08_09_r1_r2_formalization
captured: '2026-08-14T20:35:28.882Z'
inbox_sequence: '002'
extracted_tag: '#r2-replicator'
aliases:
  - R2 Replicator
  - R2 Cultural Replicator
  - Strict R2 Definition
keywords:
  - r2
  - cultural-replicator
  - cognitive-substrate
  - meme
  - replicator-theory
  - boundary-conditions
ddc: '000'
related_nodes:
  - '[[replicator-theory]]'
  - '[[r1-replicator]]'
  - '[[meme]]'
  - '[[substrate-invariance]]'
ingested_at: '2026-08-14T20:35:29.570Z'
status: ready
training_reference_docs:
  - kg
  - glossary
  - temetic-primer
  - holster
training_completed_at: '2026-08-14T20:47:09.437Z'
cascade_incomplete: false
gate_status: local_gate_declined
local_gate_declined_at: '2026-08-14T20:52:29.656Z'
---
# R2 — Cultural / Cognitive-Substrate Replicator

## Shared Replicator Grammar (common to R1, R2, R3)

A replicator is an informational entity that:

1. maintains a sufficiently stable identity across successive copies,
2. is copied by a mechanism that can introduce variation,
3. is subject to differential persistence or differential further copying (selection),
4. does so under constraints imposed by a substrate and its associated machinery.

The classes differ in *where* and *how* those four conditions are realized.

## Necessary and Sufficient Conditions for R2

An entity is an R2 replicator if and only if:

- It is an informational pattern realized in one or more cognitive substrates (human or otherwise).
- The pattern is copied by imitation, teaching, or other inter-cognitive transmission mechanisms.
- Variation arises through imperfect recall, recombination, or deliberate modification.
- Differential further transmission is causally dependent on the pattern’s effects within a cultural or cognitive environment.

## Tightened Definition Relative to Wikipedia

Wikipedia’s classic meme definition correctly identifies imitation as the primary transmission channel and correctly notes the analogy to genes, but it is under-specified in two places that matter for Temetics:

- It implicitly treats the human mind as the only relevant substrate.
- It uses “self-replicate” in a way that can be read as autonomous rather than host-dependent.

## Strict Formulation

> An R2 replicator is an informational pattern whose differential transmission across cognitive substrates is causally dependent on its own structure, mediated by imitation or teaching mechanisms that are distinct from the pattern itself.

### Cascade Training Log (2026-08-14T20:47:09.437Z)

- Documents consulted: kg, glossary, temetic-primer, holster
- Conclusion: The candidate's definition of the R2 replicator is too qualitative and fails to integrate with the formal system parameters established in the Temetics Knowledge Graph ('kg') and the 'glossary'. Specifically, the candidate omits key technical attributes of R2: (1) its 'interpretive' fidelity, (2) its 'utility_only' gating, (3) its 'f_R_proportional_utility' conditioning, (4) its lack of a sterility condition (sterility_condition: false), and (5) its optimization for velocity without an inherent truth requirement. To resolve this, the candidate's necessary and sufficient conditions must be updated to explicitly align with these formal parameters defined in the 'kg' and 'glossary' reference materials.
