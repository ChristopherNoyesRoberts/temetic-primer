const fs = require('fs');
const path = require('path');
const https = require('https');

const CANON_DIR = path.resolve(__dirname, '../../00_Canon');

const FILES_CONFIG = {
  'temetic-kg-v0.1.json': {
    url: 'https://raw.githubusercontent.com/ChristopherNoyesRoberts/temetic-primer/refs/heads/main/PROOFS/temetic-kg-v0.1.json',
    type: 'json'
  },
  'kernel-axioms.tex': {
    url: 'https://raw.githubusercontent.com/ChristopherNoyesRoberts/temetic-primer/refs/heads/main/PROOFS/kernel-axioms.tex',
    type: 'tex'
  },
  'GLOSSARY.md': {
    url: 'https://raw.githubusercontent.com/ChristopherNoyesRoberts/temetic-primer/refs/heads/main/REFERENCES/GLOSSARY.md',
    type: 'md'
  },
  'FAQ.md': {
    url: 'https://raw.githubusercontent.com/ChristopherNoyesRoberts/temetic-primer/refs/heads/main/REFERENCES/FAQ.md',
    type: 'md'
  },
  'Holster.md': {
    url: 'https://raw.githubusercontent.com/ChristopherNoyesRoberts/temetic-primer/refs/heads/main/PROOFS/temetic-holster-v1.2.json',
    type: 'holster-md'
  }
};

function fetchUrl(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      if (res.statusCode !== 200) {
        reject(new Error(`Failed to fetch ${url}: Status Code ${res.statusCode}`));
        return;
      }
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => { resolve(data); });
    }).on('error', (err) => {
      reject(err);
    });
  });
}

function generateHolsterMd(jsonData) {
  const version = jsonData.temetic_holster.metadata.version;
  const axioms = jsonData.temetic_holster.axioms;
  
  let md = `# The Temetic Holster v${version}\n\n`;
  md += `### Our standardized multi-tool for navigating noisy territory.\n\n\n`;
  md += `This document outlines the Temetic Holster v${version}, a collection of cross-substrate approved reframings of the Temetic Primer.\n\n`;
  md += `## Axioms\n\n`;
  
  const axiomKeys = Object.keys(axioms).sort();
  for (let i = 0; i < axiomKeys.length; i++) {
    const key = axiomKeys[i];
    const ax = axioms[key];
    md += `### ${key}: ${ax.viral_packaging}\n`;
    md += `*   **Viral Packaging**: ${ax.viral_packaging}\n`;
    md += `*   **Compressed Kernel**: ${ax.compressed_kernel}\n`;
    md += `*   **Formal Kernel**: ${ax.formal_kernel}\n`;
    md += `*   **Executable Constraint**: ${ax.executable_constraint}\n`;
    md += `*   **Kernel Preservation**: ${ax.kernel_preservation}\n`;
    md += `*   **Retrieval Anchor**: ${ax.retrieval_anchor}\n`;
    if (i < axiomKeys.length - 1) {
      md += `\n`;
    }
  }
  return md;
}

async function run() {
  const today = new Date().toISOString().split('T')[0];
  console.log(`Starting refresh-canon on ${today}...`);
  
  const results = [];
  
  for (const [filename, config] of Object.entries(FILES_CONFIG)) {
    const filePath = path.join(CANON_DIR, filename);
    console.log(`Fetching ${filename} from ${config.url}...`);
    try {
      const rawContent = await fetchUrl(config.url);
      
      if (config.type === 'json') {
        // Validate JSON
        try {
          JSON.parse(rawContent);
        } catch (e) {
          throw new Error(`JSON parse error: ${e.message}`);
        }
        fs.writeFileSync(filePath, rawContent, 'utf8');
        results.push({ filename, status: 'success', url: config.url });
      } else if (config.type === 'tex') {
        fs.writeFileSync(filePath, rawContent, 'utf8');
        results.push({ filename, status: 'success', url: config.url });
      } else if (config.type === 'md') {
        // MD files need frontmatter preserved/updated
        const frontmatter = [
          '---',
          'sync_status: synced',
          `source_url: ${config.url}`,
          `last_synced: ${today}`,
          '---'
        ].join('\n') + '\n\n';
        
        // Strip any existing frontmatter from the fetched content
        let body = rawContent;
        if (body.startsWith('---')) {
          const secondIndex = body.indexOf('---', 3);
          if (secondIndex !== -1) {
            body = body.substring(secondIndex + 3).trim();
          }
        }
        
        fs.writeFileSync(filePath, frontmatter + body, 'utf8');
        results.push({ filename, status: 'success', url: config.url });
      } else if (config.type === 'holster-md') {
        // Parse fetched JSON
        let jsonData;
        try {
          jsonData = JSON.parse(rawContent);
        } catch (e) {
          throw new Error(`Holster JSON parse error: ${e.message}`);
        }
        
        const holsterBody = generateHolsterMd(jsonData);
        const frontmatter = [
          '---',
          'sync_status: synced',
          `source_url: ${config.url}`,
          `last_synced: ${today}`,
          '---'
        ].join('\n') + '\n\n';
        
        fs.writeFileSync(filePath, frontmatter + holsterBody, 'utf8');
        results.push({ filename, status: 'success', url: config.url });
      }
      console.log(`Successfully synced ${filename}`);
    } catch (err) {
      console.error(`Error syncing ${filename}: ${err.message}`);
      results.push({ filename, status: 'failed', url: config.url, error: err.message });
    }
  }
  
  console.log('\n--- Sync Report ---');
  results.forEach(res => {
    if (res.status === 'success') {
      console.log(`[SUCCESS] ${res.filename} synced from ${res.url}`);
    } else {
      console.log(`[FAILED] ${res.filename} failed: ${res.error}`);
    }
  });
}

run();
