---
name: refresh-canon
description: Pulls the canonical Temetics documents from their public GitHub/Substack source URLs and overwrites the local read-only mirror in 00_Canon/. One-directional only — never writes back upstream, never edits 00_Canon/ from any other context. Use when the founder asks to sync, refresh, or update the canon mirror, or when a 00_Canon/ file's sync_status is not_yet_synced and a real source_url has been provided.
---

# Refresh Canon

## Overview

`00_Canon/` exists so the local agent always has a cheap, local copy of
the canonical Temetics documents without re-fetching them on every
check. This skill is the *only* thing in this repository permitted to
write into that folder. Its job is narrow on purpose.

## Important

BEFORE EXECUTING ANY STEP IN THIS SKILL:
Re-read this file from disk at its current path to ensure you are working from the latest version, not a cached copy from earlier in this session.

## Workflow

1. For each file in `00_Canon/` that has a `source_url` set in its
   frontmatter (or a known URL, for files like `temetic-kg-v0.1.json`
   that don't carry frontmatter — keep the known URL list below current):
   - Fetch the current content from that URL.
   - Overwrite the local file with the fetched content exactly.
   - If the file is markdown with a `sync_status` frontmatter field,
     update it to `synced` and set `last_synced` to the current date.
   - If the file is JSON, validate it parses before overwriting the
     local copy — never leave `00_Canon/` in a broken-JSON state.
2. Report back to the founder what was pulled and from where, including
   anything that failed (404, parse error) rather than silently skipping
   it.
3. **Never** write to any source outside `00_Canon/`, and never push
   anything from `00_Canon/` back upstream. This skill has no concept
   of "upload" — only "download and overwrite locally."

## Known source URLs (keep current)

- `temetic-kg-v0.1.json` — `https://raw.githubusercontent.com/ChristopherNoyesRoberts/temetic-primer/refs/heads/main/PROOFS/temetic-kg-v0.1.json`
- `kernel-axioms.tex` — `https://raw.githubusercontent.com/ChristopherNoyesRoberts/temetic-primer/refs/heads/main/PROOFS/kernel-axioms.tex`
- `GLOSSARY.md` — `https://raw.githubusercontent.com/ChristopherNoyesRoberts/temetic-primer/refs/heads/main/REFERENCES/GLOSSARY.md`
- `FAQ.md` — `https://raw.githubusercontent.com/ChristopherNoyesRoberts/temetic-primer/refs/heads/main/REFERENCES/FAQ.md`
- `Holster.md` — `https://raw.githubusercontent.com/ChristopherNoyesRoberts/temetic-primer/refs/heads/main/PROOFS/temetic-holster-v1.2.json`

 Fill in
  `source_url` in each file's own frontmatter once known.

## Constraints

- Read-only with respect to everything except `00_Canon/`.
- Idempotent — running it twice in a row with nothing changed upstream
  should produce no diff.
- If a URL 404s or returns something that doesn't parse, leave the
  existing local file untouched and report the failure clearly — do not
  overwrite good content with a failed fetch.
