---
name: strip-vendor-terms
description: Scans an imported skill's SKILL.md (and any referenced scripts) for vendor-coded executor references — "Claude," "GPT," "ChatGPT," "Gemini," "Copilot," or any other model/product name used as the thing doing the work — and replaces them with "the local agent." Leaves an audit trail of what was changed so the strip is reviewable and reversible. Use when importing a third-party skill, or when a skill in this repository still names a specific vendor as its executor.
---

# Strip Vendor Terms

## Overview

Community skills are routinely written assuming a specific product is
running them. That assumption doesn't survive a repo meant to be
substrate-agnostic. This skill's only job is removing it, mechanically,
without changing what the skill actually does.

## Workflow

1. Read the target skill's `SKILL.md` (and any `.py`/`.js`/etc files it
   references) in full before changing anything.
2. Identify every place a specific vendor/model/product name is used as
   **the executor of the skill's actions** — e.g. "Claude processes the
   input," "Configures Claude to act as...," "Gemini analyzes the note."
   This is different from a vendor name appearing as factual content
   (e.g. a note *about* Claude, or a glossary entry mentioning GPT) —
   only strip executor references, never factual ones.
3. Replace each executor reference with **"the local agent."** Keep the
   surrounding sentence grammatically intact — don't just find-and-replace
   the word in isolation if it breaks the sentence.
4. Write a short changelog block at the bottom of the modified `SKILL.md`
   (or a sibling `STRIP-LOG.md` if the file format doesn't support
   trailing notes cleanly) listing every replacement made, with enough
   context that the original could be reconstructed if someone disagreed
   with a specific change later.
5. Update the skill's row in `skills/_provenance.md`: provenance from
   `imported` to `stripped`.

## Constraints

- Mechanical and conservative. If it's ambiguous whether a name is being
  used as the executor or as factual content, leave it and flag it to
  the founder rather than guessing.
- Never touch the skill's actual logic, workflow steps, or output format
  — only the executor-naming language.
- Always produces an audit trail. A strip with no record of what changed
  is not a complete run of this skill.
