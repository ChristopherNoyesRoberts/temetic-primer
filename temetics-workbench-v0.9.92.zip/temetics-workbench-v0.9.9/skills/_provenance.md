# skills/_provenance.md

Every skill in this repository — native or imported — gets an entry here.
A skill not listed here should not be treated as trusted, regardless of
where it physically sits. Schema per Manifesto v4.0 §8, shared with
`infra/_provenance.md`.

| Skill | Provenance | Write-scope | Deterministic | Idempotent | Side-effect-free | Requires-interpretation | Authority-level | Source |
|---|---|---|---|---|---|---|---|---|
| `refresh-canon` | native | `00_Canon/` only | Yes | Yes (own claim, matches mechanical fetch-and-overwrite behavior) | **No** — fetches from external GitHub URLs on every run (network call); within-scope writes are fine, the network call is the flagged item | false | Autonomous within scope, but only ever touches a file that already has a real `source_url` set — never invents one | this build |
| `strip-vendor-terms` | native | the target skill's own folder only | No | Yes (converges — a second run on an already-stripped skill finds nothing left to strip) | Yes, within declared scope | **true** — explicitly judgment-dependent (disambiguating executor-reference vs. factual mention); the skill's own text says to flag ambiguous cases to the founder rather than guess | Sign-off required before overwriting an existing skill in place; autonomous on a fresh import | this build |

## Fields, defined

- **Provenance** — `native` (written generic for this repo from line
  one), `imported` (pulled from a public skill set, vendor-coded
  language not yet checked), or `stripped` (was imported, has been run
  through `strip-vendor-terms`, vendor language removed).
- **Write-scope** — the exact folder(s) a skill may write to. A skill
  attempting to write outside its declared scope should be stopped and
  flagged to the founder, not silently allowed.
- **Deterministic** — does this produce the same output every time given
  the same input, with no interpretation involved?
- **Idempotent** — can this be safely re-run on the same input without
  changing the outcome? Note: for a *capture*-type action, "safe to
  re-run" and "produces a new artifact each time" are not in tension —
  idempotent here describes whether a duplicate/repeat *event* is a
  no-op, not whether every invocation is one.
- **Side-effect-free** — does this perform any observable I/O or state
  mutation outside its declared write-scope (network calls, spawning
  child processes, writing to a path not listed)? Staying inside the
  declared boundary is what this tracks, not absolute functional purity.
- **Requires-interpretation** — does this task inherently require
  judgment-dependent evaluation, or could an equivalent deterministic
  implementation exist? Describes the nature of the task, not the
  current implementation.
- **Authority-level** — what can this act on without further
  confirmation, and what needs founder or Alliance sign-off first? Does
  not imply epistemic authority over what the files it touches claim —
  operational authority only.
- **Source** — for `imported` skills, the URL/attribution of where it
  came from. Required before the skill is used, not after.

## When you import a new skill

1. Drop it into `skills/<skill-name>/`.
2. Add a row here immediately: provenance `imported`, write-scope set
   conservatively (narrower than you think it needs, widen later if
   genuinely necessary), source URL filled in, and an honest first pass
   at all five behavioral properties — a guess flagged as a guess beats
   a confident-looking blank.
3. It's usable right away — importing doesn't require cleaning first.
4. Run `strip-vendor-terms` against it before relying on it long-term,
   then flip provenance to `stripped` here.
