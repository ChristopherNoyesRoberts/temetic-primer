# 02_Candidate

## What this folder is

A note lands here from `01_Inbox/` once someone — founder or the local
agent — attempts a formal/Boolean restatement of it. While a file sits
here, it is **work in progress, not a claim.** Nothing here has cleared
anything yet unless its own status field says so explicitly.

---

## The one and only procedure

**The full Candidate procedure lives at `Templates/candidate.md`. That
file, and only that file, is authoritative.**

RULE — TEMPLATE SOURCE (no exceptions):
    before processing any Candidate file, open and read
    Templates/candidate.md directly
    do not infer the procedure's structure from any existing file
    already sitting in 02_Candidate/, including anything that looks
    like a template, a test fixture, or a prior example
    structural resemblance to an old file in this folder is not
    evidence that it's the correct pattern to follow

CONTEXT — not an additional rule, explains why the RULE above is
non-negotiable:
This has caused a real failure before: an agent pattern-matched on a
leftover test stub instead of the actual template, and produced two
malformed Candidate files as a result. Don't repeat it.

---

## What a complete Candidate file must contain

At minimum, per `Templates/candidate.md`:

1. **The raw claim, untouched** — copied verbatim from its Inbox source.
   Nothing rephrased, nothing corrected, nothing dropped.

2. **Formal / Boolean restatement** — the claim restated as precisely as
   possible, in the fewest words that preserve its full original
   meaning. This step genuinely requires judgment — it is not
   mechanizable, and no amount of tightening this document will make
   it so. If the raw claim is ambiguous, the restatement must say so
   explicitly rather than silently resolving it in one direction.

3. **Round-trip check (S1_verification)** — take the formal restatement
   from step 2 and, independently, translate it back into plain
   language, as if explaining it to someone with zero prior context.
   Compare that reverse-translation against the *original raw claim*
   from step 1 — not against the formal restatement. Record any
   divergence explicitly. A round-trip that reports "zero divergence"
   without showing the comparison is not trustworthy on its own — the
   comparison itself should be visible in the output.

4. **P0–P6 axiom scan** — evaluate the formal restatement against
   `00_Canon/temetic-kg-v0.1.json` (canon reference order: check this
   file first; escalate to `kernel-axioms.tex` only for symbolic-logic-
   level questions the JSON can't resolve). This step must show its
   work — which specific fields were checked and what the result was —
   not just assert "axioms checked." At minimum, explicitly evaluate:
   - `sterility_condition`
   - `fidelity_threshold`

   If the P6 stabilizers are relevant to the claim, reference them by
   their exact names only, never paraphrased:
   - `S1_verification`
   - `S2_reversible`
   - `S3_independent`

5. **A status field** reflecting current state — `candidate` until
   every check above has actually passed, not merely been attempted.

---

## Interior vs. Exterior — do not conflate these

- **Interior mode** — the same procedure can be run against any note,
  at any time, purely for feedback. It is optional and it never blocks
  anything or changes a file's status.

- **Exterior mode** — mandatory before any file moves from
  `02_Candidate/` to `03_Promoted/`. It must produce an explicit
  pass/fail result.

RULE — GATE LANGUAGE: see `AGENTS.md` §4 for the exact rule (permitted
and forbidden terms for a file that cleared the Exterior gate). Do not
restate it here — a second copy of the same rule is how it drifts out
of sync with the first one. If this section and AGENTS.md §4 ever
disagree, AGENTS.md is correct and this line is stale — flag it.

CONTEXT — not an additional rule:
A file that passes the exterior gate has demonstrated local coherence
only — internal consistency, checked on this machine, by this agent.
It has not demonstrated P0. True substrate-independent verification
only happens once the file reaches independent Alliance nodes, outside
this local session, with no shared context. This distinction has
drifted before, in an earlier version of a governance file — that's
the entire reason it now lives in exactly one place (AGENTS.md §4)
instead of being restated here.

---

## Failure handling

RULE — FAILED AXIOM SCAN (no exceptions):
    do not quietly correct, soften, delete, or rewrite a claim that
    fails the axiom scan into something that would pass
    label it explicitly: "Synthetically Probable but Temetically
    Invalid"
    state which axiom or field it failed, and why
    leave the file in place in 02_Candidate/ (or return it to
    01_Inbox/ — founder's call), with the failure reasoning attached

CONTEXT — not an additional rule:
A failed file that quietly disappears or gets rewritten into a passing
one is a worse outcome than a failed file that stays visibly failed.

---

## What this README is not

CONTEXT — this whole section is non-normative, reference material only:
This README describes the procedure; it does not execute it and is not
itself subject to it. It carries no vendor or model name (per
`AGENTS.md`) and it is reference material — read once when needed, safe
to drop from working context afterward. The living, authoritative
procedure is always `Templates/candidate.md`, not this description of
it. If the two ever disagree, `Templates/candidate.md` is correct and
this file is stale — flag it.
