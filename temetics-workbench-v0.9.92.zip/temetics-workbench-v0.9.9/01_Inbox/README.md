# 01_Inbox

Format: `[source]-YYMMDD-###-[content_slug].md`

- **[source]**: open-ended label for where the item came from (`wikilink`, `nugget`,
  more to come as new capture paths get added — e.g. desktop vs. phone).
  Lowercase, alphanumeric only.
- **YYMMDD**: capture date.
- **###**: zero-padded daily sequence number (001, 002, ...), assigned at
  capture time. This is what makes same-day items sortable by order of
  ingestion even when there are dozens of them.
- **[content_slug]**: first 3-5 unique *content* words of the payload
  (stopwords filtered), lowercased and hyphenated.

Use `infra/capture-inbox-item.js` to write a new item — it assigns the next
free sequence number for today and derives the slug automatically:

```
node infra/capture-inbox-item.js --source voice "raw payload text..."
```

**Inbox files contain the raw payload and nothing else — no frontmatter,
ever.** All capture metadata (source, date, sequence) lives in the filename
now, not in the file body. `inbox-to-candidate.js` parses it from there and
appends it to the candidate's frontmatter downstream.

A file that doesn't match this naming convention gets quarantined by
`inbox-to-candidate.js` — logged clearly and left in place, untouched, rather
than silently processed. If you see a `*.quarantined.log` sitting next to a
file, that's why.

Raw capture. No structure required, no judgment applied here.

Anything goes: voice dumps (including transcription artifacts — don't clean
those up at this stage, that's a Candidate-stage job), partial thoughts, chat
exports, a single sentence. The only job of a file in this folder is to exist
and be findable later.

New thinking — including the founder's own new theoretical extensions —
always enters here first, even if it feels obviously correct in the
moment. It does not get written directly into `00_Canon/` or treated as
settled until it has gone through `02_Candidate/`.
