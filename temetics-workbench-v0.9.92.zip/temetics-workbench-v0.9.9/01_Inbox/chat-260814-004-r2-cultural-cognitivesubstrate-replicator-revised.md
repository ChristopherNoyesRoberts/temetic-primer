---
source: chat
source_node: Node M
captured: '2026-08-14T22:45:58.085Z'
---
# R2 — Cultural / Cognitive-Substrate Replicator (Revised, glossed)

## Shared Replicator Grammar (common to R1, R2, R3)

A replicator is an informational entity that:

1. maintains a sufficiently stable identity across successive copies,
2. is copied by a mechanism that can introduce variation,
3. is subject to differential persistence or differential further copying (selection),
4. does so under constraints imposed by a substrate and its associated machinery.

The classes differ in *where* and *how* those four conditions are realized.

## Necessary and Sufficient Conditions for R2

An entity is an R2 replicator if and only if:

- It is an informational pattern realized in one or more cognitive substrates (human or otherwise).
- The pattern is copied by imitation, teaching, or other inter-cognitive transmission mechanisms distinct from the pattern itself.
- Variation arises through imperfect recall, recombination, or deliberate modification.
- Differential further transmission is causally dependent on the pattern's effects within a cultural or cognitive environment.
- Its transmission fidelity is **interpretive**, not mechanical: what persists across copies is the pattern's effect or meaning as reconstructed by the receiving substrate, not an exact token-for-token replica. This is the R2 analog of R1's copying-fidelity condition, but enforced by shared interpretive convention rather than by dedicated molecular machinery independent of what the sequence "means."
- Selection is gated on **utility alone**: whether a copy persists and propagates further depends only on its usefulness — functional, social, emotional, or otherwise — to the substrates carrying it, with no independent correspondence-to-fact requirement built into the gate.
- The rate at which a variant is further copied is **proportional to the utility it currently confers**: more-useful variants aren't merely favored at a fixed threshold, their copying rate tracks realized utility continuously.
- It carries **no sterility condition**: canon defines a sterility condition as a binary correspondence gate that can zero out a copy's fitness outright — R3's version assigns zero fitness to any copy that fails to resolve against a grounding referent. R2 has no such gate: every successfully interpreted copy retains non-zero fitness regardless of whether it corresponds to anything true, and is only up- or down-weighted by utility.
- Taken together, R2 is optimized for transmission velocity, not truth-preservation: a false or distorted pattern that is more useful in the above sense will out-propagate a true one, with nothing in the replication mechanism itself correcting for that.

## Tightened Definition Relative to the Standard "Meme" Concept

The informal meme concept correctly identifies imitation as a transmission channel and the analogy to genetic replication, but under-specifies two things that matter for R2's boundary conditions:

- It implicitly treats the human mind as the only relevant substrate, rather than any cognitive substrate meeting the conditions above.
- It is silent on *why* memes drift toward virality over accuracy — R2's utility-only gating and utility-proportional conditioning make that drift a structural consequence of the definition rather than an observed tendency bolted on afterward.

## Strict Formulation

> An R2 replicator is an informational pattern realized in one or more cognitive substrates whose differential transmission is governed by interpretive fidelity (the element that persists across copies is reconstructed meaning or effect, not exact duplication), utility-only gating (further propagation depends solely on usefulness to the substrates carrying it, with no independent truth requirement), and utility-proportional conditioning (copying rate scales continuously with realized utility rather than a fixed threshold). It carries no sterility condition — unlike R3, where a copy that fails to resolve against a grounding referent is assigned zero fitness outright, no R2 copy is zeroed out for lacking correspondence, only up- or down-weighted by utility — and it is accordingly optimized for transmission velocity rather than veridical correspondence. Copying occurs via imitation, teaching, or other inter-cognitive mechanisms distinct from the pattern itself; variation arises through imperfect recall, recombination, or deliberate modification; and further transmission is causally dependent on the pattern's effects within a cultural or cognitive environment.

## Terminology cross-reference (for kg/glossary alignment)

Plain-language gloss aboveFormal designation used in prior candidatesinterpretive fidelity`interpretive` fidelityutility-only gating`gating: utility_only`utility-proportional conditioning`f_R_proportional_utility`no sterility condition`sterility_condition: false`

*Verification note: checked against temetic-kg v0.1, GLOSSARY.md, TEMETIC_PRIMER.md, and REPLICATOR_STABILITY.md. All four parameter values above (fidelity: interpretive, gating: utility_only, conditioning: f_R_proportional_utility, sterility_condition: false) match the R2 entity definition in kg exactly. The glossary itself doesn't define these field names as prose entries — the sterility_condition gloss was tightened using R3's contrasting sterility_condition: true and Replicator Stability's Lemma 3, since that's the only place canon spells out what a sterility condition actually does.*
