---
source: document
source_node: Node A
source_session_id: session_2026_08_14_r2_revision
captured: '2026-08-14T21:11:00Z'
extracted_tag: '#r2-replicator'
aliases:
  - R2 Cultural Replicator
  - Strict R2 Definition (v2)
keywords:
  - r2
  - cultural-replicator
  - cognitive-substrate
  - meme
  - replicator-theory
  - boundary-conditions
  - interpretive-fidelity
  - utility-only
  - sterility-condition
related_nodes:
  - '[[replicator-theory]]'
  - '[[r1-replicator]]'
  - '[[meme]]'
  - '[[substrate-invariance]]'
  - '[[glossary]]'
  - '[[kg]]'
---
# R2 — Cultural / Cognitive-Substrate Replicator (Revised)

## Shared Replicator Grammar (common to R1, R2, R3)

A replicator is an informational entity that:

1. maintains a sufficiently stable identity across successive copies,
2. is copied by a mechanism that can introduce variation,
3. is subject to differential persistence or differential further copying (selection),
4. does so under constraints imposed by a substrate and its associated machinery.

The classes differ in *where* and *how* those four conditions are realized.

## Necessary and Sufficient Conditions for R2

An entity is an R2 replicator if and only if:

- It is an informational pattern realized in one or more cognitive substrates (human or otherwise).
- The pattern is copied by imitation, teaching, or other inter-cognitive transmission mechanisms distinct from the pattern itself.
- Variation arises through imperfect recall, recombination, or deliberate modification.
- Differential further transmission is causally dependent on the pattern’s effects within a cultural or cognitive environment.
- Transmission is governed by **interpretive fidelity**.
- Gating is **utility_only**.
- Conditioning follows **f_R_proportional_utility**.
- It carries **sterility_condition: false**.
- It is optimized for transmission velocity without an inherent truth requirement.

## Strict Formulation

> An R2 replicator is an informational pattern realized in cognitive substrates whose differential transmission is governed by interpretive fidelity, utility-only gating, and f_R-proportional utility conditioning; it lacks a sterility condition (sterility_condition: false) and is optimized for transmission velocity without an inherent truth requirement. Copying occurs via imitation, teaching, or other inter-cognitive mechanisms distinct from the pattern itself; variation arises through imperfect recall, recombination, or deliberate modification; and further transmission is causally dependent on the pattern’s effects within a cultural or cognitive environment.
