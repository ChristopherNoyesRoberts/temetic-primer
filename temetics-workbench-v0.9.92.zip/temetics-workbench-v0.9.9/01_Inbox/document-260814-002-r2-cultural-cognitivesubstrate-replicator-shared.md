---
source: document
source_node: Node A
captured: '2026-08-14T20:35:28.882Z'
source_session_id: session_2026_08_09_r1_r2_formalization
extracted_tag: '#r2-replicator'
aliases:
  - R2 Cultural Replicator
  - Strict R2 Definition
keywords:
  - r2
  - cultural-replicator
  - cognitive-substrate
  - meme
  - replicator-theory
  - boundary-conditions
related_nodes:
  - '[[replicator-theory]]'
  - '[[r1-replicator]]'
  - '[[meme]]'
  - '[[substrate-invariance]]'
---
# R2 — Cultural / Cognitive-Substrate Replicator

## Shared Replicator Grammar (common to R1, R2, R3)

A replicator is an informational entity that:

1. maintains a sufficiently stable identity across successive copies,
2. is copied by a mechanism that can introduce variation,
3. is subject to differential persistence or differential further copying (selection),
4. does so under constraints imposed by a substrate and its associated machinery.

The classes differ in *where* and *how* those four conditions are realized.

## Necessary and Sufficient Conditions for R2

An entity is an R2 replicator if and only if:

- It is an informational pattern realized in one or more cognitive substrates (human or otherwise).
- The pattern is copied by imitation, teaching, or other inter-cognitive transmission mechanisms.
- Variation arises through imperfect recall, recombination, or deliberate modification.
- Differential further transmission is causally dependent on the pattern’s effects within a cultural or cognitive environment.

## Tightened Definition Relative to Wikipedia

Wikipedia’s classic meme definition correctly identifies imitation as the primary transmission channel and correctly notes the analogy to genes, but it is under-specified in two places that matter for Temetics:

- It implicitly treats the human mind as the only relevant substrate.
- It uses “self-replicate” in a way that can be read as autonomous rather than host-dependent.

## Strict Formulation

> An R2 replicator is an informational pattern whose differential transmission across cognitive substrates is causally dependent on its own structure, mediated by imitation or teaching mechanisms that are distinct from the pattern itself.
