---
raw_content_sha256: 18311ae9c7fc77403125730a08b694067f8e4e39d83e157e28997a074f795cb9
source: document
source_node: Node A
source_session_id: session_2026_08_09_r1_r2_formalization
captured: '2026-08-14T20:16:00Z'
inbox_sequence: '001'
extracted_tag: '#r1-replicator'
aliases:
  - R1 Replicator
  - R1 Biological Replicator
  - Strict R1 Definition
keywords:
  - r1
  - biological-replicator
  - physical-substrate
  - gene
  - replicator-theory
  - boundary-conditions
ddc: '000'
related_nodes:
  - '[[replicator-theory]]'
  - '[[r2-replicator]]'
  - '[[gene]]'
  - '[[substrate-invariance]]'
ingested_at: '2026-08-14T20:28:10.546Z'
training_reference_docs:
  - kg
  - glossary
  - gene
training_completed_at: '2026-08-14T20:45:05.490Z'
cascade_incomplete: false
gate_status: parallax_approved
promoted_at: '2026-08-14T20:52:17.696Z'
awaiting_parallax: false
founder_note: ''
verification_receipt:
  status: CONSISTENT
  referenced_rules:
    - P0
  evaluated_rules:
    - P0
  evidence:
    - candidate_quote: >-
        It is a discrete informational sequence (or set of sequences) realized
        in a physical molecular substrate.
      kernel_rule: P0
      reasoning: >-
        This maps the physical molecular substrate of the R1 replicator to the
        substrate entity 'M' in the P0 invariance rule, while treating the
        sequence as the informational entity [cite: glossary].
      confidence: 0.9
    - candidate_quote: >-
        It does not explicitly separate the informational identity from the
        physical substrate and the copying machinery.
      kernel_rule: P0
      reasoning: >-
        This critique of the standard biological definition aligns with the P0
        invariance rule, which formally separates the informational identity
        (the expression of abstract 'I') from the physical substrate 'M' via the
        independence operator [cite: gene].
      confidence: 0.95
  supported_mapping: >-
    The candidate's definition of an R1 replicator as an informational sequence
    realized in a physical molecular substrate, distinct from its copying
    machinery, maps directly to the P0 invariance rule where the informational
    identity is independent of the substrate M.
  citation_check:
    cited:
      - glossary
      - gene
    unverified: []
    verified: true
  kernel_projection: >-
    An R1 replicator is a physical-substrate instantiation of a lossless kernel
    whose replication and persistence are constrained by, yet informationally
    independent of, its molecular substrate and copying machinery.
parallax_approved_at: '2026-08-14T21:44:00.276Z'
---
# R1 — Biological / Physical-Substrate Replicator

## Shared Replicator Grammar (common to R1, R2, R3)

A replicator is an informational entity that:

1. maintains a sufficiently stable identity across successive copies,
2. is copied by a mechanism that can introduce variation,
3. is subject to differential persistence or differential further copying (selection),
4. does so under constraints imposed by a substrate and its associated machinery.

The classes differ in *where* and *how* those four conditions are realized.

## Necessary and Sufficient Conditions for R1

An entity is an R1 replicator if and only if:

- It is a discrete informational sequence (or set of sequences) realized in a physical molecular substrate.
- The substrate itself is capable of being copied by molecular machinery that is not identical to the sequence.
- Copying fidelity is high enough that the informational identity persists across generations, yet low enough that variation is generated.
- Differential reproductive success of the sequence (or of vehicles that carry it) is causally dependent on the sequence’s effects in a physical environment.

## Tightened Definition Relative to Wikipedia

Wikipedia’s “sequence of nucleotides in DNA that is transcribed to produce RNA” is a useful biological description but fails as a strict R1 definition on three counts:

- It ties the entity to DNA rather than to any physical informational polymer that meets the conditions.
- It treats transcription as definitional rather than as one possible expression pathway.
- It does not explicitly separate the informational identity from the physical substrate and the copying machinery.

## Strict Formulation

> An R1 replicator is a physical informational sequence whose differential persistence and further copying are causally dependent on its own structure, mediated by molecular machinery that is distinct from the sequence itself.

### Cascade Training Log (2026-08-14T20:45:05.490Z)

- Documents consulted: kg, glossary, gene
- Conclusion: The primary gap preventing a successful Exterior-gate review of the R1 candidate is the absence of an authorized reference document that formally maps biological dualities to Temetic concepts. Specifically, a reviewer needs an explicit mapping guide (e.g., an 'R1/Biological Mapping Guide') that translates: 1) the Mendelian gene (abstract unit of heredity) to the Temetic 'lossless kernel'; 2) the molecular gene/genotype (physical nucleotide sequence) to the 'substrate' (M); and 3) the phenotype (expressed physical traits) to the 'execution' or 'expression' of the replicator. No existing document in the current corpus bridges this biological-to-temetic translation.
