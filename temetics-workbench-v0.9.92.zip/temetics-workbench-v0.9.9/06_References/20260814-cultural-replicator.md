---
raw_content_sha256: 9b1415309f611943e45f208608403a83bf52016606783de29d60567931217bdf
source: chat
source_node: Node M
source_session_id: null
captured: '2026-08-14T22:44:57.354Z'
inbox_sequence: '004'
extracted_tag: '#cultural-replicator'
aliases:
  - Cultural Replicator
keywords:
  - replicator
  - memetics
  - cultural-transmission
  - cognitive-substrate
ddc: '300'
related_nodes:
  - '[[Memetics]]'
  - '[[Cultural Evolution]]'
  - '[[Universal Darwinism]]'
ingested_at: '2026-08-14T22:45:19.372Z'
training_reference_docs:
  - kg
  - glossary
  - replicator-stability
  - temetic-primer
  - r1-replicator
training_completed_at: '2026-08-14T22:48:53.361Z'
cascade_incomplete: false
gate_status: parallax_approved
promoted_at: '2026-08-14T22:49:58.926Z'
awaiting_parallax: false
founder_note: ''
verification_receipt:
  status: CONSISTENT
  referenced_rules:
    - P0
    - P1
    - P4
    - P6
  evaluated_rules:
    - P0
    - P1
    - P4
    - P6
  evidence:
    - candidate_quote: >-
        An R2 replicator is an informational pattern realized in one or more
        cognitive substrates (human or otherwise).
      kernel_rule: P0
      reasoning: >-
        The candidate defines R2 as substrate-independent across cognitive
        substrates, aligning with the Law of Substrate Invariance (P0) and the
        R2 entity definition in the knowledge graph [cite: temetic-primer].
      confidence: 0.95
    - candidate_quote: >-
        Selection is gated on **utility alone**: whether a copy persists and
        propagates further depends only on its usefulness - functional, social,
        emotional, or otherwise - to the substrates carrying it, with no
        independent correspondence-to-fact requirement built into the gate.
      kernel_rule: P1
      reasoning: >-
        The decoupling of selection from correspondence-to-fact (utility-only
        gating) maps to Valence Decoupling (P1), where truth-value is
        independent of substrate response/utility [cite: replicator-stability].
      confidence: 0.9
    - candidate_quote: >-
        It carries **no sterility condition**: canon defines a sterility
        condition as a binary correspondence gate that can zero out a copy's
        fitness outright - R3's version assigns zero fitness to any copy that
        fails to resolve against a grounding referent. R2 has no such gate:
        every successfully interpreted copy retains non-zero fitness regardless
        of whether it corresponds to anything true, and is only up- or
        down-weighted by utility.
      kernel_rule: P6
      reasoning: >-
        The absence of a sterility condition in R2 directly contrasts with the
        P6 grounding/stabilizer condition defined in Lemma 3 of Replicator
        Stability, where failure to resolve against a grounding referent zeroes
        out fitness [cite: replicator-stability].
      confidence: 0.95
    - candidate_quote: >-
        optimized for transmission velocity, not truth-preservation: a false or
        distorted pattern that is more useful in the above sense will
        out-propagate a true one, with nothing in the replication mechanism
        itself correcting for that.
      kernel_rule: P4
      reasoning: >-
        This describes the divergence of utility and correspondence under noise,
        where utility-optimized structures out-replicate
        correspondence-preserving ones, mapping directly to Lemma 1 (Axioms P1,
        P4) [cite: replicator-stability].
      confidence: 0.95
  supported_mapping: >-
    The evaluation establishes that the candidate's definition of the R2
    replicator matches the entity parameters in the knowledge graph (fidelity:
    interpretive, gating: utility_only, conditioning: f_R_proportional_utility,
    sterility_condition: false) and consistently maps its dynamics to P0
    (substrate invariance), P1 (valence decoupling), P4 (fidelity paradox), and
    the absence of P6 (grounding/sterility condition).
  citation_check:
    cited:
      - temetic-primer
      - replicator-stability
    unverified: []
    verified: true
  kernel_projection: >-
    R2 replicators are ungrounded, utility-driven informational structures whose
    replication rate scales with substrate utility rather than veridical
    correspondence, driving semantic drift and convergence toward non-veridical
    absorbing states in the absence of a P6 sterility constraint.
parallax_approved_at: '2026-08-14T23:23:20.884Z'
---
# R2 - Cultural / Cognitive-Substrate Replicator (Revised, glossed)

## Shared Replicator Grammar (common to R1, R2, R3)

A replicator is an informational entity that:

1. maintains a sufficiently stable identity across successive copies,
2. is copied by a mechanism that can introduce variation,
3. is subject to differential persistence or differential further copying (selection),
4. does so under constraints imposed by a substrate and its associated machinery.

The classes differ in *where* and *how* those four conditions are realized.

## Necessary and Sufficient Conditions for R2

An entity is an R2 replicator if and only if:

- It is an informational pattern realized in one or more cognitive substrates (human or otherwise).
- The pattern is copied by imitation, teaching, or other inter-cognitive transmission mechanisms distinct from the pattern itself.
- Variation arises through imperfect recall, recombination, or deliberate modification.
- Differential further transmission is causally dependent on the pattern's effects within a cultural or cognitive environment.
- Its transmission fidelity is **interpretive**, not mechanical: what persists across copies is the pattern's effect or meaning as reconstructed by the receiving substrate, not an exact token-for-token replica. This is the R2 analog of R1's copying-fidelity condition, but enforced by shared interpretive convention rather than by dedicated molecular machinery independent of what the sequence "means."
- Selection is gated on **utility alone**: whether a copy persists and propagates further depends only on its usefulness - functional, social, emotional, or otherwise - to the substrates carrying it, with no independent correspondence-to-fact requirement built into the gate.
- The rate at which a variant is further copied is **proportional to the utility it currently confers**: more-useful variants aren't merely favored at a fixed threshold, their copying rate tracks realized utility continuously.
- It carries **no sterility condition**: canon defines a sterility condition as a binary correspondence gate that can zero out a copy's fitness outright - R3's version assigns zero fitness to any copy that fails to resolve against a grounding referent. R2 has no such gate: every successfully interpreted copy retains non-zero fitness regardless of whether it corresponds to anything true, and is only up- or down-weighted by utility.
- Taken together, R2 is optimized for transmission velocity, not truth-preservation: a false or distorted pattern that is more useful in the above sense will out-propagate a true one, with nothing in the replication mechanism itself correcting for that.

## Tightened Definition Relative to the Standard "Meme" Concept

The informal meme concept correctly identifies imitation as a transmission channel and the analogy to genetic replication, but under-specifies two things that matter for R2's boundary conditions:

- It implicitly treats the human mind as the only relevant substrate, rather than any cognitive substrate meeting the conditions above.
- It is silent on *why* memes drift toward virality over accuracy - R2's utility-only gating and utility-proportional conditioning make that drift a structural consequence of the definition rather than an observed tendency bolted on afterward.

## Strict Formulation

> An R2 replicator is an informational pattern realized in one or more cognitive substrates whose differential transmission is governed by interpretive fidelity (the element that persists across copies is reconstructed meaning or effect, not exact duplication), utility-only gating (further propagation depends solely on usefulness to the substrates carrying it, with no independent truth requirement), and utility-proportional conditioning (copying rate scales continuously with realized utility rather than a fixed threshold). It carries no sterility condition - unlike R3, where a copy that fails to resolve against a grounding referent is assigned zero fitness outright, no R2 copy is zeroed out for lacking correspondence, only up- or down-weighted by utility - and it is accordingly optimized for transmission velocity rather than veridical correspondence. Copying occurs via imitation, teaching, or other inter-cognitive mechanisms distinct from the pattern itself; variation arises through imperfect recall, recombination, or deliberate modification; and further transmission is causally dependent on the pattern's effects within a cultural or cognitive environment.

## Terminology cross-reference (for kg/glossary alignment)

Plain-language gloss aboveFormal designation used in prior candidatesinterpretive fidelity`interpretive` fidelityutility-only gating`gating: utility_only`utility-proportional conditioning`f_R_proportional_utility`no sterility condition`sterility_condition: false`

*Verification note: checked against temetic-kg v0.1, GLOSSARY.md, TEMETIC_PRIMER.md, and REPLICATOR_STABILITY.md. All four parameter values above (fidelity: interpretive, gating: utility_only, conditioning: f_R_proportional_utility, sterility_condition: false) match the R2 entity definition in kg exactly. The glossary itself doesn't define these field names as prose entries - the sterility_condition gloss was tightened using R3's contrasting sterility_condition: true and Replicator Stability's Lemma 3, since that's the only place canon spells out what a sterility condition actually does.*

### Cascade Training Log (2026-08-14T22:48:53.359Z)

- Documents consulted: kg, glossary, replicator-stability, temetic-primer, r1-replicator
- Conclusion: The diagnostic pass reveals three primary gaps preventing a successful Exterior-gate review of the R2 candidate:

1. **Absence of a Replicator Schema Specification**: The formal parameters used to define R2 in the knowledge graph (`fidelity: interpretive`, `gating: utility_only`, `conditioning: f_R_proportional_utility`, and `sterility_condition: false`) are not defined as prose entries or mathematical formulations in the canonical `glossary` or `temetic-primer`. The reviewer has no authorized reference to verify the candidate's gloss of these parameters (e.g., why `sterility_condition: false` means the absence of a binary correspondence gate, which the candidate had to infer from R3's contrasting parameters and Lemma 3 of *Replicator Stability*).

2. **Absence of an R2/Memetic Mapping Guide**: Similar to the R1 candidate's gap, there is no authorized reference document that formally maps classical memetic/cultural transmission concepts to Temetic R2 concepts. A reviewer needs an explicit guide translating: 1) the classical 'meme' (as an informal unit of imitation) to the R2 'lossless kernel'; 2) 'imitation/teaching' to 'interpretive fidelity'; 3) 'human/AI minds' to 'cognitive substrates' (M); and 4) 'virality/usefulness' to 'utility-only gating' and the absence of a sterility condition.

3. **Typographical/Encoding Corruption**: The candidate document contains multiple instances of '-' (likely corrupted em-dashes or punctuation). A clean, authorized style guide or template is required to resolve these formatting defects.
