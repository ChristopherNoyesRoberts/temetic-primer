# 06_References

See `AGENTS.md` §1 for the authoritative pipeline definition — not
restated here in full, so there's only one copy of the CONFIG table and
gate_status lifecycle to keep in sync. This file covers what's specific
to this stage.

Local, parallax-approved working definitions and reference material that
the Interior training cascade (`promotion-helper.js`) and the Exterior
gate (`candidate-to-promoted.js`) can cite by id — same mechanism as
`kg`, `holster`, `glossary`, etc., just dynamically discovered here
instead of hardcoded in `infra/lib/reference-manifest.js`.

**Distinct from `07_Published/` on purpose.** `07_Published/` means
"actually pushed to Substack" — real external publication. A file lands
here once it has cleared the local gate (`03_Promoted/`,
`gate_status: parallax_pending`) AND gone through Alliance parallax
review AND come back `gate_status: parallax_approved`. It may never be
pushed to Substack or GitHub — it's usable locally as a working
definition regardless. `00_Canon/` stays exactly as it is today:
read-only, one-way mirror from GitHub, untouched by any of this.

**How a file gets here — the real flow, not the old manual one.**
`infra/promoted-to-parallax.js` batches `03_Promoted/` items into a
manifest sent to `04_To_Parallax/`. Node Alliance members
(Node B, Node A, Node CL, Node GPT) reply with YAML/JSON receipts
dropped into `05_From_Parallax/`. `infra/collate_parallax.js` validates
each receipt against the allowlist and the originating manifest,
accumulates signatures toward quorum (≥2 distinct machine approvals,
zero outstanding dissent) in the parallax ledger, and — once that
machine-quorum half is met — prompts the founder for a manual sign-off
before flipping `gate_status` to `parallax_approved`. Only then does
`infra/promote-to-references.js` **move** the file here — not copy.
`03_Promoted/` never retains a copy of an approved item; the move is the
custody-chain guarantee, not just a filing convenience. See
`infra/_provenance.md` for the full behavioral rundown of both scripts.

**How the cascade sees it:** `reference-manifest.js` scans this directory
live on every lookup (no restart needed). A file's own `extracted_tag`
(e.g. `#epistemology`) becomes its citable id — the same tag that shows
up in some other file's `related_nodes` wikilink, closing the loop: a
rejected candidate names the missing concept, founder defines and
approves it here, and it's automatically available to unblock that same
gap on retry.

**Growth here is intentional, not a mess to clean up.** This is meant to
become an ever-expanding personal glossary of working definitions, each
one subject to ongoing re-testing as the framework evolves.

**A note on this file's own staleness risk:** this is the third README
in this pipeline to drift out of sync with the automation it describes
(see `02_Candidate/README.md` and `03_Promoted/README.md`'s own
histories). If anything above disagrees with `AGENTS.md` or with what
`collate_parallax.js`/`promote-to-references.js` actually do, those are
the source of truth, not this file — flag the discrepancy rather than
trust this description on its face.
