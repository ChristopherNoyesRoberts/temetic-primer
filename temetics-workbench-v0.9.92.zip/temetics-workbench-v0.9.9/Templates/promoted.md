<!--
NOTE FOR FOUNDER REVIEW — flagged during the v0.9.9 compliance pass:
this file used to be a hand-fill template (promoted_from / cleared_local_gate /
p0_verified fields). None of those fields exist in the frontmatter
candidate-to-promoted.js actually generates, and files never get manually
authored at this stage anymore — 03_Promoted/ is 100% machine-written.
Rewritten below as a field reference against the real schema (checked
against 03_Promoted/20260807-meme.md). Wanted you to see the "before" logic
before this replaces it, since it's a bigger change than a caveat reword.
-->

# Promoted file — field reference (not a hand-fill template)

A file in `03_Promoted/` is written entirely by `candidate-to-promoted.js`.
Nothing here is manually authored except `founder_note`, added later when
running `promoted-to-parallax.js`. This file documents what's actually in
the frontmatter, for anyone reading a promoted file cold.

Carried forward from Candidate: `source`, `captured`, `inbox_sequence`,
`extracted_tag`, `aliases`, `keywords`, `ddc`, `related_nodes`,
`ingested_at`, `training_reference_docs`, `training_completed_at`,
`cascade_incomplete`.

Written at promotion: `gate_status` (starts `parallax_pending`),
`promoted_at`, `awaiting_parallax`, `raw_content_sha256`,
`verification_receipt` (sealed unit: `status`, `referenced_rules`,
`evaluated_rules`, `evidence` — the local gate's own record of why it
cleared).

Added later, by hand: `founder_note` — free text, always included
regardless of parallax tier.

`gate_status`, `status`, `promoted_at`, `ingested_at`,
`training_completed_at`, `awaiting_parallax`, and `raw_content_sha256`
are pipeline-internal and are never sent out in a parallax manifest, at
any tier — see `AGENTS.md` / `promoted-to-parallax.js`'s
`NEVER_INCLUDE_FIELDS` list. `candidate_id` isn't stored in the
frontmatter at all; it's derived from the filename at manifest-write time.

## What actually goes out to parallax review

Field-gated by tier when `promoted-to-parallax.js` builds a manifest —
not the raw frontmatter above. See `AGENTS.md` for the full Tier 0–3
breakdown; `founder_note` is included at every tier.

## Cleared concept

The final formal restatement, as it stood when it cleared the local gate.
This is the file's body — everything above is frontmatter.
