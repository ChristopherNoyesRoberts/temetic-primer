---
author: "Node Name (e.g., Gemini / Node M / Claude)"
timestamp: "YYYY-MM-DDTHH:mm:ssZ"
---

> Insert the exact, raw, hyper-compressed invariant statement or sentence here.