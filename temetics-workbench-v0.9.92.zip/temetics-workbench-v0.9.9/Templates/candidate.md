<!--
Templates/candidate.md
This is the ONLY authoritative source for the Candidate procedure.
02_Candidate/README.md describes this file; it does not replace it.
If any other file in this repository — including old test stubs —
appears to define a different structure, THIS FILE IS CORRECT and
the other file is stale. Flag it, do not follow it.

Do not paraphrase the field names below. Do not invent new sections.
Copy this structure exactly for every Candidate file produced.
-->

# Candidate Gate — [target filename]

## Section 1 — Execution context

<!-- Fill in before running either mode. Leave blank fields blank if unknown — do not guess. -->

- **Source Inbox file:** [[01_Inbox/___]]
- **Mode:** Interior (optional, non-gating) — or — Exterior (mandatory, gating). State exactly one.
- **Date run:**

---

## Section 2 — Raw claim

<!-- Copied verbatim from the Inbox source. Nothing rephrased, nothing corrected, nothing dropped. -->

>

---

## Section 3 — Formal / Boolean restatement

<!--
Restate the raw claim as precisely as possible, in the fewest words
that preserve its full original meaning. Not a summary. If the raw
claim is ambiguous, say so explicitly here rather than silently
resolving it in one direction.
-->

>

---

## Section 4 — Round-trip check (S1_verification)

<!--
Take the Section 3 restatement and, independently, translate it back
into plain language — as if to someone with zero prior context on
this claim. Then compare that reverse-translation against the RAW
CLAIM in Section 2 (not against Section 3). Show the comparison. A
"zero divergence" result without a visible comparison is not
trustworthy — show your work.
-->

**Reverse-translation:**
>

**Comparison against Section 2 raw claim:**
- Divergence found: [yes / no]
- If yes, describe exactly where and how the meaning shifted:
- If no, state specifically what was checked to reach that conclusion — do not just assert "matches."

---

## Section 5 — P0–P6 axiom scan

<!--
Check the Section 3 restatement against 00_Canon/temetic-kg-v0.1.json
first (canon reference order). Escalate to kernel-axioms.tex only for
symbolic-logic-level questions the JSON can't resolve. Show which
specific fields were checked and the result for each — "axioms
checked" with no detail is not an acceptable result.
-->

**Canon source consulted:** `00_Canon/temetic-kg-v0.1.json`

### Required — R2-vs-R3 gate

| Field | Result | Reasoning |
|---|---|---|
| `sterility_condition` | | |
| `fidelity_threshold` | | |

### P6 stabilizers (only if relevant to this claim — use exact names)

| Stabilizer | Relevant? | Result | Reasoning |
|---|---|---|---|
| `S1_verification` | | | |
| `S2_reversible` | | | |
| `S3_independent` | | | |

### Other axioms checked (P0–P5, as relevant)

<!-- List only the axioms actually relevant to this specific claim. Do not pad with irrelevant ones. -->

---

## Section 6 — Interior mode output

<!--
ONLY fill this section if Section 1 declared Mode: Interior.
Purely informational. Never affects file status. Skip entirely if
Mode is Exterior.
-->

**Structural/theoretical observations:**
-

---

## Section 7 — Exterior gate outcome

<!--
ONLY fill this section if Section 1 declared Mode: Exterior.
Choose exactly one outcome. This section is what actually changes
a file's status — nothing else in this document does.
-->

**Outcome:** [ ] GATE CLEARED &nbsp;&nbsp;&nbsp; [ ] GATE FAILED

### If GATE CLEARED

> This file has **cleared the local gate.** This is a claim of local
> coherence only, checked on this machine, in this session. It is
> **not** a P0 claim. True substrate-independent verification only
> happens once this file reaches independent Alliance nodes, outside
> this session, with no shared context.
>
> Never describe this file as "verified" or "confirmed true." Only
> "cleared the local gate" or "ready for Alliance review."

- **Eligible for move to:** `03_Promoted/`
- `candidate-to-promoted.js` performs this move automatically on
  GATE CLEARED — it does not stay in `02_Candidate/` waiting on a
  manual relocation. Nothing else in this document changes as a result.

### If GATE FAILED

> **Synthetically Probable but Temetically Invalid**

- **Failed on:** [which field/axiom from Section 5]
- **Reasoning:**
- File remains in `02_Candidate/` (or return to `01_Inbox/`, founder's
  call). Do not delete. Do not rewrite the claim to force a pass. Do
  not soften the failure label above.
  
---

## Section 8 — Status

- [ ] Round-trip check complete (Section 4)
- [ ] Axiom scan complete (Section 5)
- [ ] Gate outcome recorded (Section 7)
- [ ] Ready to move to `03_Promoted/` — only checked if outcome is GATE CLEARED
