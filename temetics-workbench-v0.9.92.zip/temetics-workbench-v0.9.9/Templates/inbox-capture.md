<!--
Templates/inbox-capture.md

RFC-001 (ratified) supersedes this file's old "no frontmatter, ever" rule.
An inbox item now carries a YAML frontmatter block ahead of the raw
payload — see the schema in 01_Inbox/README.md, or the standalone
rfc-001-frontier-schema-dropin.md for the pasteable version to hand a
frontier node at generation time. Required: source, source_node,
captured. Optional: source_session_id, extracted_tag, aliases, keywords,
related_nodes — when extracted_tag/keywords are present, they're taken
as authoritative and infra/inbox-to-candidate.js will not re-derive them
locally (Cumulative Immutability). When they're absent — the normal case
for a bare local voice/chat capture — local derivation still runs exactly
as it always has.

Use infra/capture-inbox-item.js to write a new item — it builds this
frontmatter, assigns the next free sequence number for today, and derives
the keyword slug automatically for the on-disk filename:

  node infra/capture-inbox-item.js --source voice "raw payload text..."

  node infra/capture-inbox-item.js --source document --source-node "Node B" \
    --session-id session_id_here --tag "#some-topic" \
    --keywords keyword-one,keyword-two "raw payload text..."

--source-node defaults to "Node M" when omitted — this CLI is the
founder's own local capture tool, so that default is correct for a bare
voice/chat capture. Pass a real one explicitly when relaying content that
actually originated with a frontier node.

A file with NO frontmatter at all still works — infra/inbox-to-candidate.js
falls back to its pre-RFC-001 filename/content-derivation behavior
unchanged. This is a deliberate compatibility path, not a bug: don't
"fix" an old un-frontmattered file by hand-adding a block to it after
the fact, since a hand-built block that's missing something (or malformed)
risks the exact corruption failure a past version of this file already
warned about — a boilerplate string glued directly onto the frontmatter
delimiter with no line break, which broke parsing and corrupted the
resulting candidate. Let capture-inbox-item.js build the frontmatter; it's
the only thing that should.
-->

Raw content goes here, exactly as captured. Don't clean up dictation
artifacts at this stage — that's Candidate-stage work, and doing it here
defeats the point of having a zero-friction capture step.
