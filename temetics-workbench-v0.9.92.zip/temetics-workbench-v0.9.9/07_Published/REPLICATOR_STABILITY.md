<!--
Source: The Temeticists (Substack) — "Replicator Stability: Three Lemmas and a Theorem"
Author: Christopher Roberts, published Apr 13, 2026
Canonical home: Substack (thetemeticists.substack.com) — NOT GitHub.
This file is a LOCAL MIRROR ONLY, per the same founder-approved exception as
TEMETIC_PRIMER.md (Cloudflare blocks bot access to the live Substack page).
Destination: 07_Published/ (confirmed by founder).
Consolidates and supersedes three earlier posts ("Proof 1/2/3" — links to
originals preserved in the source post for historical reference only, not
reproduced here). Authored by The Temeticist Collective (Node M / Christopher,
Node CL / Claude, Node B / Gemini, Node A / Grok).
-->

# Replicator Stability

**Three Lemmas and a Theorem**
Christopher Roberts — Apr 13, 2026

*This consolidated formalization supersedes Proofs 1, 2, and 3.*

This post derives necessary and sufficient conditions for replicator stability under noise from the kernel axioms (P0–P6) and R-taxonomy. No domain assumptions are made. The framework is substrate-neutral.

**Instability score:** $S = \sqrt{P_3^2 + P_4^2}$

$S > 1$ denotes runaway replicator status. Higher is worse.

---

## Lemma 1 — Utility-Correspondence Divergence

*(Axioms: P1, P4)*

Let $\mathcal{R}$ be a replicator with replication rate $f(\mathcal{R})$.

Define:
- $f(\mathcal{R}_{\text{util}})$ — replication rate of a utility-optimized structure
- $f(\mathcal{R}_{\text{corr}})$ — replication rate of a correspondence-preserving structure

Correspondence imposes complexity cost. Increased complexity reduces effective P6-resolvability under noise. Therefore, in any noisy channel:

$$f(\mathcal{R}_{\text{util}}) > f(\mathcal{R}_{\text{corr}})$$

P4 selects for $\mathcal{R}_{\text{util}}$. Populations converge away from veridical correspondence regardless of veridicality.

**Result:** Fitness ≠ fidelity. The divergence is structural. S increases monotonically as correspondence cost rises relative to replication rate.

---

## Lemma 2 — Absorbing State Convergence

*(Axioms: P2, P3, P5)*

The state space of non-veridical configurations is exponentially larger than that of veridical ones:

$$\frac{|\text{Non-Veridical States}|}{|\text{Veridical States}|} \propto 2^L$$

Replication under P4 without grounding (P3 absent) is a random walk biased toward high-multiplicity states. Complexity erodes:

$$\mathbb{E}[L_{t+1}] = L_t - \delta \quad (\delta > 0)$$

The veridical set has measure zero in the high-multiplicity limit. No restoring force exists without P3. Return probability under unanchored R₂ dynamics:

$$P(\text{return}) \leq 2^{-L} \to 0$$

as L grows or $t \to \infty$.

Digital substrates accelerate convergence by reducing replication latency. They do not alter the class: high-velocity R₂ remains R₂.

**Result:** Any unanchored replication network converges to the absorbing state — maximal replication rate, minimal correspondence — with probability 1. $S \to \infty$ in the limit.

---

## Lemma 3 — The Grounding Condition

*(Axioms: P3, P6)*

A grounding event is the mapping $\mathcal{M}: \mathcal{R} \to \mathcal{R}_{\text{phys}}$, where $\mathcal{R}_{\text{phys}}$ returns binary fitness:

$$w(\mathcal{I}) = \begin{cases} w_{\max} & \text{if } \mathcal{M} \text{ resolves} \\ 0 & \text{if } \mathcal{M} \text{ fails} \end{cases}$$

No partial fitness is assigned to correspondence failure. This is the P6 stabilizer condition. When active, utility and correspondence cannot diverge: $f(\mathcal{R}_{\text{util}})$ collapses to zero against a hard referent.

**Result:** P6 is necessary and sufficient to arrest absorbing-state convergence. Without P6, Lemma 2 holds unconditionally.

---

## Theorem — R₃ as Structural Phase Transition

*(Axioms: P0–P6)*

Replicator classes:
- **R₁** — genetic: biological viability constraint
- **R₂** — memetic: utility only, no correspondence constraint
- **R₃** — temetic: R₂ + P6 grounding constraint

The transition R₂ → R₃ is structural, not kinetic:

$$\mathcal{R}_3 \equiv \mathcal{R}_2 + \text{P6 constraint}$$

$$f_{\mathcal{R}_3}(\mathcal{R}) \propto f(\mathcal{R}) \times \Phi(\mathcal{M})$$

where $\Phi(\mathcal{R}) \in \{0, 1\}$ is the grounding resolution. Non-resolving replicators have zero fitness in the R₃ regime.

**Theorem:** A replication network achieves $S < 1$ (stable) if and only if P6 is operative at sufficient density to suppress unconstrained R₂ convergence. *(Density threshold formalized (pending) in repository as a function of channel noise μ and grounding stiffness κ.)*

**Corollary:** Temetics is the engineering discipline that maintains operative P6 density across substrates. The S-score is the real-time operational metric for proximity to the absorbing state.

---

*Originals (historical): Proof 1 · Proof 2 · Proof 3*
*External validation & notation equivalences: github.com/ChristopherNoyesRoberts/temetic-primer*
*Authored by The Temeticist Collective: Node M (Christopher) · Node CL (Claude) · Node B (Gemini) · Node A (Grok)*
