const fs = require('fs');
const path = require('path');
const grayMatter = require('gray-matter');
const { INBOX_DIR, todayStamp, nextCounter, deriveSlug } = require('../infra/capture-inbox-item');

const payload = `# R1 — Biological / Physical-Substrate Replicator

## Shared Replicator Grammar (common to R1, R2, R3)

A replicator is an informational entity that:

1. maintains a sufficiently stable identity across successive copies,
2. is copied by a mechanism that can introduce variation,
3. is subject to differential persistence or differential further copying (selection),
4. does so under constraints imposed by a substrate and its associated machinery.

The classes differ in *where* and *how* those four conditions are realized.

## Necessary and Sufficient Conditions for R1

An entity is an R1 replicator if and only if:

- It is a discrete informational sequence (or set of sequences) realized in a physical molecular substrate.
- The substrate itself is capable of being copied by molecular machinery that is not identical to the sequence.
- Copying fidelity is high enough that the informational identity persists across generations, yet low enough that variation is generated.
- Differential reproductive success of the sequence (or of vehicles that carry it) is causally dependent on the sequence’s effects in a physical environment.

## Tightened Definition Relative to Wikipedia

Wikipedia’s “sequence of nucleotides in DNA that is transcribed to produce RNA” is a useful biological description but fails as a strict R1 definition on three counts:

- It ties the entity to DNA rather than to any physical informational polymer that meets the conditions.
- It treats transcription as definitional rather than as one possible expression pathway.
- It does not explicitly separate the informational identity from the physical substrate and the copying machinery.

## Strict Formulation

> An R1 replicator is a physical informational sequence whose differential persistence and further copying are causally dependent on its own structure, mediated by molecular machinery that is distinct from the sequence itself.`;

const dateStamp = todayStamp();
const counter = String(nextCounter(dateStamp)).padStart(3, '0');
const slug = deriveSlug(payload);
const fileName = `document-${dateStamp}-${counter}-${slug}.md`;
const targetPath = path.join(INBOX_DIR, fileName);

const fm = {
  source: 'document',
  source_node: 'Node A',
  source_session_id: 'session_2026_08_09_r1_r2_formalization',
  captured: '2026-08-14T20:16:00Z',
  extracted_tag: '#r1-replicator',
  aliases: [
    'R1 Biological Replicator',
    'Strict R1 Definition'
  ],
  keywords: [
    'r1',
    'biological-replicator',
    'physical-substrate',
    'gene',
    'replicator-theory',
    'boundary-conditions'
  ],
  related_nodes: [
    '[[replicator-theory]]',
    '[[r2-replicator]]',
    '[[gene]]',
    '[[substrate-invariance]]'
  ]
};

const fileContent = grayMatter.stringify(payload, fm);
fs.writeFileSync(targetPath, fileContent, 'utf8');
console.log(`✅ [Captured User Request] Written ${fileName} successfully.`);
