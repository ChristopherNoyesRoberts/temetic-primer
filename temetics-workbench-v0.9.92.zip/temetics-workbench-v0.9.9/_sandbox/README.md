# _Sandbox

Ephemeral, test-only workspace. Not part of the Candidate→Promoted
pipeline — nothing here is being evaluated, gated, hashed, or tracked in
the ingestion ledger, and no daemon watches this folder.

Use it for:
- bridging/scratch documents while testing a script or a prompt change
- throwaway inputs used to sanity-check tooling before touching real data
- anything a node wants to leave behind for the founder to look at that
  isn't itself a claim or "new thinking" (see AGENTS.md §5's Inbox-first
  rule — genuine new thinking still goes to `01_Inbox/`, never here)

Not subject to:
- the Inbox-first rule (this isn't a claim awaiting review)
- reversibility snapshotting (§6) — treat contents as disposable
- the write-scope surface-before-overwrite rule (§5) — freely create,
  edit, or delete anything in here without asking first

Founder or any node may clear this folder at any time with no ceremony.
If something in here turns out to matter, move it into `01_Inbox/`
properly (through `capture-inbox-item.js`, not by hand) so it gets a real
audit trail.
