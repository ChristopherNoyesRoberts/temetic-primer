#!/usr/bin/env node
/**
 * promote-to-references.js
 *
 * Manifesto v4.0 §5.8: watches 03_Promoted/ for files whose frontmatter
 * reaches `gate_status: parallax_approved` — the manual cross-node review
 * step (founder drags the file into the four always-open Node Alliance
 * tabs; will become one-click once ingest-from-parallax.js / the
 * publish-to-machine-node RFC lands) — and MOVES (never copies) the file
 * into 06_References/, where reference-manifest.js's dynamic scan picks it
 * up automatically.
 *
 * This is deliberately the SMALLEST possible bridge: it does not judge
 * content, does not call the substrate, does not touch 00_Canon/. It only
 * reacts to a gate_status value the founder (or a future automated
 * parallax flow via ingest-from-parallax.js) sets by hand.
 *
 * v4.0 correction from prior v0.9.x behavior: this used to COPY and leave
 * 03_Promoted/ as a permanent record, gated on a bare `status` field. Per
 * §5.8/§12, the correct behavior is MOVE — 03_Promoted/ after a move
 * contains only pending or declined items, never approved-and-synced ones.
 * Declined items (`gate_status: local_gate_declined` /
 * `parallax_declined`) are NOT touched by this script and are never
 * auto-removed from 03_Promoted/ — only a manual founder deletion removes
 * them (§5.8 consequences; founder ruling, this thread).
 *
 * Idempotency: file existence is the guard. Once moved, the file no
 * longer exists at its 03_Promoted/ path, so a daemon restart or duplicate
 * chokidar event (ignoreInitial:false re-scans the whole folder) has
 * nothing left to re-process — the existsSync check at the top of
 * moveIfApproved() is sufficient on its own. The promotion ledger write is
 * additionally deduplicated by content hash (see loggedInLedger below) so
 * a crash between the ledger append and the unlink (interrupted move)
 * doesn't produce a duplicate ledger entry when the move is retried.
 *
 * Ledger: per §8 ("Ledger paths"), the promotion/publishing ledger lives
 * at 03_Promoted/.promotion-ledger.json — separate from the cryptographic
 * SHA-256 audit chain (§5.3) and from the parallax ledger (§5.7,
 * .parallax-ledger.json, written by the not-yet-built
 * ingest-from-parallax.js). Its purpose is publishing-decision input: a
 * node asking "what's recently parallax-approved?" reads this ledger, not
 * the audit chain. Obsidian ignores non-Markdown files, so this
 * introduces no View-layer noise.
 */

require('dotenv').config();

const fs = require('fs');
const path = require('path');
const chokidar = require('chokidar');
const grayMatter = require('gray-matter');
const { acquireSingleInstanceLock } = require('./lib/single-instance-lock');
const { REFERENCES_DIR } = require('./lib/reference-manifest');

const PROMOTED_DIR = path.join(__dirname, '../03_Promoted');
const LEDGER_PATH = path.join(PROMOTED_DIR, '.promotion-ledger.json');
const NON_CANDIDATE_FILENAMES = new Set(['README.md']);

acquireSingleInstanceLock(path.join(__dirname, '.promote-to-references.lock'), 'promote-to-references.js');

if (!fs.existsSync(REFERENCES_DIR)) fs.mkdirSync(REFERENCES_DIR, { recursive: true });

let pipelineQueue = Promise.resolve();
function queuePipelineAction(actionFn) {
  pipelineQueue = pipelineQueue.then(async () => {
    try { await actionFn(); }
    catch (err) { console.error('❌ PtR Pipeline Fault:', err.message); }
  });
  return pipelineQueue;
}

// Ledger is a hash-keyed JSON object, same convention as
// lexicons/.ingestion-ledger.json — but this is one of the three §5
// pipeline ledgers, not the lexicon. Keyed by raw_content_sha256 when
// available (stable across the move, unlike filename) so a retried/
// interrupted move can detect "already logged" without depending on the
// file still existing at either path.
function loadLedger() {
  if (!fs.existsSync(LEDGER_PATH)) return {};
  try {
    return JSON.parse(fs.readFileSync(LEDGER_PATH, 'utf8'));
  } catch (err) {
    console.error(`⚠️ [Ledger] Failed to parse ${path.basename(LEDGER_PATH)} — refusing to overwrite it blindly:`, err.message);
    throw err; // don't silently clobber a corrupt-but-recoverable ledger
  }
}

function saveLedger(ledger) {
  fs.writeFileSync(LEDGER_PATH, JSON.stringify(ledger, null, 2), 'utf8');
}

function moveIfApproved(filePath) {
  return queuePipelineAction(async () => {
    if (!fs.existsSync(filePath)) return;

    const raw = fs.readFileSync(filePath, 'utf8');
    const parsed = grayMatter(raw);
    const frontmatter = parsed.data || {};

    if (frontmatter.gate_status !== 'parallax_approved') return;

    const baseName = path.basename(filePath);
    const targetPath = path.join(REFERENCES_DIR, baseName);
    const ledgerKey = frontmatter.raw_content_sha256 || baseName;

    const ledger = loadLedger();
    const alreadyLogged = Object.prototype.hasOwnProperty.call(ledger, ledgerKey);

    // Write to References first — the audit-chain-critical content must
    // exist at the destination before we remove the source. If a crash
    // happens between these two lines, re-running this script is safe:
    // the write below is a harmless overwrite with identical content, and
    // the unlink still needs to happen.
    fs.writeFileSync(targetPath, raw, 'utf8');

    if (!alreadyLogged) {
      ledger[ledgerKey] = {
        candidate_name: baseName,
        gate_status: frontmatter.gate_status,
        promoted_at: frontmatter.promoted_at || null,
        references_synced_at: new Date().toISOString()
      };
      saveLedger(ledger);
    }

    fs.unlinkSync(filePath);

    const tagNote = typeof frontmatter.extracted_tag === 'string'
      ? ` (citable as "${frontmatter.extracted_tag.replace(/^#/, '')}")`
      : ' (no extracted_tag — will fall back to a filename-derived id)';

    console.log(`✅ [Promoted → References] ${baseName} moved to 06_References/${tagNote}`);
  });
}

const watcher = chokidar.watch(PROMOTED_DIR, {
  persistent: true,
  ignoreInitial: false,
  awaitWriteFinish: { stabilityThreshold: 600, pollInterval: 100 }
});

watcher.on('all', (event, filePath) => {
  if (filePath.endsWith('.md') && (event === 'add' || event === 'change')) {
    const baseName = path.basename(filePath);
    if (NON_CANDIDATE_FILENAMES.has(baseName)) return;
    moveIfApproved(filePath);
  }
});

console.log('🚀 Promote-to-References (gate_status: parallax_approved → 06_References/, move) Active. Monitoring 03_Promoted...');
