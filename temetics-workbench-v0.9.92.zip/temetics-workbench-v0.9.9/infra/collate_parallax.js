#!/usr/bin/env node
/**
 * collate_parallax.js
 *
 * RFC-003 v2 (parallax-to-local receipt schema): manually-triggered
 * inbound collation script. Reads every receipt file the founder has
 * pasted into 05_From_Parallax/, validates each against the local
 * Node Alliance allowlist and the outbound manifest in 04_To_Parallax/,
 * accumulates signatures into a per-candidate consensus record, and
 * flips gate_status to parallax_approved once real quorum is met.
 *
 * NOT a chokidar daemon — run by hand:
 *
 *   node infra/collate_parallax.js
 *
 * Receipt files: one file per node response, YAML or JSON, any filename,
 * dropped into 05_From_Parallax/. NEW DEPENDENCY: this script needs
 * js-yaml to parse the YAML receipts nodes actually send (RFC-003 §2's
 * examples are YAML) — run `npm install js-yaml` before first use.
 * promoted-to-parallax.js's outbound manifest stays JSON (see that
 * file's header) since nothing there needs to be human-typed by a node;
 * receipts DO need YAML support because that's the format the Alliance
 * is actually replying in.
 *
 * QUORUM RULE (founder's ruling, parallax-schema thread):
 *   - At least 2 DISTINCT allow-listed MACHINE-node signatures with
 *     verdict parallax_approved for the same (candidate_id,
 *     parallax_batch_id), AND
 *   - Node M's own sign-off (prompted interactively below — the CLI
 *     equivalent of "my mouse click"), AND
 *   - ZERO outstanding `amend` signatures from any allow-listed node,
 *     present now or arriving later (dissent holds the gate — P4,
 *     intentional, not a bug).
 *
 * parallax_declined is NOT a machine-returnable verdict (RFC-003 §3) —
 * this script has no code path that writes it. That value is reserved
 * exclusively for the founder's own manual veto (deleting an item from
 * 03_Promoted/ or 06_References/ by hand), outside this script entirely.
 *
 * On promotion: this script ONLY flips gate_status to parallax_approved
 * on the file in place in 03_Promoted/ — it does NOT move the file.
 * promote-to-references.js (the existing daemon) already watches
 * 03_Promoted/ for exactly that gate_status value and performs the move
 * to 06_References/ itself (§5.8). Reusing that machinery instead of
 * duplicating a second move implementation here. If that daemon isn't
 * running when this script flips the flag, the item just waits — same
 * as everywhere else in the pipeline that depends on a watcher being up.
 *
 * Post-promotion dissent: an amend arriving for a candidate that's
 * already left 03_Promoted/ (i.e. already promoted) does NOT revert
 * anything automatically. It's still logged to the consensus ledger and
 * printed as a loud flag for the founder's attention (RFC-003 §5 —
 * promotion isn't terminal, a ledgered claim stays actionable).
 */

const fs = require('fs');
const path = require('path');
const grayMatter = require('gray-matter');
const readline = require('readline');

let yaml;
try {
  yaml = require('js-yaml');
} catch (err) {
  console.error('❌ [Missing Dependency] js-yaml is required to parse incoming receipts.');
  console.error('   Run: npm install js-yaml');
  process.exit(1);
}

const PROMOTED_DIR = path.join(__dirname, '../03_Promoted');
const TO_PARALLAX_DIR = path.join(__dirname, '../04_To_Parallax');
const FROM_PARALLAX_DIR = path.join(__dirname, '../05_From_Parallax');
const PROCESSED_DIR = path.join(FROM_PARALLAX_DIR, '.processed');
const AMENDMENTS_DIR = path.join(PROMOTED_DIR, '.amendments');
const LEDGER_PATH = path.join(PROMOTED_DIR, '.parallax-ledger.json');
const ALLIANCE_PATH = path.join(__dirname, '../_local/alliance-members.json');

const FOUNDER_NODE_ID = 'Node M';
const MACHINE_QUORUM_MIN = 2;

// ---------- Setup / loaders ----------

function loadAllianceAllowlist() {
  if (!fs.existsSync(ALLIANCE_PATH)) {
    console.error(`❌ [Allowlist Missing] Expected ${ALLIANCE_PATH} — nothing can be validated without it.`);
    process.exit(1);
  }
  const parsed = JSON.parse(fs.readFileSync(ALLIANCE_PATH, 'utf8'));
  const byId = new Map();
  for (const member of parsed.members || []) {
    byId.set(member.node_id, member);
  }
  return byId;
}

function loadLedger() {
  if (!fs.existsSync(LEDGER_PATH)) return { batches: {}, consensus: {} };
  try {
    const parsed = JSON.parse(fs.readFileSync(LEDGER_PATH, 'utf8'));
    parsed.batches = parsed.batches || {};
    parsed.consensus = parsed.consensus || {};
    return parsed;
  } catch (err) {
    console.error(`⚠️ [Ledger] Failed to parse ${path.basename(LEDGER_PATH)} — refusing to overwrite it blindly:`, err.message);
    throw err;
  }
}

function saveLedger(ledger) {
  fs.writeFileSync(LEDGER_PATH, JSON.stringify(ledger, null, 2), 'utf8');
}

function loadManifest(batchId) {
  const manifestPath = path.join(TO_PARALLAX_DIR, `${batchId}.json`);
  if (!fs.existsSync(manifestPath)) return null;
  try {
    return JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  } catch (err) {
    console.error(`⚠️ [Manifest] Failed to parse ${manifestPath}:`, err.message);
    return null;
  }
}

function parseReceiptFile(filePath) {
  const raw = fs.readFileSync(filePath, 'utf8');
  if (filePath.endsWith('.json')) return JSON.parse(raw);
  return yaml.load(raw);
}

function consensusKey(candidateId, batchId) {
  return `${candidateId}::${batchId}`;
}

// ---------- Validation ----------

function validateReceiptItem(item, receipt, allowlist, manifestCache) {
  const problems = [];

  const member = allowlist.get(receipt.reviewing_node);
  if (!member) {
    problems.push(`reviewing_node "${receipt.reviewing_node}" is not on the Node Alliance allowlist`);
    return { valid: false, problems, member: null };
  }

  if (!manifestCache.has(item.parallax_batch_id)) {
    manifestCache.set(item.parallax_batch_id, loadManifest(item.parallax_batch_id));
  }
  const manifest = manifestCache.get(item.parallax_batch_id);

  if (!manifest) {
    problems.push(`no outbound manifest found for parallax_batch_id "${item.parallax_batch_id}"`);
    return { valid: false, problems, member };
  }

  const manifestItem = (manifest.items || []).find(m => m.candidate_id === item.candidate_id);
  if (!manifestItem) {
    problems.push(`candidate_id "${item.candidate_id}" not found in manifest for batch "${item.parallax_batch_id}"`);
    return { valid: false, problems, member };
  }

  if (manifest.blindness_tier !== item.blindness_tier_evaluated) {
    problems.push(`blindness_tier_evaluated (${item.blindness_tier_evaluated}) does not match the tier this batch was actually sent under (${manifest.blindness_tier})`);
    return { valid: false, problems, member };
  }

  return { valid: true, problems: [], member };
}

// ---------- Consensus accounting ----------

function recordSignature(ledger, item, receipt, member) {
  const key = consensusKey(item.candidate_id, item.parallax_batch_id);
  if (!ledger.consensus[key]) {
    ledger.consensus[key] = { candidate_id: item.candidate_id, parallax_batch_id: item.parallax_batch_id, signatures: [] };
  }
  const record = ledger.consensus[key];

  const alreadyRecorded = record.signatures.some(
    s => s.reviewing_node === receipt.reviewing_node && s.verdict === item.verdict
  );
  if (alreadyRecorded) {
    console.log(`   ⏭️  Duplicate signature ignored (${receipt.reviewing_node}, ${item.verdict}) — already recorded.`);
    return record;
  }

  record.signatures.push({
    reviewing_node: receipt.reviewing_node,
    node_type: member.type,
    verdict: item.verdict,
    reasoning: item.reasoning || null,
    proposed_amendment: item.proposed_amendment || null,
    deduced_axiom: item.deduced_axiom || null,
    deduced_ddc: item.deduced_ddc || null,
    timestamp: receipt.timestamp || new Date().toISOString()
  });

  if (item.verdict === 'amend') {
    if (!fs.existsSync(AMENDMENTS_DIR)) fs.mkdirSync(AMENDMENTS_DIR, { recursive: true });
    const amendPath = path.join(AMENDMENTS_DIR, `${item.candidate_id}--${item.parallax_batch_id}--${receipt.reviewing_node}.json`);
    fs.writeFileSync(amendPath, JSON.stringify(record.signatures[record.signatures.length - 1], null, 2), 'utf8');
    console.log(`   📝 [Amendment Logged] ${path.basename(amendPath)}`);
  }

  return record;
}

function hasOutstandingDissent(record) {
  return record.signatures.some(s => s.verdict === 'amend');
}

function distinctMachineApprovals(record, allowlist) {
  const nodes = new Set();
  for (const s of record.signatures) {
    if (s.verdict === 'parallax_approved' && s.node_type === 'machine') nodes.add(s.reviewing_node);
  }
  return nodes;
}

function founderHasApproved(record) {
  return record.signatures.some(s => s.reviewing_node === FOUNDER_NODE_ID && s.verdict === 'parallax_approved');
}

function findPromotedFilePath(candidateId) {
  const candidatePath = path.join(PROMOTED_DIR, `${candidateId}.md`);
  return fs.existsSync(candidatePath) ? candidatePath : null;
}

function promoteCandidate(candidateId) {
  const filePath = findPromotedFilePath(candidateId);
  if (!filePath) {
    console.log(`   ⚠️  [Post-Promotion] "${candidateId}" already left 03_Promoted/ — quorum reached but nothing to flip. If this is a late approval after prior promotion, no action needed.`);
    return;
  }
  const parsed = grayMatter(fs.readFileSync(filePath, 'utf8'));
  const updated = { ...parsed.data, gate_status: 'parallax_approved', parallax_approved_at: new Date().toISOString() };
  fs.writeFileSync(filePath, grayMatter.stringify(parsed.content.trim(), updated), 'utf8');
  console.log(`   ✅ [Gate Flipped] ${candidateId} → gate_status: parallax_approved (promote-to-references.js will pick this up).`);
}

async function promptFounderSignoff(candidateId, machineApprovals) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(resolve => {
    rl.question(
      `\n🗳️  "${candidateId}" has ${machineApprovals.size} allow-listed machine approval(s) [${[...machineApprovals].join(', ')}] and zero dissent.\n   Approve for promotion? [y/N]: `,
      answer => {
        rl.close();
        resolve(answer.trim().toLowerCase() === 'y');
      }
    );
  });
}

// ---------- Main ----------

async function main() {
  if (!fs.existsSync(FROM_PARALLAX_DIR)) {
    console.error('❌ 05_From_Parallax/ does not exist.');
    process.exit(1);
  }
  if (!fs.existsSync(PROCESSED_DIR)) fs.mkdirSync(PROCESSED_DIR, { recursive: true });

  const allowlist = loadAllianceAllowlist();
  const ledger = loadLedger();
  const manifestCache = new Map();

  const receiptFiles = fs.readdirSync(FROM_PARALLAX_DIR)
    .filter(name => (name.endsWith('.yaml') || name.endsWith('.yml') || name.endsWith('.json')));

  if (receiptFiles.length === 0) {
    console.log('ℹ️  No new receipt files in 05_From_Parallax/.');
  }

  const touchedCandidates = new Set();

  for (const fileName of receiptFiles) {
    const filePath = path.join(FROM_PARALLAX_DIR, fileName);
    let parsedDoc;
    try {
      parsedDoc = parseReceiptFile(filePath);
    } catch (err) {
      console.error(`❌ [Parse Error] ${fileName}: ${err.message} — left in place, not processed.`);
      continue;
    }

    const receipt = parsedDoc.rfc_receipt;
    if (!receipt || !Array.isArray(receipt.responses)) {
      console.error(`❌ [Format Error] ${fileName} does not look like an RFC-003 rfc_receipt document — left in place, not processed.`);
      continue;
    }

    console.log(`\n📨 Processing ${fileName} (reviewing_node: ${receipt.reviewing_node})`);

    for (const item of receipt.responses) {
      const { valid, problems, member } = validateReceiptItem(item, receipt, allowlist, manifestCache);
      if (!valid) {
        console.error(`   ❌ [Rejected] ${item.candidate_id || '?'}: ${problems.join('; ')}`);
        continue;
      }

      recordSignature(ledger, item, receipt, member);
      touchedCandidates.add(consensusKey(item.candidate_id, item.parallax_batch_id));
      console.log(`   ✅ Recorded ${item.verdict} from ${receipt.reviewing_node} for ${item.candidate_id}`);
    }

    fs.renameSync(filePath, path.join(PROCESSED_DIR, fileName));
  }

  saveLedger(ledger);

  if (touchedCandidates.size === 0) {
    console.log('\nℹ️  Nothing new to evaluate for quorum.');
    return;
  }

  console.log('\n— Quorum check —');
  for (const key of touchedCandidates) {
    const record = ledger.consensus[key];
    const candidateId = record.candidate_id;

    if (hasOutstandingDissent(record)) {
      const dissenters = record.signatures.filter(s => s.verdict === 'amend').map(s => s.reviewing_node);
      console.log(`⛔ "${candidateId}" — held by dissent from: ${dissenters.join(', ')}. Remains parallax_pending.`);
      continue;
    }

    const machineApprovals = distinctMachineApprovals(record, allowlist);
    if (machineApprovals.size < MACHINE_QUORUM_MIN) {
      console.log(`⏳ "${candidateId}" — ${machineApprovals.size}/${MACHINE_QUORUM_MIN} machine approvals so far. Not yet eligible.`);
      continue;
    }

    if (founderHasApproved(record)) {
      promoteCandidate(candidateId);
      continue;
    }

    const approved = await promptFounderSignoff(candidateId, machineApprovals);
    if (approved) {
      record.signatures.push({
        reviewing_node: FOUNDER_NODE_ID,
        node_type: 'human',
        verdict: 'parallax_approved',
        reasoning: 'Founder manual sign-off (CLI confirmation).',
        timestamp: new Date().toISOString()
      });
      saveLedger(ledger);
      promoteCandidate(candidateId);
    } else {
      console.log(`   ⏸️  Skipped — "${candidateId}" left at parallax_pending pending your sign-off.`);
    }
  }

  saveLedger(ledger);
  console.log('\n✅ Collation run complete.');
}

main().catch(err => {
  console.error('❌ Fatal error:', err.message);
  process.exit(1);
});
