require('dotenv').config();

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const chokidar = require('chokidar');
const grayMatter = require('gray-matter');
const Ajv = require('ajv');
const { acquireSingleInstanceLock } = require('./lib/single-instance-lock');
const { manifestSummary, loadReferenceDoc, findManifestEntry } = require('./lib/reference-manifest');
const { ALWAYS_ON_TRAINING } = require('./lib/pipeline-mode');

const ajv = new Ajv({ allErrors: true });

// 1. PATH GEOGRAPHY
// Independent daemon — deliberately NOT required by or coupled to
// inbox-to-candidate.js or candidate-to-promoted.js. Watches 02_Candidate/
// directly, same as the Exterior gate does, but with a different job.
const CANDIDATE_DIR = path.join(__dirname, '../02_Candidate');

// 2. SUBSTRATE CONFIG
// Same substrate as candidate-to-promoted.js, deliberately duplicated here
// rather than shared — this script is meant to work standalone even if the
// Exterior-gate script is mid-refactor or temporarily down.
const CORE_AGENT_KEY = process.env.CORE_AGENT_KEY;
const CORE_AGENT_MODEL = process.env.CORE_AGENT_MODEL;
const CORE_AGENT_ENDPOINT = process.env.CORE_AGENT_ENDPOINT;

if (!CORE_AGENT_KEY || !CORE_AGENT_MODEL || !CORE_AGENT_ENDPOINT) {
  console.error("❌ [Config Error] Missing required CORE_AGENT_* environment variables.");
  process.exit(1);
}

const SUBSTRATE_MAX_ATTEMPTS = parseInt(process.env.SUBSTRATE_MAX_ATTEMPTS || '4', 10);
const SUBSTRATE_BASE_DELAY_MS = parseInt(process.env.SUBSTRATE_BASE_DELAY_MS || '1000', 10);
const RETRYABLE_STATUS_CODES = new Set([429, 500, 502, 503, 504]);
const MAX_CASCADE_ROUNDS = parseInt(process.env.PROMOTION_HELPER_MAX_ROUNDS || '3', 10);

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

acquireSingleInstanceLock(path.join(__dirname, '.promotion-helper.lock'), 'promotion-helper.js');

// 3. SCHEMA — cascade round response
// The model is unreliable input; every round's output is deterministically
// validated before we act on it, same principle as the Exterior gate's
// verification-receipt schema.
const cascadeRoundSchema = {
  type: "object",
  properties: {
    action: { type: "string", enum: ["REQUEST_DOCS", "CONCLUDE"] },
    requested_docs: { type: "array", items: { type: "string" } },
    reasoning: { type: "string" },
    conclusion: { type: "string" }
  },
  required: ["action", "reasoning"],
  additionalProperties: false
};
const validateCascadeRound = ajv.compile(cascadeRoundSchema);

// 4. PIPELINE SERIALIZATION (same pattern as candidate-to-promoted.js)
let pipelineQueue = Promise.resolve();
function queuePipelineAction(actionFn) {
  pipelineQueue = pipelineQueue.then(async () => {
    try { await actionFn(); }
    catch (err) { console.error("❌ Promotion-Helper Pipeline Fault:", err.message); }
  });
  return pipelineQueue;
}

// 5. DETERMINISTIC HELPERS
function computeSha256(content) {
  return crypto.createHash('sha256').update(content, 'utf8').digest('hex');
}

// 6. SUBSTRATE CALL (retry/backoff — same shape as candidate-to-promoted.js)
async function callSubstrate(promptText) {
  async function fetchWithRetry() {
    let lastError;

    for (let attempt = 1; attempt <= SUBSTRATE_MAX_ATTEMPTS; attempt++) {
      try {
        const response = await fetch(CORE_AGENT_ENDPOINT, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${CORE_AGENT_KEY}`
          },
          body: JSON.stringify({
            model: CORE_AGENT_MODEL,
            messages: [{ role: 'user', content: promptText }],
            temperature: 0.1
          })
        });

        if (!response.ok) {
          const err = new Error(`HTTP ${response.status}`);
          err.status = response.status;
          throw err;
        }

        return response;
      } catch (error) {
        lastError = error;
        const isRetryableStatus = typeof error.status === 'number' && RETRYABLE_STATUS_CODES.has(error.status);
        const isNetworkThrow = typeof error.status !== 'number';
        const isLastAttempt = attempt === SUBSTRATE_MAX_ATTEMPTS;

        if ((isRetryableStatus || isNetworkThrow) && !isLastAttempt) {
          const delayMs = SUBSTRATE_BASE_DELAY_MS * Math.pow(2, attempt - 1) + Math.floor(Math.random() * 250);
          console.warn(`⚠️ [Cascade] Substrate call failed (attempt ${attempt}/${SUBSTRATE_MAX_ATTEMPTS}): ${error.message}. Retrying in ${delayMs}ms...`);
          await sleep(delayMs);
          continue;
        }
        throw lastError;
      }
    }
    throw lastError;
  }

  const response = await fetchWithRetry();
  const rawText = (await response.text()).trim();
  let innerContent = JSON.parse(rawText).choices?.[0]?.message?.content?.trim() || '';

  if (innerContent.startsWith("```")) {
    innerContent = innerContent.replace(/^```json\s*/i, "").replace(/```$/, "").trim();
  }

  return JSON.parse(innerContent);
}

// 7. CASCADE PROMPT CONSTRUCTION
function buildCascadePrompt(candidateBody, providedDocs, roundNumber) {
  const providedSection = Object.keys(providedDocs).length === 0
    ? '(none yet)'
    : Object.entries(providedDocs).map(([id, content]) => `--- DOCUMENT "${id}" ---\n${content}`).join('\n\n');

  const providedIds = new Set(Object.keys(providedDocs));
  const remainingManifest = manifestSummary()
    .split('\n')
    .filter(line => {
      const match = line.match(/^- "([^"]+)"/);
      return !(match && providedIds.has(match[1]));
    })
    .join('\n');

  return `You are assisting an Interior-mode (non-gating, exploratory) training pass on a Temetics Candidate document that has FAILED the real Exterior gate at least once.

This is NOT a verification pass. Nothing you say here promotes or rejects anything. Your only job is diagnostic: figure out what reference material, if any, would actually let a competent Exterior-gate reviewer resolve this candidate — and say so plainly.

This is round ${roundNumber} of at most ${MAX_CASCADE_ROUNDS}.

### CANDIDATE DOCUMENT
${candidateBody}

### DOCUMENTS ALREADY PROVIDED TO YOU
${providedSection}

### OTHER DOCUMENTS AVAILABLE (request by exact id if you need one)
${remainingManifest || '(none remaining — all manifest documents already provided)'}

### INSTRUCTIONS
1. Only request a document if you have a specific, statable reason to think it's relevant. Do not request documents speculatively "just in case."
2. If you already have enough to state clearly what the actual gap is and what would bridge it, conclude — do not request more documents just because rounds remain.
3. Return ONLY valid JSON. No extra text.

{
  "action": "REQUEST_DOCS" | "CONCLUDE",
  "requested_docs": ["exact-id-from-list", "..."],
  "reasoning": "why you're requesting these specific documents, or why you're ready to conclude",
  "conclusion": "if action is CONCLUDE: a plain-language statement of what the actual gap is and which reference material (if any) bridges it. Omit or leave empty if action is REQUEST_DOCS."
}`;
}

// 8. RUN THE CASCADE FOR ONE CANDIDATE
async function runCascade(candidateBody) {
  const providedDocs = {};
  const roundLog = [];
  let finalConclusion = null;
  let concluded = false;

  for (let round = 1; round <= MAX_CASCADE_ROUNDS; round++) {
    const prompt = buildCascadePrompt(candidateBody, providedDocs, round);
    let roundResult;

    try {
      roundResult = await callSubstrate(prompt);
    } catch (error) {
      console.error(`❌ [Cascade] Round ${round} substrate call failed: ${error.message}`);
      roundLog.push({ round, error: error.message });
      break; // Transport failure — stop the cascade, don't guess.
    }

    if (!validateCascadeRound(roundResult)) {
      console.warn(`⚠️ [Cascade] Round ${round} returned malformed JSON — treating as a stalled round, not retrying.`);
      roundLog.push({ round, error: 'Schema validation failed', raw: roundResult });
      break;
    }

    if (roundResult.action === 'CONCLUDE') {
      roundLog.push({ round, action: 'CONCLUDE', reasoning: roundResult.reasoning, conclusion: roundResult.conclusion });
      finalConclusion = roundResult.conclusion || roundResult.reasoning;
      concluded = true;
      break;
    }

    // action === 'REQUEST_DOCS'
    const requestedIds = Array.isArray(roundResult.requested_docs) ? roundResult.requested_docs : [];
    const newlyLoaded = [];

    for (const id of requestedIds) {
      if (providedDocs[id]) continue; // already have it
      const entry = findManifestEntry(id);
      if (!entry) {
        console.warn(`⚠️ [Cascade] Model requested unknown doc id "${id}" — ignoring.`);
        continue;
      }
      const content = loadReferenceDoc(id);
      if (content !== null) {
        providedDocs[id] = content;
        newlyLoaded.push(id);
      }
    }

    roundLog.push({ round, action: 'REQUEST_DOCS', requested: requestedIds, loaded: newlyLoaded, reasoning: roundResult.reasoning });

    if (newlyLoaded.length === 0) {
      // Requested nothing new and nothing valid — stagnant round, stop rather
      // than spend further rounds/tokens on a loop that isn't progressing.
      console.warn(`⚠️ [Cascade] Round ${round} requested no new, valid documents — ending cascade early.`);
      break;
    }
  }

  if (!concluded) {
    roundLog.push({ note: `Cascade ended without an explicit CONCLUDE after ${roundLog.length} round(s).` });
  }

  return {
    providedDocIds: Object.keys(providedDocs),
    roundLog,
    conclusion: finalConclusion,
    // Bug #3 fix: `concluded` is already exactly the signal needed to tell
    // a confident CONCLUDE from a forced stop (round cap exhausted,
    // stagnant round, malformed JSON, or transport failure) — all of which
    // mean training_reference_docs may be an incomplete set the model
    // itself hadn't finished exploring. Threaded through to frontmatter as
    // cascade_incomplete so candidate-to-promoted.js can act on it.
    cascadeIncomplete: !concluded
  };
}

// 9. CANDIDATE FILE EDITS
// Answers "what edits are made, and why": promotion-helper.js touches exactly
// three things in a candidate file — (a) frontmatter status (training ->
// ready), (b) a new frontmatter field recording which reference docs the
// cascade actually used (training_reference_docs), consumed later by
// candidate-to-promoted.js's Exterior-gate call, and (c) an appended
// Cascade Training Log under the template's existing Section 6 (Interior
// mode output), which is explicitly "purely informational, never affects
// file status" per Templates/candidate.md — this script does not touch
// Sections 2-5 or 7 (raw claim, restatement, round-trip check, axiom scan,
// Exterior gate outcome), all of which are Exterior-gate/human territory.
function injectSection6Log(body, cascadeResult) {
  const timestamp = new Date().toISOString();
  const logBlock = [
    '',
    `### Cascade Training Log (${timestamp})`,
    '',
    `- Documents consulted: ${cascadeResult.providedDocIds.length ? cascadeResult.providedDocIds.join(', ') : '(none — model concluded no additional reference material was needed)'}`,
    `- Conclusion: ${cascadeResult.conclusion || '(cascade ended without an explicit conclusion — see raw round log)'}`,
    ''
  ].join('\n');

  // Insert right before "## Section 7" if present, else append to end of file.
  const section7Marker = '## Section 7';
  const idx = body.indexOf(section7Marker);
  if (idx === -1) {
    return body.trimEnd() + '\n' + logBlock;
  }
  return body.slice(0, idx) + logBlock + '\n---\n\n' + body.slice(idx);
}

// 10. ENTRY CRITERION — which candidates get picked up for training
// Three ways in, checked in order:
//   (a) frontmatter.status === 'training' -> never (concurrency guard)
//   (b) frontmatter.training_completed_at already set -> never (don't
//       auto-retrain; a re-run has to be asked for explicitly, not implied
//       by a file-change event)
//   (c) frontmatter.training_reference_docs already set BY HAND (e.g. a
//       founder edit in Obsidian) with no training_completed_at yet -> ALWAYS
//       pick up, regardless of ALWAYS_ON_TRAINING or failed-log state. This
//       is an explicit founder instruction, not a discovery job — see
//       evaluateForTraining's manual-pin branch, which skips the cascade
//       entirely and just stamps the founder's chosen docs.
//   (d) ALWAYS_ON_TRAINING -> pick up any untrained candidate
//   (e) otherwise (reactive-only mode) -> pick up only if a real Exterior-
//       gate rejection already happened (.validation-failed.log exists)
function shouldTrain(filePath, frontmatter) {
  if (frontmatter.status === 'training') return false;
  if (frontmatter.training_completed_at) return false;

  const hasManualPin = Array.isArray(frontmatter.training_reference_docs) && frontmatter.training_reference_docs.length > 0;
  if (hasManualPin) return true;

  if (ALWAYS_ON_TRAINING) return true;

  const failedLogPath = filePath.replace(/\.md$/, '.validation-failed.log');
  return fs.existsSync(failedLogPath);
}

// 11. PIPELINE EXECUTION
async function evaluateForTraining(filePath) {
  await queuePipelineAction(async () => {
    if (!fs.existsSync(filePath)) return;

    const fileContent = fs.readFileSync(filePath, 'utf8');
    const parsedFile = grayMatter(fileContent);
    const { data: frontmatter } = parsedFile;
    const body = parsedFile.content;

    if (!shouldTrain(filePath, frontmatter)) return;

    // Claim the file immediately so candidate-to-promoted.js's precondition
    // (skip anything with status: training) takes effect before any
    // substrate round-trips happen — this is the concurrency-safety
    // mechanism, not an afterthought.
    const claimedFrontmatter = { ...frontmatter, status: 'training' };
    fs.writeFileSync(filePath, grayMatter.stringify(body, claimedFrontmatter), 'utf8');

    const hasManualPin = Array.isArray(frontmatter.training_reference_docs) && frontmatter.training_reference_docs.length > 0;

    if (hasManualPin) {
      // Founder already told us which docs matter (e.g. edited frontmatter
      // directly in Obsidian) — the cascade's whole job is DISCOVERING that;
      // if it's already known, skip discovery, validate the ids against the
      // manifest, and just stamp it. No substrate calls, no cost.
      console.log(`📌 [Training] Manual reference-doc pin found on ${path.basename(filePath)}: ${frontmatter.training_reference_docs.join(', ')} — skipping cascade, honoring as-is.`);

      const validIds = frontmatter.training_reference_docs.filter(id => {
        const entry = findManifestEntry(id);
        if (!entry) console.warn(`⚠️ [Training] Manually-pinned doc id "${id}" not found in manifest — dropping it.`);
        return !!entry;
      });

      const manualResult = {
        providedDocIds: validIds,
        roundLog: [{ note: 'Founder-specified manual override — cascade not run.' }],
        conclusion: `Reference documents manually specified by founder: ${validIds.join(', ') || '(none valid)'}.`
      };

      const newBody = injectSection6Log(body, manualResult);
      const newHash = computeSha256(newBody.trim());
      const finalFrontmatter = {
        ...frontmatter,
        status: 'ready',
        raw_content_sha256: newHash,
        training_reference_docs: validIds,
        training_completed_at: new Date().toISOString(),
        cascade_incomplete: false
      };
      fs.writeFileSync(filePath, grayMatter.stringify(newBody, finalFrontmatter), 'utf8');

      const failedLogPath = filePath.replace(/\.md$/, '.validation-failed.log');
      if (fs.existsSync(failedLogPath)) fs.unlinkSync(failedLogPath);

      console.log(`✅ [Training] Manual pin honored on ${path.basename(filePath)}. Status -> ready.`);
      return;
    }

    console.log(`🎓 [Training] Starting Interior-mode cascade on ${path.basename(filePath)}...`);

    const cascadeResult = await runCascade(body.trim());

    const newBody = injectSection6Log(body, cascadeResult);
    const newHash = computeSha256(newBody.trim());

    const finalFrontmatter = {
      ...frontmatter,
      status: 'ready',
      raw_content_sha256: newHash,
      training_reference_docs: cascadeResult.providedDocIds,
      training_completed_at: new Date().toISOString(),
      cascade_incomplete: cascadeResult.cascadeIncomplete
    };

    fs.writeFileSync(filePath, grayMatter.stringify(newBody, finalFrontmatter), 'utf8');

    // Write the full round-by-round audit trail alongside the file — this is
    // the "which document was actually load-bearing" signal the ablation
    // testing plan depends on, separate from the human-readable Section 6
    // summary baked into the file itself.
    const auditLogPath = filePath.replace(/\.md$/, '.training-cascade.log');
    fs.writeFileSync(auditLogPath, JSON.stringify(cascadeResult, null, 2), 'utf8');

    // Self-resetting retrigger guard: clear the failure marker that got this
    // candidate picked up. If it fails the Exterior gate again after
    // re-review with the new training_reference_docs, candidate-to-
    // promoted.js will recreate a fresh .validation-failed.log and this
    // daemon will pick it up again on its own.
    const failedLogPath = filePath.replace(/\.md$/, '.validation-failed.log');
    if (fs.existsSync(failedLogPath)) fs.unlinkSync(failedLogPath);

    console.log(`✅ [Training] Cascade complete on ${path.basename(filePath)}. Docs used: ${cascadeResult.providedDocIds.join(', ') || '(none)'}. Status -> ready.${cascadeResult.cascadeIncomplete ? ' ⚠️ cascade_incomplete: true (stopped without an explicit CONCLUDE).' : ''}`);
  });
}

// 12. DAEMON
const watcher = chokidar.watch(CANDIDATE_DIR, {
  persistent: true,
  ignoreInitial: false,
  awaitWriteFinish: { stabilityThreshold: 600, pollInterval: 100 }
});

const NON_CANDIDATE_FILENAMES = new Set(['README.md']);

watcher.on('all', (event, filePath) => {
  if (filePath.endsWith('.md') && (event === 'add' || event === 'change')) {
    const baseName = path.basename(filePath);
    if (NON_CANDIDATE_FILENAMES.has(baseName)) return;
    evaluateForTraining(filePath);
  }
});

console.log('🚀 Promotion-Helper (Interior training cascade) v0.2.0 Active. Monitoring 02_Candidate...');
