# infra/_provenance.md

The second of the two provenance registers Manifesto v4.0 §8 requires —
this one covers every file in `infra/`, the Controller daemons and
shared libraries that constitute the pipeline itself. Same shared
schema as `skills/_provenance.md`. A file here without a row is formally
untrusted regardless of how long it's been running correctly.

Per §8's infra-specific translation: `deterministic`/`idempotent`/
`side-effect-free` apply as written. `requires-interpretation` is
declared per the *actual code*, not assumed `false` by default — see
the correction note below, since the manifesto text itself turned out
to be wrong about which scripts call the substrate.

**Correction found this pass:** §8 states "none of the pipeline scripts
invoke an LLM directly, with one explicit exception: `promotion-
helper.js`." That's inaccurate against the code as shipped in v0.9.8 —
`inbox-to-candidate.js` and `candidate-to-promoted.js` both make direct
substrate calls too (candidate classification/tagging, and the P6
correspondence verification, respectively). Only `promote-to-
references.js` and the four `infra/lib/` files are substrate-free.
`requires-interpretation` below reflects the code, not the manifesto
sentence; the manifesto text needs a v4.1 correction to match.

## Pipeline daemons (persistent, chokidar-watched)

| File | Provenance | Write-scope | Deterministic | Idempotent | Side-effect-free | Requires-interpretation | Authority-level | Source |
|---|---|---|---|---|---|---|---|---|
| `capture-inbox-item.js` | native | `01_Inbox/` only | Yes | No — each invocation appends a new sequenced file by design; not a re-run-safe no-op | Yes | false | Autonomous, one-shot CLI, no sign-off | this build |
| `capture-obsidian-stub.js` | native | reads/removes root-level `.md` files at vault-root depth 0 (excluding `README.md`, `AGENTS.md`, `AGENTS.md_old`); writes into `01_Inbox/` | Yes | Yes — a duplicate chokidar event on an already-captured file is a no-op via `existsSync` guard | Yes, within its two declared scopes | false | Autonomous, always-on watcher, no sign-off | this build |
| `inbox-to-candidate.js` | native | `02_Candidate/`; `02_Candidate/.ingestion-ledger.json` (relocated this session — see workbench notes); `lexicons/workspace-lexicon.json` | **No** — makes a direct substrate call for candidate classification/tagging | Partial — the P6 hash-dedup check (`.ingestion-ledger.json`) blocks re-creating a duplicate candidate from unchanged content, but the substrate call itself isn't guaranteed identical output on repeat | Yes, substrate call is within the task's own purpose, not an undeclared side channel | **true** (corrects §8's blanket claim — see note above) | Autonomous within scope; substrate output isn't founder-reviewed before a candidate file is written | this build |
| `candidate-to-promoted.js` | native | `02_Candidate/` (in place, on decline); `03_Promoted/` (on success, via move) | **No** — makes a direct substrate call for the P6 correspondence verdict (CONSISTENT/INCONSISTENT/UNDERDETERMINED) | Yes, as of this session's fix — gated on `gate_status` vs. `training_completed_at`/`local_gate_declined_at` comparison, not a blanket "already touched" skip (see workbench notes for the regression this replaced) | Yes | **true** (corrects §8's blanket claim — see note above) | Autonomous within scope; the gate's verdict is exactly the thing Alliance parallax exists to independently re-check — this script's authority is "move the file," never "the claim is true" | this build |
| `promotion-helper.js` | native | `02_Candidate/` (in place — rewrites frontmatter + appends cascade log to body) | No — explicit exception, matches §8's own stated exemption for this file | Guarded by `training_completed_at`/manual-pin/`ALWAYS_ON_TRAINING` logic; a genuine no-op re-trigger is skipped, a founder-pinned or reactively-triggered re-run is not | Yes | **true** (this one matches the manifesto's own stated exception) | Autonomous within scope; a manual `training_reference_docs` pin is the one explicit founder-authority lever this script honors | this build |
| `promoted-to-parallax.js` | native | `04_To_Parallax/` (writes batch manifest, atomically); `03_Promoted/` (in-place frontmatter rewrite — flips `awaiting_parallax` to false on each selected item, before the manifest is written); `03_Promoted/.parallax-ledger.json` (writes batch record) | Yes — no substrate call; pure frontmatter read + allow-list field construction (`buildItemPayload()`) + hashing. Prompts the founder inline for an optional `founder_directive`, human input, not model output | Yes for the manifest itself (atomic temp-file + rename — either fully exists or doesn't). Not fully atomic end-to-end across the frontmatter-flip-then-manifest-write boundary, but reordered so an interruption there fails safe: a lost batch (recoverable, re-run re-selects it), never a duplicate send under a second batch id | Yes, within its declared write-scope (`04_To_Parallax/`, `03_Promoted/` frontmatter, the parallax ledger) | false | Autonomous within scope; the one human input it takes is the optional `founder_directive` — it never asks whether to send the batch, that's implicit in which items are already flagged `awaiting_parallax: true` beforehand | this build |
| `collate_parallax.js` | native | `05_From_Parallax/` (reads receipts, moves processed ones into `05_From_Parallax/.processed/`); `03_Promoted/.parallax-ledger.json` (writes consensus signatures); `03_Promoted/.amendments/` (writes one file per `amend` verdict); `03_Promoted/` (in-place frontmatter rewrite — flips `gate_status` to `parallax_approved` on quorum; never moves the file itself, see below) | Yes — no substrate call; pure allowlist/manifest cross-check and deterministic quorum counting (≥2 distinct machine approvals + zero dissent + founder sign-off, fixed rule, not model judgment) | Partial — `recordSignature()` explicitly detects and skips an exact duplicate `(reviewing_node, verdict)` pair before appending, so reprocessing the same receipt content doesn't double-count. Belt-and-suspenders only: processed receipts are moved out of `05_From_Parallax/` after handling, so a normal re-run has nothing left to find | Yes, within its declared write-scope — notably, it flips `gate_status` but does **not** perform the `03_Promoted/` → `06_References/` move itself; that's left entirely to `promote-to-references.js` picking up the flag, deliberately not duplicated here | false | Autonomous up to the quorum threshold; requires the founder's own interactive CLI sign-off before `gate_status` is ever flipped — a hard block, not an override: 2+ machine approvals and zero dissent alone are not sufficient. `parallax_declined` is not a verdict this script can write at all — reserved exclusively for a separate manual founder action | this build |
| `promote-to-references.js` | native | `06_References/` (writes); `03_Promoted/` (removes source, on move); `03_Promoted/.promotion-ledger.json` | Yes — no substrate call, pure frontmatter-field check and file move | Yes — file existence at the source path is the guard; a retry after an interrupted move is a safe no-op via the ledger's hash-keyed dedup | Yes | false | Autonomous within scope; `gate_status: parallax_approved` itself is founder-set by hand today (dragging the file into the Alliance tabs), so this script's authority begins only after that human act, not before | this build |

## Shared libraries (`infra/lib/`, imported by the daemons above — no independent write-scope of their own)

| File | Provenance | Write-scope | Deterministic | Idempotent | Side-effect-free | Requires-interpretation | Authority-level | Source |
|---|---|---|---|---|---|---|---|---|
| `lib/ddc.js` | native | none — pure functions, no I/O | Yes | Yes (explicitly documented — "safe to call on values that are already normalized") | Yes | false | N/A — has no independent authority; runs inside whichever daemon imports it | this build |
| `lib/pipeline-mode.js` | native | none — exports one constant | Yes | Yes | Yes | false | N/A — a single founder-set flip point (`ALWAYS_ON_TRAINING`), not itself an actor | this build |
| `lib/reference-manifest.js` | native | none — read-only against `06_References/` and the static Canon/Published list | Yes | Yes | Yes | false | N/A — read-only, no independent authority | this build |
| `lib/single-instance-lock.js` | native | writes/removes its caller's own declared `.lock` file path only (passed in by the caller, not chosen by this file) | Yes | Yes — checking/writing a PID lock is the same result regardless of how many times it's called in sequence | Yes | false | N/A — a safety utility, not an independent actor | this build |

## Fields, defined

Same five behavioral properties as `skills/_provenance.md` — see that
file for the full definitions. One infra-specific note: for a
persistent chokidar daemon, **idempotent** describes whether a
duplicate/repeat *event* on the same file is a safe no-op (the relevant
question for a long-running watcher that gets restarted or double-fires
on save), not whether the daemon "does the same thing" across
unrelated files — that's just normal operation, not a repeat.
