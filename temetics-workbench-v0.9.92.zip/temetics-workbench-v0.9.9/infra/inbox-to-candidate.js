require('dotenv').config();
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const chokidar = require('chokidar');
const grayMatter = require('gray-matter');
const Ajv = require('ajv');
const { acquireSingleInstanceLock } = require('./lib/single-instance-lock');
const { normalizeDDC } = require('./lib/ddc');

const ajv = new Ajv({ allErrors: true });

// 1. ENVIRONMENT CONFIGURATION & PATH GEOGRAPHY
const INBOX_DIR = path.join(__dirname, '../01_Inbox');
const CANDIDATE_DIR = path.join(__dirname, '../02_Candidate');
const LEXICON_DIR = path.join(__dirname, '../lexicons');
const LEXICON_PATH = path.join(LEXICON_DIR, 'workspace-lexicon.json');
// Relocated from lexicons/ (v4.0 correction, this build): this is a P6
// hash-keyed activity/audit record (candidate_name, source_inbox_file,
// ingested_at per entry), not a lexicon — lexicons/ is reserved for
// actual term/concept repositories (workspace-lexicon.json, nuggets/).
// Lives in 02_Candidate/ because that's what it concerns: it exists to
// block creating a duplicate candidate (see the "[P6 Gate] Duplicate
// blocked" check below), keyed on the same hash that becomes a
// candidate's raw_content_sha256 — same "ledger lives alongside the
// files it concerns" pattern the parallax/promotion ledgers use in
// 03_Promoted/. NOTE: if migrating a live repo, the existing
// lexicons/.ingestion-ledger.json file must be moved (not copied) to
// 02_Candidate/.ingestion-ledger.json by hand — this script only reads
// whatever's at the path below, it doesn't migrate old data itself.
const LEDGER_PATH = path.join(CANDIDATE_DIR, '.ingestion-ledger.json');
const SCHEMA_PATH = path.join(__dirname, '../Schemas', 'keyword-ingest.json');

// Generic substrate configuration
const CORE_AGENT_KEY = process.env.CORE_AGENT_KEY;
const CORE_AGENT_MODEL = process.env.CORE_AGENT_MODEL;
const CORE_AGENT_ENDPOINT = process.env.CORE_AGENT_ENDPOINT;

if (!CORE_AGENT_KEY || !CORE_AGENT_MODEL || !CORE_AGENT_ENDPOINT) {
  console.error("❌ [Config Error] Missing required CORE_AGENT_* environment variables. Check .env file.");
  process.exit(1);
}

acquireSingleInstanceLock(path.join(__dirname, '.inbox-to-candidate.lock'), 'inbox-to-candidate.js');

// Ensure directories
if (!fs.existsSync(CANDIDATE_DIR)) fs.mkdirSync(CANDIDATE_DIR, { recursive: true });
if (!fs.existsSync(LEXICON_DIR)) fs.mkdirSync(LEXICON_DIR, { recursive: true });

// Safe JSON init with corruption recovery
function safeInitializeJsonFile(filePath, defaultData) {
  try {
    if (!fs.existsSync(filePath) || fs.readFileSync(filePath, 'utf8').trim() === '') {
      fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2), 'utf8');
    } else {
      JSON.parse(fs.readFileSync(filePath, 'utf8'));
    }
  } catch (e) {
    console.warn(`⚠️ ${path.basename(filePath)} corrupted. Re-initializing.`);
    fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2), 'utf8');
  }
}

safeInitializeJsonFile(LEXICON_PATH, { "untitled": { "ddc": "000", "related_nodes": [] } });
safeInitializeJsonFile(LEDGER_PATH, {});

// Schemas
let keywordSchema;
try {
  keywordSchema = JSON.parse(fs.readFileSync(SCHEMA_PATH, 'utf8'));
} catch (error) {
  console.warn(`⚠️ Schema missing. Using baseline.`);
  keywordSchema = { type: "object", properties: { keywords: { type: "array", items: { type: "string" }, minItems: 1 } }, required: ["keywords"], additionalProperties: false };
}
const validateKeywords = ajv.compile(keywordSchema);

const substrateMetadataSchema = {
  type: "object",
  properties: {
    slug: { type: "string", pattern: "^[a-z0-9-]+$" },
    ddc: { type: "string" },
    related_nodes: { type: "array", items: { type: "string" } },
    valence_keywords: { type: "array", items: { type: "string" } }
  },
  required: ["slug", "ddc", "related_nodes", "valence_keywords"],
  additionalProperties: false
};
const validateSubstrateMetadata = ajv.compile(substrateMetadataSchema);

// 2. SERIALIZED PIPELINE LOCK
let pipelineQueue = Promise.resolve();
function queuePipelineAction(actionFn) {
  pipelineQueue = pipelineQueue.then(async () => {
    try { await actionFn(); } 
    catch (err) { console.error("❌ Pipeline fault:", err.message); }
  });
  return pipelineQueue;
}

// 3. DETERMINISTIC HELPERS
function computeSha256(content) {
  return crypto.createHash('sha256').update(content, 'utf8').digest('hex');
}

function getTodayStamp() {
  const now = new Date();
  return `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
}

// Inbox naming convention: [source]-YYMMDD-###-keyword1-keyword2.md
// source is open-ended (chat, voice, xyz, ...); ### is a daily sequence counter
// assigned at capture time (see capture-inbox-item.js). This still governs the
// on-disk filename and remains the fallback metadata source — but per RFC-001
// (ratified), a file may now also carry a YAML frontmatter block ahead of the
// payload, and where present that frontmatter is authoritative (see the
// parseUpstreamMetadata / Cumulative Immutability handling in processFile()
// below). A file with no frontmatter behaves exactly as it did before RFC-001.
const INBOX_FILENAME_PATTERN = /^([a-z0-9]+)-(\d{2})(\d{2})(\d{2})-(\d{3})-(.+)\.md$/i;

function parseInboxFilename(fileName) {
  const m = fileName.match(INBOX_FILENAME_PATTERN);
  if (!m) return null;
  const [, source, yy, mm, dd, sequence, slug] = m;
  return {
    source: source.toLowerCase(),
    captured: `20${yy}-${mm}-${dd}`,
    sequence,
    slug
  };
}

// RFC-001 upstream metadata split. Deliberately conservative: a raw
// human/frontier payload can legitimately contain a literal "---" line of
// its own (e.g. a markdown hr, or a pasted document fragment) — an earlier
// version of this pipeline stripped frontmatter unconditionally and that
// caused a real corruption failure (see Templates/inbox-capture.md history).
// So gray-matter's parse is only trusted as real RFC-001 frontmatter when it
// produces a source_node field — the one field no accidental "---" collision
// in ordinary prose is going to produce. Anything else (parse failure, or a
// parse that "succeeds" but has no source_node) is treated as no-frontmatter,
// and the whole raw file is used as the payload — the exact pre-RFC-001
// behavior.
function parseUpstreamMetadata(rawFile) {
  try {
    const parsed = grayMatter(rawFile);
    if (parsed.data && typeof parsed.data === 'object' && parsed.data.source_node) {
      return { hasFrontmatter: true, meta: parsed.data, body: parsed.content.trim() };
    }
  } catch (e) {
    // Not valid YAML frontmatter — fall through to no-frontmatter handling.
  }
  return { hasFrontmatter: false, meta: {}, body: rawFile.trim() };
}

// Dedup helper for merging upstream (frontier-supplied) arrays with
// locally-derived ones — order-preserving, first occurrence wins.
function mergeUnique(...lists) {
  const seen = new Set();
  const out = [];
  for (const list of lists) {
    for (const item of (list || [])) {
      if (!seen.has(item)) { seen.add(item); out.push(item); }
    }
  }
  return out;
}

function getUniqueTargetPath(baseName) {
  let counter = 0;
  const today = getTodayStamp();
  let currentName = `${today}-${baseName}.md`;
  let currentPath = path.join(CANDIDATE_DIR, currentName);

  while (fs.existsSync(currentPath)) {
    counter++;
    const suffix = String(counter).padStart(2, '0');
    currentName = `${today}-${baseName}-${suffix}.md`;
    currentPath = path.join(CANDIDATE_DIR, currentName);
  }
  return { targetPath: currentPath, targetFileName: currentName };
}

function atomicWriteJson(targetPath, data) {
  const tempPath = `${targetPath}.${crypto.randomBytes(4).readUInt32LE(0)}.tmp`;
  fs.writeFileSync(tempPath, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tempPath, targetPath);
}

function normalizeToHyphenCase(str) {
  if (!str) return '';
  return str
    .replace(/([a-z0-9])([A-Z])/g, '$1-$2')
    .replace(/[\s_]+/g, '-')
    .toLowerCase()
    .replace(/--+/g, '-')
    .replace(/^-|-$/g, '');
}

// Punch list #18 fix: date-prefixed filenames (YYYYMMDD-slug.md) break
// Obsidian's own wikilink resolution — [[Meme]] only resolves against a
// literal filename or a frontmatter `aliases:` entry, so a date-prefixed
// file always looks unresolved even once the concept exists. Rather than
// rename files (losing the audit-trail-friendly date prefix), give every
// candidate a title-cased alias matching how a wikilink would name it —
// the inverse of normalizeToHyphenCase above.
function slugToTitleCase(slug) {
  if (!slug) return '';
  return slug
    .split('-')
    .filter(Boolean)
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}

// 4. TRUST-BOUNDED SUBSTRATE HOOK
async function callSubstrateForMetadata(snippet) {
  const prompt = `Analyze this text snippet from an unclassified informational replicator inbox entry.
Extract the single most definitive conceptual topic.
Return ONLY a raw JSON object matching this exact schema with no extra text or markdown:

{
  "slug": "hyphen-case-primary-topic",
  "ddc": "000",   // MUST be exactly one of: 000, 100, 200, 300, 400, 500, 600, 700, 800, or 900
  "related_nodes": ["[[WikiLink1]]", "[[WikiLink2]]"],
  "valence_keywords": ["primary-term", "high-confidence-term2"]
}

Choose the single best top-level DDC class only. Do not invent sub-classes.
Text snippet: "${snippet}"`;

  try {
    const response = await fetch(CORE_AGENT_ENDPOINT, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json', 
        'Authorization': `Bearer ${CORE_AGENT_KEY}` 
      },
      body: JSON.stringify({ 
        model: CORE_AGENT_MODEL, 
        messages: [{ role: 'user', content: prompt }], 
        temperature: 0.1 
      })
    });

    const rawText = (await response.text()).trim();
    if (!response.ok) return { slug: "untitled", ddc: "000", related_nodes: [], valence_keywords: ["untitled"] };

    let innerContent = JSON.parse(rawText).choices?.[0]?.message?.content?.trim() || '';
    if (innerContent.startsWith("```")) {
      innerContent = innerContent.replace(/^```json\s*/i, "").replace(/```$/, "").trim();
    }

    const parsedJson = JSON.parse(innerContent);

    if (!validateSubstrateMetadata(parsedJson)) {
      console.warn("⚠️ Substrate metadata validation failed.");
      return { slug: "untitled", ddc: "000", related_nodes: [], valence_keywords: ["untitled"] };
    }

    parsedJson.slug = normalizeToHyphenCase(parsedJson.slug);

    const badSlugs = new Set(["untitled", "no-topic-identified", "none", "unknown", ""]);
    if (badSlugs.has(parsedJson.slug) || !/^[a-z0-9-]+$/.test(parsedJson.slug)) {
      console.log(`[Filter] Rejected invalid slug: ${parsedJson.slug}`);
      return { slug: "untitled", ddc: "000", related_nodes: [], valence_keywords: ["untitled"] };
    }

    // Normalize to a valid 3-digit DDC class (truncates decimals, e.g.
    // "303.372" -> "303"; falls back to "000" only if nothing usable
    // survives normalization). Substrate is prompted for top-level-only,
    // but this guard no longer assumes that held.
    const normalizedDdc = normalizeDDC(parsedJson.ddc);
    if (normalizedDdc !== parsedJson.ddc) {
      console.log(`[DDC Guard] "${parsedJson.ddc}" → normalized to "${normalizedDdc}"`);
    }
    parsedJson.ddc = normalizedDdc;

    return parsedJson;
  } catch (error) {
    console.error("❌ Substrate error:", error.message);
    return { slug: "untitled", ddc: "000", related_nodes: [], valence_keywords: ["untitled"] };
  }
}

// 5. CORE PIPELINE
async function processFile(filePath) {
  await queuePipelineAction(async () => {
    if (!fs.existsSync(filePath)) return;

    const fileName = path.basename(filePath);
    const inboxMeta = parseInboxFilename(fileName);
    if (!inboxMeta) {
      console.error(`❌ [Quarantine] "${fileName}" does not match the required naming convention [source]-YYMMDD-###-keyword1-keyword2.md. Not processed — file left in place.`);
      const quarantineLogPath = filePath.replace(/\.md$/i, '.quarantined.log');
      fs.writeFileSync(
        quarantineLogPath,
        `Filename does not match required convention: [source]-YYMMDD-###-keyword1-keyword2.md\nGot: ${fileName}\nNot processed. File left in place in 01_Inbox.\n`,
        'utf8'
      );
      return;
    }

    let rawFile = '';
    for (let attempt = 0; attempt < 5; attempt++) {
      const stats = fs.statSync(filePath);
      if (stats.size > 0) {
        rawFile = fs.readFileSync(filePath, 'utf8');
        if (rawFile.trim()) break;
      }
      await new Promise(r => setTimeout(r, 200));
    }

    if (!rawFile.trim()) {
      console.log(`[Guard] Skipping empty/zero-byte file after retries: ${path.basename(filePath)}`);
      return;
    }

    // RFC-001: split real frontmatter (if present) from the payload. See
    // parseUpstreamMetadata's own comment for why this is deliberately
    // conservative about what counts as "real" frontmatter. `content` below
    // is always just the payload — raw_claim — never the frontmatter block,
    // for both the pre- and post-RFC-001 case.
    const { hasFrontmatter, meta: upstream, body: content } = parseUpstreamMetadata(rawFile);

    if (!content) {
      console.log(`[Guard] Skipping empty file: ${path.basename(filePath)}`);
      return;
    }

    // Hash the payload only, not the frontmatter — two submissions with the
    // same underlying claim but different source_session_id/captured
    // metadata are still the same content for P6 duplicate-detection
    // purposes.
    const hash = computeSha256(content);

    const ingestionLedger = JSON.parse(fs.readFileSync(LEDGER_PATH, 'utf8'));
    if (ingestionLedger[hash]) {
      console.log(`[P6 Gate] Duplicate blocked: ${ingestionLedger[hash].candidate_name}`);
      return;
    }

    const snippet = content.split(/\s+/).slice(0, 100).join(' ');

    let slug = null;
    let lexiconRecord = null;
    let dynamicKeywords = [];

    let lexiconData = JSON.parse(fs.readFileSync(LEXICON_PATH, 'utf8'));

    // RFC-001, Cumulative Immutability: if the frontier node already supplied
    // extracted_tag (and, per the RFC, should also have supplied keywords),
    // that's upstream metadata — it's preserved untouched, not re-derived by
    // local heuristics. This takes priority over both the wikilink-slug
    // special case and the hashtag-scan/substrate-call path below, neither
    // of which run when this branch is taken.
    const upstreamTag = hasFrontmatter && upstream.extracted_tag
      ? normalizeToHyphenCase(String(upstream.extracted_tag).replace(/^#/, ''))
      : null;

    if (upstreamTag && upstreamTag !== 'untitled') {
      slug = upstreamTag;
      dynamicKeywords = Array.isArray(upstream.keywords) && upstream.keywords.length
        ? upstream.keywords
        : [slug, "ingested-note"];
      lexiconRecord = lexiconData[`#${slug}`] || lexiconData[slug];
    } else if (inboxMeta.source === 'wikilink') {
      // Bug fix: inboxMeta.slug was parsed from the filename above but never
      // actually used — every item, wikilink-sourced or not, fell through to
      // hashtag-scan-then-substrate-call derivation below, silently
      // discarding exactly the "much more meaningful signal" capture-
      // obsidian-stub.js's own header comment says a wikilink's filename
      // (e.g. "Gene", "Meme" — a deliberately chosen concept name) should
      // preserve. Only wikilink-sourced items get this treatment: chat/voice
      // slugs come from capture-inbox-item.js's own stopword-filtered content
      // guess, which isn't a deliberate name the same way a clicked wikilink is.
      slug = normalizeToHyphenCase(inboxMeta.slug);
      dynamicKeywords = [slug, "wikilink-stub", "deterministic-tag"];
    } else {
      const matchingHashtag = snippet.match(/#([A-Za-z0-9_-]+)/);
      slug = matchingHashtag ? normalizeToHyphenCase(matchingHashtag[1]) : null;
    }

    if (upstreamTag && upstreamTag !== 'untitled') {
      // Already resolved above — skip both remaining derivation branches.
    } else if (slug && slug !== 'untitled') {
      lexiconRecord = lexiconData[`#${slug}`] || lexiconData[slug];
      if (dynamicKeywords.length === 0) dynamicKeywords = [slug, "ingested-note", "deterministic-tag"];
    } else {
      const substrateData = await callSubstrateForMetadata(snippet);
      if (substrateData.slug && substrateData.slug !== 'untitled') {
        slug = substrateData.slug;
        const targetKey = `#${slug}`;
        dynamicKeywords = substrateData.valence_keywords || [slug, "ingested-note"];

        if (!lexiconData[targetKey]) {
          lexiconData[targetKey] = { ddc: substrateData.ddc || "000", related_nodes: substrateData.related_nodes || [] };
          atomicWriteJson(LEXICON_PATH, lexiconData);
          console.log(`📝 Appended new token [${targetKey}]`);
        }
        lexiconRecord = lexiconData[targetKey];
      }
    }

    const finalSlug = slug || 'untitled';
    if (dynamicKeywords.length === 0) dynamicKeywords = [finalSlug, "ingested-note"];

    const { targetPath, targetFileName } = getUniqueTargetPath(finalSlug);
    const keywordsPayload = { keywords: dynamicKeywords };

    if (!validateKeywords(keywordsPayload)) {
      console.error(`❌ AJV failed for ${path.basename(filePath)}`);
      return;
    }

    // A tag supplied by the frontier node but never seen locally before has
    // no lexicon entry yet. DDC classification is a local-only concept —
    // RFC-001's schema doesn't cover it — so a brand-new upstream tag gets
    // the same "000" default any brand-new local tag gets, seeded with
    // whatever related_nodes the frontier node already supplied.
    if (upstreamTag && upstreamTag !== 'untitled' && !lexiconRecord) {
      const targetKey = `#${finalSlug}`;
      lexiconData[targetKey] = { ddc: "000", related_nodes: Array.isArray(upstream.related_nodes) ? upstream.related_nodes : [] };
      atomicWriteJson(LEXICON_PATH, lexiconData);
      console.log(`📝 Appended new token [${targetKey}] (from upstream extracted_tag)`);
      lexiconRecord = lexiconData[targetKey];
    }

    const verifiedRecord = lexiconRecord || { ddc: "000", related_nodes: [] };
    // Normalize on every reuse, not just at tag-creation time (bug #1 fix):
    // lexiconRecord may have come from a hashtag match against an existing
    // key (line ~279 above), an existing substrate-matched key, or a manual
    // Obsidian edit — none of those paths were validated before now.
    const reusedDdc = normalizeDDC(verifiedRecord.ddc);
    if (reusedDdc !== (verifiedRecord.ddc || "000")) {
      console.log(`[DDC Guard] Reused tag "${finalSlug}" had invalid class "${verifiedRecord.ddc}" → normalized to "${reusedDdc}"`);
    }

    // Obsidian resolves [[WikiLink]]s against aliases too, not just the
    // literal filename — this is what makes [[Meme]] find this file even
    // though it's saved as 20260727-meme.md (punch list #18). Any aliases
    // the frontier node already supplied are merged in, not replaced.
    const autoAlias = finalSlug !== 'untitled' ? [slugToTitleCase(finalSlug)] : [];
    const mergedAliases = mergeUnique(autoAlias, Array.isArray(upstream.aliases) ? upstream.aliases : []);
    const mergedRelatedNodes = mergeUnique(
      verifiedRecord.related_nodes || [],
      Array.isArray(upstream.related_nodes) ? upstream.related_nodes : []
    );

    const candidateFrontmatter = {
      raw_content_sha256: hash,
      // RFC-001: prefer upstream-supplied source/captured (authoritative,
      // frontier-generated) over the filename-derived fallback — falls back
      // cleanly to the pre-RFC-001 values when there's no frontmatter.
      source: upstream.source || inboxMeta.source,
      source_node: upstream.source_node || null,
      source_session_id: upstream.source_session_id || null,
      captured: upstream.captured || inboxMeta.captured,
      inbox_sequence: inboxMeta.sequence,
      extracted_tag: finalSlug !== 'untitled' ? `#${finalSlug}` : null,
      aliases: mergedAliases,
      keywords: keywordsPayload.keywords,
      ddc: reusedDdc,
      related_nodes: mergedRelatedNodes,
      ingested_at: new Date().toISOString()
    };

    const completeCandidateContent = grayMatter.stringify(content, candidateFrontmatter);
    fs.writeFileSync(targetPath, completeCandidateContent, 'utf8');

    ingestionLedger[hash] = {
      candidate_name: targetFileName,
      source_inbox_file: path.basename(filePath),
      ingested_at: candidateFrontmatter.ingested_at
    };
    atomicWriteJson(LEDGER_PATH, ingestionLedger);

    console.log(`✅ [Substrate Connection Active] Candidate secured: ${targetFileName}`);
  });
}

// 6. DAEMON
const watcher = chokidar.watch(INBOX_DIR, {
  persistent: true,
  ignoreInitial: false,
  awaitWriteFinish: { stabilityThreshold: 600, pollInterval: 100 }
});

watcher.on('all', (event, filePath) => {
  if (filePath.endsWith('.md') && (event === 'add' || event === 'change')) {
    if (path.basename(filePath).toLowerCase() === 'readme.md') return;
    processFile(filePath);
  }
});

console.log('🚀 Hardened Controller v0.9.4 Active. Monitoring workspace...');