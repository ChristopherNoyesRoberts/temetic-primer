#!/usr/bin/env node
/**
 * capture-inbox-item.js
 *
 * Writes a new file into 01_Inbox/ following the naming convention:
 *
 *   [source]-YYMMDD-###-keyword1-keyword2[-keyword3].md
 *
 * - source: open-ended short label (chat, voice, xyz, ...), lowercase alnum only.
 * - YYMMDD: today's date.
 * - ###: zero-padded daily sequence counter (001, 002, ...), scanned from existing
 *   files for today's date — no separate counter/state file needed.
 * - keywords: first 3-5 unique CONTENT words of the payload (stopwords filtered),
 *   lowercased and hyphenated, per 01_Inbox/README.md's existing slug rule — used
 *   only when neither --tag nor --keywords is supplied (see below).
 *
 * RFC-001 (ratified): the file now carries a YAML frontmatter block ahead of
 * the raw payload — source, source_node, captured are always written;
 * source_session_id / extracted_tag / keywords / aliases / related_nodes are
 * included only when supplied, so a bare local capture (voice/chat, no
 * upstream metadata) still leaves extracted_tag/keywords for
 * inbox-to-candidate.js to derive itself, exactly as before RFC-001. This
 * script never guesses source_node on a frontier node's behalf beyond the
 * default below — that's for whatever calls this with real upstream data.
 *
 * Usage:
 *   node infra/capture-inbox-item.js --source voice "raw payload text..."
 *   echo "raw payload text..." | node infra/capture-inbox-item.js --source chat
 *   node infra/capture-inbox-item.js --source document --source-node "Node B" \
 *     --session-id session_2026_08_04_x --tag "#replicator-theory" \
 *     --keywords odd-ordered-replicators,replicator-levels "payload..."
 */

const fs = require('fs');
const path = require('path');
const grayMatter = require('gray-matter');

const INBOX_DIR = path.join(__dirname, '../01_Inbox');

const STOPWORDS = new Set([
  'a','an','the','is','are','was','were','be','been','being','has','have','had',
  'this','these','those','that','there','here','and','or','but','so','of','to',
  'in','on','at','by','with','from','as','do','does','did','not','no','we','i',
  'you','he','she','it','they','them','their','his','her','its','about','into',
  'than','then','for','if','will','would','can','could','should','may','might',
  'up','down','out','over','under','again','further','once','all','any','both',
  'each','few','more','most','other','some','such','only','own','same',
  'many','much','several'
]);

const RFC001_SOURCE_NODE_ENUM = new Set(['Node M', 'Node B', 'Node A', 'Node GPT', 'Node CL']);

function parseArgs(argv) {
  const args = {
    source: null,
    sourceNode: 'Node M', // default: this CLI is the founder's own local capture tool
    sessionId: null,
    tag: null,
    keywords: null,
    payload: null
  };
  const rest = [];
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--source') {
      args.source = argv[++i];
    } else if (argv[i] === '--source-node') {
      args.sourceNode = argv[++i];
    } else if (argv[i] === '--session-id') {
      args.sessionId = argv[++i];
    } else if (argv[i] === '--tag') {
      args.tag = argv[++i];
    } else if (argv[i] === '--keywords') {
      args.keywords = argv[++i].split(',').map(k => k.trim()).filter(Boolean);
    } else {
      rest.push(argv[i]);
    }
  }
  if (rest.length > 0) args.payload = rest.join(' ');
  return args;
}

function todayStamp() {
  const now = new Date();
  const yy = String(now.getFullYear()).slice(-2);
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  return `${yy}${mm}${dd}`;
}

function nextCounter(dateStamp) {
  if (!fs.existsSync(INBOX_DIR)) return 1;
  const pattern = new RegExp(`^[a-z0-9]+-${dateStamp}-(\\d{3})-.*\\.md$`, 'i');
  let max = 0;
  for (const name of fs.readdirSync(INBOX_DIR)) {
    const m = name.match(pattern);
    if (m) {
      const n = parseInt(m[1], 10);
      if (n > max) max = n;
    }
  }
  return max + 1;
}

function deriveSlug(payload, minWords = 3, maxWords = 5) {
  const words = payload
    .split(/\s+/)
    .map(w => w.toLowerCase().replace(/[^a-z0-9]+/gi, ''))
    .filter(Boolean);

  const seen = new Set();
  const contentWords = [];
  for (const w of words) {
    if (STOPWORDS.has(w)) continue;
    if (seen.has(w)) continue;
    seen.add(w);
    contentWords.push(w);
    if (contentWords.length >= maxWords) break;
  }

  // If stopword-filtering left us short, backfill with raw unique words
  // (still skipping exact dupes) so we always hit at least minWords when possible.
  if (contentWords.length < minWords) {
    for (const w of words) {
      if (seen.has(w)) continue;
      seen.add(w);
      contentWords.push(w);
      if (contentWords.length >= minWords) break;
    }
  }

  return contentWords.join('-');
}

// RFC-001 §2.1 frontmatter, built once here so capture-obsidian-stub.js (a
// second 01_Inbox/ writer) never has to duplicate this shape. Required
// fields (source, source_node, captured) are always present; optional ones
// (source_session_id, extracted_tag, aliases, keywords, related_nodes) are
// included only when actually supplied — an absent extracted_tag/keywords
// is the deliberate signal that tells inbox-to-candidate.js to fall back to
// its own local derivation, exactly as it did before RFC-001.
function buildInboxFrontmatter({ source, sourceNode, sessionId, tag, keywords, aliases, relatedNodes }) {
  const fm = {
    source,
    source_node: sourceNode,
    captured: new Date().toISOString()
  };
  if (sessionId) fm.source_session_id = sessionId;
  if (tag) fm.extracted_tag = tag;
  if (aliases && aliases.length) fm.aliases = aliases;
  if (keywords && keywords.length) fm.keywords = keywords;
  if (relatedNodes && relatedNodes.length) fm.related_nodes = relatedNodes;
  return fm;
}

function wrapPayload(payload, frontmatterOpts) {
  return grayMatter.stringify(payload, buildInboxFrontmatter(frontmatterOpts));
}

function main() {
  const args = parseArgs(process.argv.slice(2));

  if (!args.payload) {
    // No positional payload — try stdin.
    try {
      args.payload = fs.readFileSync(0, 'utf8');
    } catch (e) {
      // fall through to validation error below
    }
  }

  if (!args.source || !/^[a-z0-9]+$/i.test(args.source)) {
    console.error('❌ [Capture Error] --source is required and must be lowercase alnum (e.g. chat, voice).');
    process.exit(1);
  }

  if (!RFC001_SOURCE_NODE_ENUM.has(args.sourceNode)) {
    console.error(`❌ [Capture Error] --source-node must be one of: ${[...RFC001_SOURCE_NODE_ENUM].join(', ')}.`);
    process.exit(1);
  }

  const payload = (args.payload || '').trim();
  if (!payload) {
    console.error('❌ [Capture Error] No payload provided (pass as an argument or pipe via stdin).');
    process.exit(1);
  }

  if (!fs.existsSync(INBOX_DIR)) fs.mkdirSync(INBOX_DIR, { recursive: true });

  const dateStamp = todayStamp();
  const counter = String(nextCounter(dateStamp)).padStart(3, '0');
  const slug = deriveSlug(payload) || 'untitled';
  const source = args.source.toLowerCase();

  const fileName = `${source}-${dateStamp}-${counter}-${slug}.md`;
  const targetPath = path.join(INBOX_DIR, fileName);

  const fileContent = wrapPayload(payload, {
    source,
    sourceNode: args.sourceNode,
    sessionId: args.sessionId,
    tag: args.tag,
    keywords: args.keywords
  });

  fs.writeFileSync(targetPath, fileContent, 'utf8');
  console.log(`✅ [Captured] ${fileName}`);
}

// Exported so capture-obsidian-stub.js (vault-root Obsidian-stub watcher,
// punch list #6) can build a correctly-named, correctly-sequenced Inbox
// filename AND the same RFC-001 frontmatter shape, without duplicating
// either. CLI behavior is unchanged — main() only runs when this file is
// executed directly, not when required as a module.
module.exports = {
  INBOX_DIR, todayStamp, nextCounter, deriveSlug,
  buildInboxFrontmatter, wrapPayload, RFC001_SOURCE_NODE_ENUM
};

if (require.main === module) {
  main();
}
