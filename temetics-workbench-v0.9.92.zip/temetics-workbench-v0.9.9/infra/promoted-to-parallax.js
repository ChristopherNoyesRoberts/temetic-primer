#!/usr/bin/env node
/**
 * promoted-to-parallax.js
 *
 * RFC-002 (local-to-parallax schema): manually-triggered outbound batching
 * script. Scans 03_Promoted/ for items with awaiting_parallax: true,
 * assembles them into one batch manifest written to 04_To_Parallax/, and
 * flips awaiting_parallax back to false on each pulled item so a later
 * run doesn't re-send anything still in flight (the 04_To_Parallax/
 * manifest itself is the record of what's out for review — founder's
 * ruling, parallax-schema thread — no separate "in_parallax" marker
 * needed).
 *
 * NOT a chokidar daemon — this is a one-shot CLI tool, run by hand:
 *
 *   node infra/promoted-to-parallax.js --tier 0
 *
 * matching the founder's manual-trigger workflow for both sides of
 * Parallax (see collate_parallax.js for the return path).
 *
 * Blindness Tiers (RFC-002 §2, ladder as settled — supersedes the earlier
 * Grok-proposed field set): controls which fields are included per item,
 * independent of founder_note/founder_directive — those are the founder's
 * own guidance, not local system reasoning, and are ALWAYS included
 * regardless of tier (same principle for both the per-item note and the
 * batch-level directive).
 *
 *   Tier 0: candidate_id, raw_claim only
 *   Tier 1: + source, captured, extracted_tag, aliases, keywords, ddc,
 *           related_nodes
 *   Tier 2: + training_reference_docs, cascade_incomplete
 *   Tier 3: + verification_receipt, forwarded whole (incl. its own
 *           proposed_axiom, supported_mapping, kernel_projection) — sealed
 *           as one unit per the founder's ruling, never split across tiers
 *
 * PERMANENTLY EXCLUDED AT ALL TIERS (RFC-002 §5, absolute ban — not a
 * graduated Tier-2-style restriction): gate_status, status, promoted_at,
 * ingested_at, training_completed_at, awaiting_parallax,
 * raw_content_sha256. buildItemPayload() only ever adds fields by name
 * (allow-list, never spreads frontmatter wholesale), so these can't leak
 * in by construction — assertNoBannedFields() below is a cheap deterministic
 * second check on top of that, not a substitute for it.
 *
 * Fail-safe ordering fix: the manifest is written only AFTER the
 * per-item awaiting_parallax flip-back loop completes, and the manifest
 * write itself is atomic (temp file + rename — see atomicWriteFile).
 * This was previously the other way around: manifest written first, then
 * frontmatter flipped. That ordering meant an interruption between the
 * two steps could leave an already-transmitted batch still flagged
 * awaiting_parallax: true, so a re-run would re-select and re-send it
 * under a second batch id — corrupting quorum tracking with two
 * manifests for the same content. The new ordering fails safe instead:
 * an interruption before the flip loop finishes means the manifest never
 * gets written at all, so the batch is simply lost (recoverable — a
 * re-run naturally re-selects whatever's still flagged), not duplicated.
 * Not fully atomic end-to-end (the per-item frontmatter writes and the
 * manifest write are still two separate steps), but the failure mode on
 * either side of that boundary is now "nothing sent," never "sent twice."
 *
 * KNOWN GAP (flagged, not silently papered over): Tier 3's
 * verification_receipt is forwarded as whatever object currently lives in
 * candidate frontmatter — if a candidate's receipt doesn't actually carry
 * a real proposed_axiom sub-field yet, this script doesn't fabricate one;
 * that's upstream (candidate-to-promoted.js / the local gate) data, not a
 * gap in this script.
 *
 * Manifest format: JSON, not literal YAML — no YAML-writing library is
 * currently a dependency anywhere in this codebase, and RFC-002 §3
 * explicitly allows "YAML (or equivalent JSON string)". Swap to js-yaml
 * here if the founder wants the on-disk manifest to be literal YAML.
 *
 * Hash-after-final-edit: rather than a generate-then-edit-then-finalize
 * dance, this prompts for the optional batch-level founder_directive
 * INLINE at generation time (stdin), so the written manifest is already
 * final and its content hash reflects exactly what gets transmitted —
 * one script run, no follow-up edit required.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const readline = require('readline');
const grayMatter = require('gray-matter');

const PROMOTED_DIR = path.join(__dirname, '../03_Promoted');
const TO_PARALLAX_DIR = path.join(__dirname, '../04_To_Parallax');
const LEDGER_PATH = path.join(PROMOTED_DIR, '.parallax-ledger.json');
const NON_CANDIDATE_FILENAMES = new Set(['README.md']);
const VALID_TIERS = new Set([0, 1, 2, 3]);

// RFC-002 §5 absolute ban — never included at any tier. Belt-and-suspenders
// check: buildItemPayload() is allow-list by construction (see file header),
// so this should never actually fire, but a deterministic assertion is cheap
// and failing loud here beats a silent leak.
const NEVER_INCLUDE_FIELDS = new Set([
  'gate_status',
  'status',
  'promoted_at',
  'ingested_at',
  'training_completed_at',
  'awaiting_parallax',
  'raw_content_sha256'
]);

function assertNoBannedFields(item) {
  const leaked = Object.keys(item).filter(key => NEVER_INCLUDE_FIELDS.has(key));
  if (leaked.length > 0) {
    throw new Error(`🚫 [Blindness Violation] Banned field(s) present on outbound item: ${leaked.join(', ')}`);
  }
}

function parseArgs(argv) {
  const args = { tier: null, batchId: null };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--tier') args.tier = parseInt(argv[++i], 10);
    else if (argv[i] === '--batch-id') args.batchId = argv[++i];
  }
  return args;
}

function computeSha256(content) {
  return crypto.createHash('sha256').update(content, 'utf8').digest('hex');
}

// Write-then-rename so the manifest either fully exists at its real path
// or doesn't exist at all — never a partially-written file if the process
// is interrupted mid-write. Same temp+rename pattern already used for the
// lexicon/ledger writes elsewhere in this codebase.
function atomicWriteFile(targetPath, content) {
  const tempPath = `${targetPath}.${crypto.randomBytes(4).readUInt32LE(0)}.tmp`;
  fs.writeFileSync(tempPath, content, 'utf8');
  fs.renameSync(tempPath, targetPath);
}

function timestampSlug() {
  const now = new Date();
  const pad = n => String(n).padStart(2, '0');
  return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
}

// Same ledger the receiving side (collate_parallax.js) writes consensus
// data into — one file, two writers, distinct top-level keys. Matches
// the "parallax ledger" already planned in 03_Promoted/.parallax-ledger.json.
function loadLedger() {
  if (!fs.existsSync(LEDGER_PATH)) return { batches: {}, consensus: {} };
  try {
    const parsed = JSON.parse(fs.readFileSync(LEDGER_PATH, 'utf8'));
    parsed.batches = parsed.batches || {};
    parsed.consensus = parsed.consensus || {};
    return parsed;
  } catch (err) {
    console.error(`⚠️ [Ledger] Failed to parse ${path.basename(LEDGER_PATH)} — refusing to overwrite it blindly:`, err.message);
    throw err;
  }
}

function saveLedger(ledger) {
  fs.writeFileSync(LEDGER_PATH, JSON.stringify(ledger, null, 2), 'utf8');
}

function promptFounderDirective() {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(resolve => {
    rl.question('📝 Batch-level founder_directive (optional — press Enter to skip): ', answer => {
      rl.close();
      resolve(answer.trim());
    });
  });
}

// candidate_id MUST map deterministically to the 03_Promoted/ filename
// (RFC-003 §5, "Immutable Traceability") so a returned receipt can be
// correlated back without any reconstruction.
function candidateIdFromFilename(fileName) {
  return fileName.replace(/\.md$/i, '');
}

// Promotion-helper appends a "### Cascade Training Log" section (documents
// consulted, exterior-gate conclusions, references to "the Alliance,"
// "parallax step," "gate" thresholds, etc.) directly into the candidate's
// body once it lands in 03_Promoted/. That's local pipeline-process content,
// not the claim itself — it belongs in a tier-gated field (a future
// cascade_training_log field at Tier 2+, matching the founder's stated
// interest in exposing promotion-helper logs to frontier nodes), never in
// raw_claim. Left unstripped, it leaks pipeline-internal context into every
// tier including Tier 0 (Pure Blind), which is specifically supposed to
// withhold exactly this. Caught via a real promoted file
// (20260727-artificial-selection.md) during this session — the log section
// is written in-body, not to a sidecar file, so it was flowing straight
// through raw_claim undetected.
const CASCADE_LOG_HEADING_PATTERN = /\n#{2,3}\s*Cascade Training Log[\s\S]*$/i;

function stripCascadeLog(body) {
  return body.replace(CASCADE_LOG_HEADING_PATTERN, '').trim();
}

function buildItemPayload(fileName, frontmatter, body, tier) {
  const item = {
    candidate_id: candidateIdFromFilename(fileName),
    raw_claim: stripCascadeLog(body),
    // Always included regardless of tier — founder guidance, not local
    // system reasoning (same principle as the batch-level founder_directive).
    founder_note: frontmatter.founder_note || ''
  };

  if (tier >= 1) {
    item.source = frontmatter.source || null;
    item.captured = frontmatter.captured || null;
    item.extracted_tag = frontmatter.extracted_tag || null;
    item.aliases = frontmatter.aliases || [];
    item.keywords = frontmatter.keywords || [];
    item.ddc = frontmatter.ddc || null;
    item.related_nodes = frontmatter.related_nodes || [];
  }

  if (tier >= 2) {
    item.training_reference_docs = frontmatter.training_reference_docs || [];
    item.cascade_incomplete = frontmatter.cascade_incomplete ?? null;
  }

  if (tier >= 3) {
    // Sealed as one unit, not split across tiers (founder's ruling) — this
    // forwards verification_receipt exactly as it exists in the candidate's
    // frontmatter, including whatever it has (or lacks) for proposed_axiom,
    // supported_mapping, and kernel_projection. See KNOWN GAP in file header.
    item.verification_receipt = frontmatter.verification_receipt || null;
  }

  assertNoBannedFields(item);
  return item;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));

  if (args.tier === null || !VALID_TIERS.has(args.tier)) {
    console.error('❌ [Usage] --tier is required and must be one of 0, 1, 2, 3.');
    console.error('   Example: node infra/promoted-to-parallax.js --tier 0');
    process.exit(1);
  }

  if (!fs.existsSync(PROMOTED_DIR)) {
    console.error('❌ 03_Promoted/ does not exist.');
    process.exit(1);
  }
  if (!fs.existsSync(TO_PARALLAX_DIR)) fs.mkdirSync(TO_PARALLAX_DIR, { recursive: true });

  const candidates = fs.readdirSync(PROMOTED_DIR)
    .filter(name => name.endsWith('.md') && !NON_CANDIDATE_FILENAMES.has(name));

  const selected = [];
  for (const fileName of candidates) {
    const filePath = path.join(PROMOTED_DIR, fileName);
    const parsed = grayMatter(fs.readFileSync(filePath, 'utf8'));
    if (parsed.data && parsed.data.awaiting_parallax === true) {
      selected.push({ fileName, filePath, frontmatter: parsed.data, body: parsed.content.trim() });
    }
  }

  if (selected.length === 0) {
    console.log('ℹ️  No items in 03_Promoted/ have awaiting_parallax: true. Nothing to send.');
    process.exit(0);
  }

  console.log(`📦 Found ${selected.length} item(s) flagged awaiting_parallax:`);
  for (const s of selected) console.log(`   - ${s.fileName}`);

  const founderDirective = await promptFounderDirective();

  const batchId = args.batchId || `v4.0-batch-${timestampSlug()}-t${args.tier}`;
  const items = selected.map(s => buildItemPayload(s.fileName, s.frontmatter, s.body, args.tier));

  const batchPayload = {
    parallax_batch_id: batchId,
    blindness_tier: args.tier,
    founder_directive: founderDirective,
    items
  };

  const serialized = JSON.stringify(batchPayload, null, 2);
  const payloadHash = computeSha256(serialized);

  const manifestPath = path.join(TO_PARALLAX_DIR, `${batchId}.json`);
  if (fs.existsSync(manifestPath)) {
    console.error(`❌ Manifest already exists at ${manifestPath} — refusing to overwrite. Pass --batch-id to choose a different id.`);
    process.exit(1);
  }

  // Flip awaiting_parallax back off BEFORE the manifest is written, not
  // after (reordered — see file header, "Fail-safe ordering fix"). If this
  // loop is interrupted partway, the manifest never gets written at all
  // (nothing below has run yet), so the batch is simply lost — no manifest
  // exists under this batch id, and a re-run will naturally re-select
  // whatever's still flagged awaiting_parallax: true. The previous
  // manifest-first order could instead leave an already-transmitted batch
  // re-selected and re-sent under a second batch id on retry, corrupting
  // quorum tracking with two manifests for the same content — a strictly
  // worse failure than a lost batch, which is why this direction was
  // chosen over the reverse.
  for (const s of selected) {
    const updatedFrontmatter = { ...s.frontmatter, awaiting_parallax: false };
    fs.writeFileSync(s.filePath, grayMatter.stringify(s.body, updatedFrontmatter), 'utf8');
  }

  // Atomic: either the manifest fully exists at its real path, or it
  // doesn't exist at all — never a truncated/partial file on interruption.
  atomicWriteFile(manifestPath, serialized);

  const ledger = loadLedger();
  ledger.batches[batchId] = {
    blindness_tier: args.tier,
    candidate_ids: selected.map(s => candidateIdFromFilename(s.fileName)),
    payload_sha256: payloadHash,
    sent_at: new Date().toISOString()
  };
  saveLedger(ledger);

  console.log(`✅ [Batch Ready] ${batchId} → 04_To_Parallax/${batchId}.json (${items.length} item(s), tier ${args.tier})`);
  console.log(`   Payload hash: ${payloadHash}`);
  console.log('   Ready to transmit to the Node Alliance.');
}

main().catch(err => {
  console.error('❌ Fatal error:', err.message);
  process.exit(1);
});
