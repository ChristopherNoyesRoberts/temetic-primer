#!/usr/bin/env node
/**
 * capture-obsidian-stub.js
 *
 * Punch list #6: the Obsidian vault root IS this repo's root (confirmed —
 * .obsidian/ lives there). Clicking an empty [[WikiLink]] (e.g. from a
 * related_nodes entry) makes Obsidian create a new, empty note at the vault
 * root under that link's exact name (e.g. "Epistemology.md"). Neither
 * existing daemon watches the root, so that file just sits there invisible
 * to the pipeline until now.
 *
 * Founder's explicit design call: watch the root, then have the CONTROLLER
 * move the file into 01_Inbox/ after the fact, rather than having Obsidian
 * sort on save — the controller stays the controller (MVC boundary, AGENTS.md §2).
 *
 * A stub is often created empty and filled in later (founder clicks
 * through, navigates away, comes back and types a blurb, saves) — so this
 * watches for BOTH 'add' and 'change' on root-level .md files, and only
 * acts once the file has real (non-whitespace) content. An empty stub is
 * left alone indefinitely; it's picked up the moment it stops being empty.
 *
 * Once captured, the file is renamed into 01_Inbox/'s naming convention
 * using capture-inbox-item.js's own sequencing helpers (never duplicated —
 * see that file's module.exports) so it flows into the EXISTING
 * Candidate→Promoted pipeline completely unchanged from there. The
 * original root-level filename (the wikilink term itself, e.g.
 * "Epistemology") becomes the Inbox slug directly — a much more meaningful
 * signal than extracting keywords from a two-sentence blurb.
 *
 * Founder's stated intent (see /areas/temetics-workbench.md): this is
 * meant to make the filesystem "balloon" on purpose — an ever-growing
 * local working-definition set, each entry eligible for later inclusion in
 * the training cascade (see infra/promote-to-references.js for that path).
 */

const fs = require('fs');
const path = require('path');
const chokidar = require('chokidar');
const { acquireSingleInstanceLock } = require('./lib/single-instance-lock');
const { INBOX_DIR, todayStamp, nextCounter, wrapPayload } = require('./capture-inbox-item');

const VAULT_ROOT = path.join(__dirname, '..');

// Root-level files that are never wikilink stubs, no matter their content —
// checked by exact basename, not pattern, so nothing here is accidentally
// swept into the Inbox pipeline.
const ROOT_EXCLUSIONS = new Set(['README.md', 'AGENTS.md', 'AGENTS.md_old']);

const SOURCE_TAG = 'wikilink';

acquireSingleInstanceLock(path.join(__dirname, '.capture-obsidian-stub.lock'), 'capture-obsidian-stub.js');

function slugFromStubFilename(filePath) {
  const base = path.basename(filePath, '.md');
  return base
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '') || 'untitled';
}

let pipelineQueue = Promise.resolve();
function queuePipelineAction(actionFn) {
  pipelineQueue = pipelineQueue.then(async () => {
    try { await actionFn(); }
    catch (err) { console.error('❌ Stub-Capture Pipeline Fault:', err.message); }
  });
  return pipelineQueue;
}

function captureIfReady(filePath) {
  return queuePipelineAction(async () => {
    if (!fs.existsSync(filePath)) return; // already captured+removed, or a stray unlink event

    const content = fs.readFileSync(filePath, 'utf8').trim();
    if (!content) return; // still an empty stub — leave it, wait for the founder to fill it in

    if (!fs.existsSync(INBOX_DIR)) fs.mkdirSync(INBOX_DIR, { recursive: true });

    const dateStamp = todayStamp();
    const counter = String(nextCounter(dateStamp)).padStart(3, '0');
    const slug = slugFromStubFilename(filePath);
    const fileName = `${SOURCE_TAG}-${dateStamp}-${counter}-${slug}.md`;
    const targetPath = path.join(INBOX_DIR, fileName);

    // RFC-001 frontmatter: a wikilink stub is founder-authored, local, no
    // upstream extracted_tag/keywords to preserve — same minimal shape as
    // a bare capture-inbox-item.js call. inbox-to-candidate.js's existing
    // wikilink-slug special case (source === 'wikilink') is untouched by
    // this; it still reads the slug from the filename, not the frontmatter.
    const fileContent = wrapPayload(content, { source: SOURCE_TAG, sourceNode: 'Node M' });

    // Write first, then remove the original — never delete-before-confirming
    // the write landed, per the reversibility-first practice (AGENTS.md §6).
    fs.writeFileSync(targetPath, fileContent, 'utf8');
    fs.unlinkSync(filePath);

    console.log(`✅ [Stub Captured] "${path.basename(filePath)}" → 01_Inbox/${fileName}`);
  });
}

// depth: 0 — top-level of the vault root only. This is what makes the
// exclusion of every pipeline subdirectory (00_Canon/, 01_Inbox/, etc.)
// automatic rather than an ever-growing ignore list: they're never
// descended into in the first place.
const watcher = chokidar.watch(VAULT_ROOT, {
  persistent: true,
  ignoreInitial: true,
  depth: 0,
  awaitWriteFinish: { stabilityThreshold: 600, pollInterval: 100 }
});

watcher.on('all', (event, filePath) => {
  if (!filePath.endsWith('.md')) return;
  if (event !== 'add' && event !== 'change') return;
  const baseName = path.basename(filePath);
  if (ROOT_EXCLUSIONS.has(baseName)) return;
  captureIfReady(filePath);
});

console.log('🚀 Capture-Obsidian-Stub (vault root → 01_Inbox/) Active. Monitoring vault root (depth 0)...');
