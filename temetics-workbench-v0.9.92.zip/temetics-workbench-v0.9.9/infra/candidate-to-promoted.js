/**
 * candidate-to-promoted.js
 *
 * Manifesto v4.0 §5.5: the exterior R3 gate, mandatory (not informative).
 * Gate language stays "cleared the local gate" / "ready for Alliance
 * review" — never "verified."
 *
 * v4.0 correction from prior v0.9.x behavior, made alongside the same
 * fix in promote-to-references.js (§5.8):
 *
 *  1. Terminal state now lives in `gate_status`, not the shared `status`
 *     field. `status` remains exactly as promotion-helper.js's Interior
 *     cascade uses it (`training` / `ready`, a claim marker unrelated to
 *     gate lifecycle) — untouched here, out of scope for this pass.
 *
 *  2. On CONSISTENT: `gate_status: 'parallax_pending'` (§5.5's "awaiting
 *     Alliance review" value — not the old terminal 'promoted' string,
 *     which pre-empted a state ownership problem: 03_Promoted/ is a
 *     holding stage, not a completed-work archive).
 *
 *  3. Real bug fixed: the previous version wrote the promoted frontmatter
 *     + verification_receipt ONLY to the new file in 03_Promoted/ — the
 *     original file at `filePath` (still in 02_Candidate/) was never
 *     updated or removed. Its own idempotency guard (`if
 *     (frontmatter.promoted_at) return;`) checked the SOURCE file's
 *     frontmatter, which never got `promoted_at` written to it — so any
 *     daemon restart (ignoreInitial:false re-scans the whole folder) or
 *     duplicate save event re-ran the substrate call from scratch on
 *     every already-promoted candidate indefinitely, silently burning
 *     substrate calls and risking a flipped verdict overwriting the
 *     target file. Fixed by moving (not copying) the file out of
 *     02_Candidate/ on success, matching §5.8's move semantics — file
 *     existence at the source path is now the guard, same pattern as
 *     promote-to-references.js.
 *
 *  4. Real bug fixed: on INCONSISTENT/UNDERDETERMINED, only a
 *     `.validation-failed.log` sibling was written — the candidate's own
 *     frontmatter was never touched, so it was indistinguishable from an
 *     unprocessed file and got re-verified (another live substrate call)
 *     on every subsequent event, forever. Fixed by writing `gate_status:
 *     'local_gate_declined'` back onto the candidate in place — per
 *     §5.5, a declined item is left in `02_Candidate/`, tagged, not moved
 *     anywhere. It is never auto-removed; only a manual founder deletion
 *     removes it (consistent with the same rule for declined items in
 *     03_Promoted/).
 */

require('dotenv').config();

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const chokidar = require('chokidar');
const grayMatter = require('gray-matter');
const Ajv = require('ajv');
const { acquireSingleInstanceLock } = require('./lib/single-instance-lock');
const { findManifestEntry, loadReferenceDoc } = require('./lib/reference-manifest');
const { ALWAYS_ON_TRAINING } = require('./lib/pipeline-mode');
const { normalizeDDC } = require('./lib/ddc');

const ajv = new Ajv({ allErrors: true });

// 1. PATH GEOGRAPHY
const CANDIDATE_DIR = path.join(__dirname, '../02_Candidate');
const PROMOTED_DIR = path.join(__dirname, '../03_Promoted');
const CANON_DIR = path.join(__dirname, '../00_Canon');
const LEXICON_DIR = path.join(__dirname, '../lexicons');

const LEXICON_PATH = path.join(LEXICON_DIR, 'workspace-lexicon.json');
const KG_PATH = path.join(CANON_DIR, 'temetic-kg-v0.1.json');

// Generic substrate configuration
const CORE_AGENT_KEY = process.env.CORE_AGENT_KEY;
const CORE_AGENT_MODEL = process.env.CORE_AGENT_MODEL;
const CORE_AGENT_ENDPOINT = process.env.CORE_AGENT_ENDPOINT;

if (!CORE_AGENT_KEY || !CORE_AGENT_MODEL || !CORE_AGENT_ENDPOINT) {
  console.error("❌ [Config Error] Missing required CORE_AGENT_* environment variables.");
  process.exit(1);
}

// Retry/backoff config — scoped to transport-layer failures only (network
// throws, and HTTP statuses that indicate transient backend congestion, per
// the empirically-confirmed 503 root cause). A malformed/unparseable model
// response is a content problem, not a transport one, and is NOT retried
// here — retrying that silently masks a real schema-format regression.
const SUBSTRATE_MAX_ATTEMPTS = parseInt(process.env.SUBSTRATE_MAX_ATTEMPTS || '4', 10);
const SUBSTRATE_BASE_DELAY_MS = parseInt(process.env.SUBSTRATE_BASE_DELAY_MS || '1000', 10);
const RETRYABLE_STATUS_CODES = new Set([429, 500, 502, 503, 504]);

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

acquireSingleInstanceLock(path.join(__dirname, '.candidate-to-promoted.lock'), 'candidate-to-promoted.js');

// Ensure directories
if (!fs.existsSync(PROMOTED_DIR)) fs.mkdirSync(PROMOTED_DIR, { recursive: true });

// 2. SCHEMA DEFINITIONS
const verificationReceiptSchema = {
  type: "object",
  properties: {
    status: { type: "string", enum: ["CONSISTENT", "INCONSISTENT", "UNDERDETERMINED"] },
    referenced_rules: { type: "array", items: { type: "string" } },
    evaluated_rules: { type: "array", items: { type: "string" } },
    evidence: {
      type: "array",
      items: {
        type: "object",
        properties: {
          candidate_quote: { type: "string" },
          kernel_rule: { type: "string" },
          // Punch list #5 / bug #5 (audit-trail asymmetry): reasoning is
          // expected to embed an inline [cite: doc-id] tag whenever it draws
          // on a specific SUPPLEMENTARY document, e.g. "...[cite: holster]".
          // Not schema-enforced here (a model can't be forced to cite what
          // it didn't use) — verifyCitations() below cross-checks whatever
          // tags DO appear against what was actually supplied, deterministically.
          reasoning: { type: "string" },
          confidence: { type: "number", minimum: 0, maximum: 1 }
        },
        required: ["candidate_quote", "kernel_rule", "reasoning", "confidence"]
      }
    },
    // supported_mapping: deliberately modest — a literal restatement of
    // exactly what evidence-to-axiom mapping this evaluation established,
    // no extrapolation. kernel_projection: the existing ambitious synthesis.
    // Splitting these addresses GPT's independent critique (kernel_projection
    // "sounds like a theorem while the receipt only established a mapping")
    // and gives bug #3's forced-conclude handling below something honest to
    // fall back to when the full synthesis wasn't actually earned.
    supported_mapping: { type: "string" },
    kernel_projection: { type: "string" }
  },
  required: ["status", "referenced_rules", "evaluated_rules", "evidence", "supported_mapping", "kernel_projection"],
  additionalProperties: false
};
const validateVerificationReceipt = ajv.compile(verificationReceiptSchema);

// 3. PIPELINE SERIALIZATION
let pipelineQueue = Promise.resolve();
function queuePipelineAction(actionFn) {
  pipelineQueue = pipelineQueue.then(async () => {
    try { await actionFn(); } 
    catch (err) { console.error("❌ CtP Pipeline Fault:", err.message); }
  });
  return pipelineQueue;
}

// 4. DETERMINISTIC HELPERS
function computeSha256(content) {
  return crypto.createHash('sha256').update(content, 'utf8').digest('hex');
}

function normalizeToHyphenCase(str) {
  if (!str) return '';
  return str
    .replace(/([a-z0-9])([A-Z])/g, '$1-$2')
    .replace(/[\s_]+/g, '-')
    .toLowerCase()
    .replace(/--+/g, '-')
    .replace(/^-|-$/g, '');
}

// Punch list #5 / bug #5 fix: don't rely on prose happening to mention a
// doc's name — extract the model's own [cite: doc-id] tags mechanically and
// cross-verify each against the docs actually supplied to THIS call. The KG
// itself is always "supplied" and doesn't require a supplementary tag.
const CITE_TAG_REGEX = /\[cite:\s*([a-zA-Z0-9_-]+)\]/g;

function extractCitedDocIds(evidence) {
  const ids = new Set();
  for (const item of (evidence || [])) {
    if (typeof item.reasoning !== 'string') continue;
    CITE_TAG_REGEX.lastIndex = 0;
    let match;
    while ((match = CITE_TAG_REGEX.exec(item.reasoning)) !== null) {
      ids.add(match[1]);
    }
  }
  return Array.from(ids);
}

function verifyCitations(evidence, supplementaryDocs) {
  const suppliedIds = new Set(['kg', ...(supplementaryDocs || []).map(d => d.id)]);
  const cited = extractCitedDocIds(evidence);
  const unverified = cited.filter(id => !suppliedIds.has(id));
  return { cited, unverified, verified: unverified.length === 0 };
}

// 5. SUBSTRATE VERIFICATION
async function runSubstrateVerification(candidateBody, algebraicKg, supplementaryDocs) {
  // supplementaryDocs: array of {id, content} resolved from a candidate's
  // training_reference_docs frontmatter (written by promotion-helper.js's
  // Interior cascade, if it ran on this file). KG-first remains the DEFAULT
  // — this is additive, not a replacement, and only present when a prior
  // training pass identified something the KG-only default didn't cover.
  // The substrate call itself is still a single, fresh (amnesiac) request —
  // training doesn't get replayed here, only its conclusion (which docs
  // mattered) does.
  const supplementarySection = (supplementaryDocs && supplementaryDocs.length)
    ? `\n### SUPPLEMENTARY REFERENCE MATERIAL (identified by prior Interior-mode training as relevant to this specific candidate)\n${supplementaryDocs.map(d => `--- ${d.id} ---\n${d.content}`).join('\n\n')}\n`
    : '';

  const prompt = `You are a high-fidelity LOCAL verification substrate performing a local coherence check only.

Evaluate the candidate document against the provided Algebraic Temetic Knowledge Graph.
This is NOT P0 substrate-independent verification. This is a local gate check only.

### REFERENCE CONSTRAINT SYSTEM
${JSON.stringify(algebraicKg, null, 2)}
${supplementarySection}
### CANDIDATE DOCUMENT
${candidateBody}

### INSTRUCTIONS
1. Only evaluate claims that are actually present in the candidate. Do not infer unstated premises.
2. If the document is too vague or completely outside the domain, return status "UNDERDETERMINED".
3. Map claims directly back to the active rules (P0 through P6).
4. Provide exact "candidate_quote" matches for any evidence.
5. Return ONLY valid JSON. No extra text.
6. "supported_mapping" and "kernel_projection" are DIFFERENT and must not be merged:
   - supported_mapping: a modest, literal restatement of exactly what evidence-to-axiom mapping this evaluation established. No extrapolation, no generalization beyond what the evidence array actually shows.
   - kernel_projection: an ambitious 1-2 sentence substrate-invariant synthesis of the candidate's core thesis, going beyond the literal mapping if the evidence supports it.
7. Whenever an evidence item's "reasoning" draws on a specific SUPPLEMENTARY reference document (not the Algebraic Temetic Knowledge Graph itself), embed an inline tag using that document's exact id from its "--- id ---" header, e.g. "...establishes X [cite: holster]." Omit the tag if reasoning only draws on the Knowledge Graph above.

{
  "status": "CONSISTENT" | "INCONSISTENT" | "UNDERDETERMINED",
  "referenced_rules": ["P0", "P1"],
  "evaluated_rules": ["P2", "P3"],
  "evidence": [
    {
      "candidate_quote": "exact quote from candidate",
      "kernel_rule": "P3",
      "reasoning": "explanation of mapping or violation, with [cite: doc-id] if a supplementary document was used",
      "confidence": 0.95
    }
  ],
  "supported_mapping": "literal restatement of exactly what was established — no extrapolation",
  "kernel_projection": "1-2 sentence substrate-invariant core thesis"
}`;

  async function fetchWithRetry() {
    let lastError;

    for (let attempt = 1; attempt <= SUBSTRATE_MAX_ATTEMPTS; attempt++) {
      try {
        const response = await fetch(CORE_AGENT_ENDPOINT, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${CORE_AGENT_KEY}`
          },
          body: JSON.stringify({
            model: CORE_AGENT_MODEL,
            messages: [{ role: 'user', content: prompt }],
            temperature: 0.1
          })
        });

        if (!response.ok) {
          const err = new Error(`HTTP ${response.status}`);
          err.status = response.status;
          throw err;
        }

        return response;
      } catch (error) {
        lastError = error;

        const isRetryableStatus = typeof error.status === 'number' && RETRYABLE_STATUS_CODES.has(error.status);
        const isNetworkThrow = typeof error.status !== 'number'; // fetch() itself threw — treat as transient
        const isLastAttempt = attempt === SUBSTRATE_MAX_ATTEMPTS;

        if ((isRetryableStatus || isNetworkThrow) && !isLastAttempt) {
          const delayMs = SUBSTRATE_BASE_DELAY_MS * Math.pow(2, attempt - 1) + Math.floor(Math.random() * 250);
          console.warn(`⚠️ Substrate call failed (attempt ${attempt}/${SUBSTRATE_MAX_ATTEMPTS}): ${error.message}. Retrying in ${delayMs}ms...`);
          await sleep(delayMs);
          continue;
        }

        // Non-retryable status (e.g. 400/401) or attempts exhausted — stop here.
        throw lastError;
      }
    }

    throw lastError;
  }

  try {
    const response = await fetchWithRetry();

    const rawText = (await response.text()).trim();
    let innerContent = JSON.parse(rawText).choices?.[0]?.message?.content?.trim() || '';

    if (innerContent.startsWith("```")) {
      innerContent = innerContent.replace(/^```json\s*/i, "").replace(/```$/, "").trim();
    }

    const verificationPayload = JSON.parse(innerContent);

    if (!validateVerificationReceipt(verificationPayload)) {
      console.warn("⚠️ Invalid verification format from substrate.");
      return { status: "UNDERDETERMINED", referenced_rules: [], evaluated_rules: [], evidence: [], supported_mapping: "N/A — parser mismatch", kernel_projection: "Parser mismatch", citation_check: { cited: [], unverified: [], verified: true } };
    }

    const citationCheck = verifyCitations(verificationPayload.evidence, supplementaryDocs);
    if (!citationCheck.verified) {
      console.warn(`⚠️ [Citation Check] Unverified [cite:] tag(s) not in supplied docs: ${citationCheck.unverified.join(', ')}`);
    }

    return { ...verificationPayload, citation_check: citationCheck };
  } catch (error) {
    console.error("❌ Verification failed:", error.message);
    return { status: "UNDERDETERMINED", referenced_rules: [], evaluated_rules: [], evidence: [], supported_mapping: "N/A — transport error", kernel_projection: `Transport error: ${error.message}`, citation_check: { cited: [], unverified: [], verified: true } };
  }
}

// 6. PIPELINE EXECUTION
async function evaluateAndPromote(filePath) {
  await queuePipelineAction(async () => {
    if (!fs.existsSync(filePath)) return;

    const fileContent = fs.readFileSync(filePath, 'utf8');
    const parsedFile = grayMatter(fileContent);
    const { data: frontmatter } = parsedFile;
    const body = parsedFile.content.trim();

    // IDEMPOTENCY GUARD — real gap found in live testing: without this, ANY
    // add/change event on an already-gated file (including a daemon
    // restart re-scanning the whole folder, since chokidar runs with
    // ignoreInitial:false) re-runs the substrate call at temperature 0.1 —
    // not 0, not guaranteed identical — and can silently overwrite a
    // perfectly good verification_receipt with a different one. `parallax_
    // pending` is unconditionally terminal here — file existence at this
    // path already implies the move to 03_Promoted/ hasn't happened yet,
    // and re-gating a file that's already cleared makes no sense.
    if (frontmatter.gate_status === 'parallax_pending') {
      console.log(`⏭️  Skipping ${path.basename(filePath)} — already gated (gate_status: parallax_pending).`);
      return;
    }

    // `local_gate_declined` is DELIBERATELY NOT a permanent skip — doing so
    // was a regression caught on audit: promotion-helper.js's reactive mode
    // (see shouldTrain's failedLogPath branch) exists specifically to pick
    // up a declined candidate, run an Interior cascade with newly-selected
    // reference docs, and clear the failure marker so this script re-gates
    // it — that retry loop is the whole point of local_gate_declined, and a
    // flat "declined == done" skip silently breaks it (the candidate would
    // sit declined forever even after being retrained to fix the gap).
    // What actually needs guarding against is the ORIGINAL bug: a
    // no-op re-trigger (restart, duplicate save) re-verifying a declined
    // file that hasn't changed since it was declined. Distinguish the two
    // by timestamp: only skip if there's no training_completed_at newer
    // than the decline — i.e. nothing happened since the decline that
    // would justify another substrate call.
    if (frontmatter.gate_status === 'local_gate_declined') {
      const declinedAt = frontmatter.local_gate_declined_at;
      const retrainedAt = frontmatter.training_completed_at;
      const retrainedSinceDecline = retrainedAt && declinedAt && new Date(retrainedAt) > new Date(declinedAt);
      if (!retrainedSinceDecline) {
        console.log(`⏭️  Skipping ${path.basename(filePath)} — declined at ${declinedAt}, no retraining since.`);
        return;
      }
      console.log(`🔁 Re-evaluating ${path.basename(filePath)} — retrained at ${retrainedAt}, after prior decline at ${declinedAt}.`);
    }

    // Concurrency guard against promotion-helper.js's Interior training
    // cascade racing on the same file — it claims status: training the
    // moment it starts working a candidate, and flips back to ready when
    // done (see promotion-helper.js's evaluateForTraining).
    if (frontmatter.status === 'training') {
      console.log(`⏭️  Skipping ${path.basename(filePath)} — currently claimed by promotion-helper.js (status: training).`);
      return;
    }

    // ALWAYS_ON_TRAINING mode: defer a brand-new, not-yet-trained candidate
    // to promotion-helper.js rather than gating it immediately, so the
    // gate's FIRST look at it already has cascade-selected reference
    // material attached instead of KG-only. This is best-effort ordering,
    // not a hard guarantee — both daemons watch 02_Candidate/ independently
    // with no shared lock beyond the status field itself, so there's a real
    // (small) race window right after inbox-to-candidate.js mints a file
    // and before promotion-helper.js's claim write lands. If
    // promotion-helper.js isn't actually running, this file will stall here
    // indefinitely — flip ALWAYS_ON_TRAINING off in pipeline-mode.js if that
    // happens, or run this script with --no-defer once that flag exists.
    if (ALWAYS_ON_TRAINING && !frontmatter.training_completed_at) {
      console.log(`⏳ Deferring ${path.basename(filePath)} to promotion-helper.js first (ALWAYS_ON_TRAINING mode).`);
      return;
    }

    // Deterministic hash check (P6)
    // Must trim to match how inbox-to-candidate.js computed the stored hash —
    // gray-matter's .content keeps the leading/trailing blank line around the
    // frontmatter delimiter, which otherwise changes the hash independent of
    // any real edit to the claim text.
    const currentHash = computeSha256(body);
    if (frontmatter.raw_content_sha256 !== currentHash) {
      console.error(`[P6 FAILURE] Hash mismatch for ${path.basename(filePath)}. Expected: ${frontmatter.raw_content_sha256}, got: ${currentHash}. Not promoting.`);
      return;
    }

    const rawDdc = frontmatter.ddc || "000";
    const assignedDdc = normalizeDDC(rawDdc);
    if (assignedDdc !== rawDdc) {
      console.log(`[DDC Guard] "${rawDdc}" → normalized to "${assignedDdc}"`);
    }

    // Load KG
    let algebraicKg = {};
    if (fs.existsSync(KG_PATH)) {
      try {
        algebraicKg = JSON.parse(fs.readFileSync(KG_PATH, 'utf8'));
      } catch (err) {
        console.error("⚠️ Failed to load KG.", err.message);
      }
    }

    console.log(`🔍 Running local gate on ${path.basename(filePath)}...`);

    // KG-first is still the default. This only adds material a prior
    // Interior training pass specifically flagged for THIS candidate — see
    // reference-manifest.js's note on why "KG exclusively first" is a
    // heuristic default, not a hard constraint the axioms themselves impose.
    let supplementaryDocs = [];
    if (Array.isArray(frontmatter.training_reference_docs) && frontmatter.training_reference_docs.length) {
      supplementaryDocs = frontmatter.training_reference_docs
        .map(id => ({ id, content: loadReferenceDoc(id) }))
        .filter(d => d.content !== null);
    }

    const receipt = await runSubstrateVerification(body, algebraicKg, supplementaryDocs);

    if (receipt.status === "CONSISTENT") {
      // Bug #3/#7 fix: a candidate whose Interior cascade never reached an
      // explicit model CONCLUDE (round cap exhausted, stagnant round,
      // malformed JSON, or transport failure — see promotion-helper.js's
      // cascade_incomplete) may have been gated on a document set the model
      // itself hadn't finished exploring. Still promote on CONSISTENT (that
      // verdict is real), but don't let the receipt claim the ambitious
      // kernel_projection synthesis when the cascade behind it was cut
      // short — supported_mapping (the modest, literal restatement) is all
      // that's honestly earned in that case.
      const cascadeIncomplete = frontmatter.cascade_incomplete === true;
      if (cascadeIncomplete) {
        console.warn(`⚠️ [Receipt] ${path.basename(filePath)} promoted on an incomplete Interior cascade — withholding kernel_projection, keeping supported_mapping only.`);
      }

      // gate_status now owns the lifecycle state (§5.5); `status` stays
      // reserved for promotion-helper.js's training/ready claim marker,
      // so it's dropped here rather than left holding a stale 'ready'
      // value that would read as self-contradictory next to a completed
      // verification_receipt (the same problem the old terminal
      // status: 'promoted' write was patching, just via the wrong field).
      const { status: _droppedClaimStatus, ...frontmatterWithoutClaimStatus } = frontmatter;
      const promotedFrontmatter = {
        ...frontmatterWithoutClaimStatus,
        ddc: assignedDdc,
        gate_status: 'parallax_pending',
        promoted_at: new Date().toISOString(),
        // RFC-002 workflow (founder ruling, parallax-schema thread): every
        // promoted item is a Parallax candidate from the moment it lands
        // here, not just once explicitly picked. awaiting_parallax starts
        // false so nothing ships until the founder deliberately opts an
        // item in; founder_note is per-item (not the RFC-002 batch-level
        // founder_directive, which is kept separately, blank, in the
        // 04_To_Parallax/ manifest itself) — both are filled by hand in
        // Obsidian before promoted-to-parallax.js is ever run.
        awaiting_parallax: false,
        founder_note: '',
        verification_receipt: {
          status: receipt.status,
          referenced_rules: receipt.referenced_rules,
          evaluated_rules: receipt.evaluated_rules,
          evidence: receipt.evidence,
          supported_mapping: receipt.supported_mapping,
          citation_check: receipt.citation_check,
          kernel_projection: cascadeIncomplete
            ? "Withheld — this candidate's Interior training cascade was cut short before an explicit model CONCLUDE (see .training-cascade.log), so the full reference set it flagged was never confirmed reviewed. See supported_mapping for the literal evidence-to-axiom mapping that WAS established."
            : receipt.kernel_projection
        }
      };

      const promotedContent = grayMatter.stringify(body, promotedFrontmatter);
      const targetPath = path.join(PROMOTED_DIR, path.basename(filePath));

      // Move, not copy: write the destination first (so the audit-chain
      // content exists at 03_Promoted/ before anything is removed), then
      // remove the source. Matches §5.8's move semantics for the next
      // stage and closes the idempotency gap above — once removed, there
      // is nothing left in 02_Candidate/ for a restart or duplicate event
      // to re-process.
      fs.writeFileSync(targetPath, promotedContent, 'utf8');
      fs.unlinkSync(filePath);

      console.log(`✅ [PROMOTED] Local gate cleared: ${path.basename(filePath)} → 03_Promoted/`);
    } else {
      console.warn(`❌ [REJECTED] ${path.basename(filePath)} → ${receipt.status}`);

      const failedLogPath = filePath.replace(/\.md$/, '.validation-failed.log');
      fs.writeFileSync(failedLogPath, JSON.stringify(receipt, null, 2), 'utf8');
      console.log(`📝 [Logged Failure] Details written to: ${path.basename(failedLogPath)}`);

      // §5.5: local_gate_declined is left in place in 02_Candidate/,
      // tagged, not moved — and never auto-removed (only a manual founder
      // deletion removes it). Writing this back is what stops the
      // re-verify-forever loop the old code had for declined candidates.
      const declinedFrontmatter = {
        ...frontmatter,
        gate_status: 'local_gate_declined',
        local_gate_declined_at: new Date().toISOString()
      };
      fs.writeFileSync(filePath, grayMatter.stringify(body, declinedFrontmatter), 'utf8');
    }
  });
}

// 7. DAEMON
const watcher = chokidar.watch(CANDIDATE_DIR, {
  persistent: true,
  ignoreInitial: false,
  awaitWriteFinish: { stabilityThreshold: 600, pollInterval: 100 }
});

const NON_CANDIDATE_FILENAMES = new Set(['README.md']);

watcher.on('all', (event, filePath) => {
  if (filePath.endsWith('.md') && (event === 'add' || event === 'change')) {
    const baseName = path.basename(filePath);
    if (NON_CANDIDATE_FILENAMES.has(baseName)) return;
    evaluateAndPromote(filePath);
  }
});

console.log('🚀 Candidate-to-Promoted Pipeline (gate_status, move-not-copy) Active. Monitoring 02_Candidate...');