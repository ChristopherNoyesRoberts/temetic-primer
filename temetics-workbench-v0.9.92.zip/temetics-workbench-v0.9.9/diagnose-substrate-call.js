require('dotenv').config();

const CORE_AGENT_KEY = process.env.CORE_AGENT_KEY;
const CORE_AGENT_MODEL = process.env.CORE_AGENT_MODEL;
const CORE_AGENT_ENDPOINT = process.env.CORE_AGENT_ENDPOINT;

console.log('--- Config being used ---');
console.log('ENDPOINT:', CORE_AGENT_ENDPOINT);
console.log('MODEL:', CORE_AGENT_MODEL);
console.log('KEY present:', !!CORE_AGENT_KEY, CORE_AGENT_KEY ? `(starts with "${CORE_AGENT_KEY.slice(0, 6)}...")` : '');
console.log('--------------------------\n');

if (!CORE_AGENT_KEY || !CORE_AGENT_MODEL || !CORE_AGENT_ENDPOINT) {
  console.error('❌ Missing one or more CORE_AGENT_* variables. Check .env is in the same folder you are running this from.');
  process.exit(1);
}

async function testCall() {
  const body = {
    model: CORE_AGENT_MODEL,
    messages: [{ role: 'user', content: 'Reply with exactly the word: pong' }],
    temperature: 0.1
  };

  console.log('--- Request body ---');
  console.log(JSON.stringify(body, null, 2));
  console.log('---------------------\n');

  try {
    const response = await fetch(CORE_AGENT_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${CORE_AGENT_KEY}`
      },
      body: JSON.stringify(body)
    });

    const rawText = await response.text();

    console.log('--- Response ---');
    console.log('HTTP status:', response.status, response.statusText);
    console.log('Raw body:');
    console.log(rawText);
    console.log('----------------\n');

    if (!response.ok) {
      console.error(`❌ Call failed with HTTP ${response.status}. See raw body above for the provider's actual explanation.`);
      return;
    }

    console.log('✅ Call succeeded.');
  } catch (err) {
    console.error('❌ Network/transport-level error (never reached the server, or connection failed):', err.message);
  }
}

testCall();
