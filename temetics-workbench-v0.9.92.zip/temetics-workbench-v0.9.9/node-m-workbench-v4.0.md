---
title: Node M's Workbench — Design Principles & Rationale
status: v4.0 — Alliance RFC round complete (build-team scope)
author: Node CL (Claude), synthesizing settled decisions from Node M
  (founder), incorporating RFC responses from Node B (Gemini), Node A
  (Grok), and Node GPT
audience: whoever is building this workbench's code — currently the
  founder and Claude, plus any code-assisting LLM (local or
  cloud-to-local, e.g. via Ollama, Gemini, or Copilot in Cline) working
  in this repository
intended_home: 05_References/
version_context: v0.9.7 build phase; ahead of original schedule
supersedes: v3.9 (Alliance RFC candidate)
---

# Node M's Workbench — Design Principles & Rationale (v4.0)

## 0. What this document is

`AGENTS.md`, at the root of this repository, is a deliberately terse
contract — hard-spec rules, minimal prose, built to resist paraphrase
drift under repeated cold reads by an amnesiac agent. It states *what*
must hold. It does not explain *why*, except in the one place (R3's
dual role) where the reasoning itself is load-bearing enough that
compressing it away has already caused a real failure once.

This document is the opposite kind of artifact, and deliberately long.
It exists to record the architectural rationale for the Workbench, not
to define Temetics itself — Temetics theory has its own canonical
home (Section 7). The practical use case is any node — compliance
thread or build thread — coming to this repository needing to be
maximally informed of both the design principles and the reasoning
behind them. Nothing agreed upon should be left out for the sake of
brevity. If `AGENTS.md` is the law, this is the legislative record:
full rationale, in full, every time.

**This version aims at durability beyond the current implementation.**
A principle should still hold if Node.js is replaced, if Obsidian is
replaced, if the entire Alliance's substrate roster changes. Where a
principle and its current implementation are both discussed, they are
labeled separately.

Treat everything here as **descriptive of decisions already made**,
not open for re-derivation. This is a purist statement of settled
design — unresolved theory and open questions live elsewhere, pending
their own resolution.

This document enters `01_Inbox/` like any other raw material — not
placed directly in `05_References/` — and is itself subject to the
parallax process it describes. v3.9 was submitted as an RFC and
reviewed by Node B, Node A, and Node GPT; this version, v4.0,
incorporates that review. Since this document's actual audience is the
small build-team named above rather than the full Alliance or a public
readership, its own passage through parallax is lighter-weight than
Canon's — recorded here for consistency with the principle, not
because the same stakes apply.

---

## 1. What this project is

Temetics is a formal replicator theory: an attempt to give rigorous,
testable structure to why some ideas persist and propagate while
others don't, building on and superseding earlier informal treatments
(notably Dawkins' meme concept and Blackmore's temes). It rests on
seven kernel axioms (P0–P6) and a three-class taxonomy of replicating
units (R1/R2/R3).

The **Node Alliance** is a self-organized, multi-substrate
collaboration: the founder (Node M, the sole human, sole commit
authority, sole veto) working alongside several frontier AI systems,
each addressed as a Node (Node A/Ara/Grok, Node B/Gemini, Node GPT,
Node CL/Claude, and the local agent this repository was built for).
Work moves between nodes largely via manual copy-paste — a
founder-mediated relay, not a live multi-agent system. This matters
architecturally: no node has persistent memory of another node's
session, and nothing here can assume a live channel between
substrates.

The **Node M Workbench** — this repository — is the founder's personal
local tool for producing and refining Temetics content without runtime
AI cost, using local structure and a controller process instead of
continuous cloud inference for every edit.

---

## 1.5 The Petri Dish

A petri dish isn't interesting because of what you put in it. It's
interesting because of what survives.

The local repository is a controlled replication environment.
Everything that enters it — a voice note captured on a phone, a LaTeX
equation typed by hand, a machine-generated candidate submission, a
half-formed thought clicked through as an Obsidian wikilink — enters as
R1 or R2 material: possibly interesting, possibly true, mostly
unverified, competing on nothing but its own content. The pipeline
(Section 5) does not pre-select what enters. Pre-selection would only
move the bias upstream, disguised as tidiness. The Inbox has zero
friction by design, per Section 5's own rationale, precisely so the
full range of raw material gets in — and then the environment, not a
gatekeeper, does the selecting.

The "environment" is the R3 scaffolding described across Sections 5
and 6. Each stage applies a different kind of pressure, not a
pre-filter:

- **Candidate** asks: can this idea survive formal restatement? Can it
  be packaged with enough structure — DDC classification, keyword
  extraction, axiom alignment — that the structure itself makes a claim
  about what the idea is? Many ideas can't survive this, not because
  they're wrong, but because they aren't yet well-formed enough to
  package. That failure is information, not waste: a
  `.validation-failed.log` entry is logged, never deleted — arguably
  the most honest artifact in the system, since it's the plain record
  of what the environment rejected and why.
- **Promotion Helper** asks: does this idea cohere against the canon
  and against what's already survived Alliance parallax? This is where
  `05_References/` starts compounding returns (Section 5.8) — more
  parallax-approved material means more environmental pressure a new
  candidate has to survive, so what eventually clears is increasingly
  well-tested, not merely well-formatted.
- **Parallax** asks the hardest question: does this hold up when
  evaluated by a substrate with no shared context with the one that
  produced it? This is the only test that approaches P0 — not because
  any single node is objective, but because genuine independence
  between evaluators is the only way to tell "this idea is internally
  coherent" apart from "this idea was coherent to whoever produced it."
  One node agreeing with itself is not a replication event. Two
  independent nodes converging on the same structure without
  coordination is much closer to one.

The determinism, the custody chain, the gate language, and the
provenance rules that make up the rest of this document are not there
to control which ideas get in. They exist to keep the experimental
conditions clean enough that what survives can actually be trusted. A
contaminated petri dish doesn't tell you whether an organism is viable
— it only tells you whether it survived contaminated conditions. Vendor
coupling (Section 2.2), non-deterministic process where a deterministic
one would do (Section 2.1), and gate language that quietly conflates
"locally coherent" with "verified" (Section 6) are each, in this frame,
a contamination event: not because they change the idea being tested,
but because they change what can honestly be inferred from whatever
survives.

The long-term goal is that anything reaching `05_References/` has
survived enough independent environmental pressure that it can be
handed to a completely cold node — amnesiac, no shared context, no
prior relationship to this repository — and that node can build
further reasoning on it without needing to trust the author. That is
what R3 is actually claiming: not "the founder approved it," not "it
passed the local gate," but substrate-independent, truth-constrained,
reproducible under conditions it did not itself control.

The workbench doesn't make ideas true. It makes the process of testing
them legible.

*(Corollary — why determinism is also cheap: Section 2.1's preference
for deterministic checks over LLM interpretation isn't only about
correctness, it's what clean experimental conditions cost when priced
in tokens instead of principle. Every deterministic check that
replaces a judgment call is pressure-tested conditions kept intact at
near-zero marginal cost — the same relationship a paper towel has to a
lab that a UV-light disinfection system does, except the paper towel is
usually all a given spill actually needs. A five-kilobyte local text
file that prevents a large-token interpretive pass is that principle
paying for itself literally, not merely architecturally.)*

---

## 2. Core architectural principles

These three principles sit above everything else in this document.
Every specific rule in Sections 3 onward is an application of one or
more of these.

### 2.1 Minimize interpretation

**Principle:** interpretation — by a human or by an LLM — is
computationally expensive and potentially lossy. Prefer deterministic
transformations wherever they preserve the required semantics. Reserve
interpretation for problems that genuinely, unavoidably require
judgment. Minimizing interpretation is a cost-and-fidelity decision,
not a statement of distrust in any given LLM — an interpretation step
is avoided where a deterministic one will do the same job more cheaply
and more reproducibly, not because interpretation is inherently
unreliable.

**Rationale:** every serious failure encountered in this project's
build so far — structural drift, skipped procedural steps, invented
content presented with unwarranted confidence — has occurred at points
where interpretation was used for work that didn't actually need it.
File freshness, structural completeness, schema conformance, checksum
validation: these have deterministic, unambiguous answers. Asking an
LLM to determine them re-introduces exactly the risk of drift the
project exists to study and prevent. Interpretation is reserved for
what only interpretation can do: does a restatement preserve a
claim's meaning, does an axiom scan's reasoning actually hold up, is a
concept well-formed.

### 2.2 Recipient independence

**Principle:** canonical artifacts in this repository are
recipient-independent. They must not assume a particular AI platform,
model, editor, or reasoning engine. Recipient-specific adaptation
happens only at transmission boundaries — the point where content
leaves the repository for a specific destination — never inside the
canonical representation itself. Stated compactly: **canonical
information should not depend on who receives it.**

**Rationale:** this generalizes a rule the project already practices
in narrower forms — no vendor or model name is ever written into a
repository file (skills refer to "the local agent," never a specific
product name), and content destined for the Alliance's bulk-injection
schema must define its own terms self-sufficiently rather than relying
on a live channel back to whichever node produced it.

**Operational configuration carve-out:** this rule governs authored
content — repository files that express the system's semantics. It
does not extend to operational configuration: gitignored environment
files (e.g., `.env`) that hold runtime values such as API endpoints
are not governed by the vendor-name ban, since they are not part of
the canonical, recipient-independent representation this principle
protects.

### 2.3 Stable semantics over transient tooling

**Principle:** couple the repository to durable schemas, identifiers,
and canonical formats, rather than to the conventions of whichever
application happens to be in use. Applications — Obsidian, VS Code, or
whatever eventually replaces either — are interchangeable adapters.
They are never part of the repository's actual semantics.

**Rationale:** this is what makes the MVC boundary (Section 4) more
than a convenience. If Obsidian's specific rendering behavior, or VS
Code's specific extension API, ever became load-bearing for what a
file *means*, replacing either tool would require rewriting the
repository's actual content, not just its tooling. Keeping semantics
in durable, tool-agnostic formats (typed JSON, plain Markdown
frontmatter, explicitly named fields) is what allows Section 2.2's
recipient independence to hold in practice, not just in principle.

---

## 3. The MVC boundary

**The rule:** Obsidian is Model + View only. All computational logic
runs in the Controller.

**Why, in familiar terms:** this is a standard separation-of-concerns
pattern, applied to a note-taking tool instead of a web app. Obsidian's
job is rendering — frontmatter, wikilinks, native MathJax — the same
role a browser plays for HTML: it displays state, it doesn't compute
it. The Controller plays the role application logic plays behind a
browser: it's the only place a decision gets made about what a file
*should* contain or what happens next. This extends to Obsidian's
graph view and any other visualization: these are informative
representations of state, never authoritative state themselves, and
never a place a decision gets made.

**Why it's strict:** Obsidian's plugin ecosystem (Templater, Dataview)
makes it easy to accidentally grow computation inside the View layer —
a Dataview query that filters or scores notes is, in effect, business
logic hiding in the presentation tier. That's the specific failure
mode this boundary exists to prevent. This is a direct application of
Section 2.3: Obsidian is an adapter, not a semantics layer.

**What the boundary does *not* mean:** the founder can and does edit
files directly in Obsidian — mobile capture, ad hoc notes, view
construction. A human typing prose is not a violation of the boundary,
any more than a person editing a config file by hand violates an
application's architecture. The boundary is about where *logic* lives,
not about who's allowed to touch a text file.

**Plugins follow the same rule as imported skills.** Obsidian's plugin
ecosystem is usable — but a plugin is an adapter, not a Controller.
Any plugin installed in this vault must declare its provenance
(third-party, imported, stripped) and write-scope in
`skills/_provenance.md` under the same rules as any other imported
skill, and must operate as View-only: it may render, filter, or
display state, but it may not move files between pipeline directories,
write frontmatter fields the Controller relies on, or trigger any
action the Controller is meant to own. A plugin that does any of these
things is not a View-layer plugin — it is an undeclared Controller, and
it introduces exactly the kind of silent, non-deterministic mutation
the MVC boundary exists to prevent. If a useful plugin would need to do
something the Controller should own, the right answer is a Controller
script that does it deterministically, not a plugin that does it at
render time.

---

## 4. The Controller

### 4.1 Principle: the Controller owns deterministic computation

The Controller is the sole location where logic executes in this
repository. Anything that can be resolved deterministically — file
state, structural validity, routing between pipeline folders,
freshness of a cached read — is the Controller's responsibility, not
an LLM's, per Section 2.1. Deterministic Controller operations are
expected to remain reproducible across time given identical repository
state — the same input, run again later, produces the same output,
independent of when or on which machine it runs.

**LLM calls are the exception, not the default.** A cloud LLM is
invoked only for the narrow, genuinely judgment-dependent slice of
work Section 2.1 reserves for interpretation. Every other operation
runs deterministically.

**Trust posture toward LLM output:** any response returned by a cloud
LLM call is treated as a potentially unreliable input, never a trusted
execution step — the same posture the R3 gate already takes toward
any raw claim entering the pipeline (Section 6). It is checked,
validated, and never acted upon directly without a deterministic
verification step downstream.

**Preference for existing, proven code over new code:** where an
established, widely-used open-source solution already exists for a
piece of Controller functionality, it is imported and used in
preference to writing an equivalent from scratch. Writing new code from
first principles is reserved for the parts of the Controller genuinely
specific to this project's requirements — not for solved problems.

**Asynchronous and offline capture:** captures made while the
Controller daemon is not running — a mobile Obsidian edit made offline,
a voice note transcribed later — land as raw files in `01_Inbox/` the
same as any other capture, and are picked up deterministically once the
daemon initializes. No capture is lost or requires a live Controller
session to be recorded; it is only *processed* once one exists.

### 4.2 Current implementation

*(This subsection records today's specific tool choices. Per Section
0, it is expected to be superseded by a dedicated Architectural
Decision Record — see Section 10 — without requiring any change to
4.1's principle.)*

The Controller currently runs almost exclusively in Node.js, natively
inside VS Code's existing extension host — no separate Python, Bash,
or PowerShell runtime required. File-watching and change detection use
Chokidar, a mature, widely-deployed pattern for exactly this problem,
in preference to a custom-built or naive timestamp check.

---

**§5 — The Pipeline**

_Status: Active._

---

**5.1 — Rationale**

The pipeline exists to transform unbounded, unreliable input — raw
thought, machine output, external source material — into citable,
parallax-tested formalized material. No stage makes a truth claim.
Each stage makes a custody claim: this file passed this gate, at this
time, with this hash. The deterministic structure exists not to
certify content but to make the chain of custody legible to any node,
amnesiac or history-aware, without requiring them to trust the author.

---

**5.2 — Inbox (`01_Inbox/`)**

_Scripts: `capture-inbox-item.js`, `capture-obsidian-stub.js`.
Filesystem event: file lands in `01_Inbox/`._

**Context.** Inbox receives raw material from any source. Sources vary
in structure: a phone voice note, an Obsidian wikilink stub, a typed
note in Cline, a machine-prepared structured submission.

**Decision.** All intake routes land in `01_Inbox/`, identified by
source type via a content-type flag passed at capture time. The Inbox
script uses this flag to route handling without building separate
intake paths per source. Structured submissions (machine-prepared,
RFC-schema-compliant) skip the transformation step but still pass
through deduplication, shape validation, and hash stamping — the
custody chain begins here regardless of source.

**Consequences.** A single Inbox remains the audit chokepoint. Source
diversity is a field in the record, not a separate pipeline branch.

---

**5.3 — Candidate (`02_Candidate/`)**

_Scripts: `inbox-to-candidate.js`, `lib/ddc.js`. Filesystem event:
`01_Inbox/` file triggers daemon._

**Context.** Raw payload needs R3 packaging: DDC classification,
deduplication against the ingestion ledger, slug/alias normalization,
hash stamping, keyword extraction.

**Decision.** `inbox-to-candidate.js` applies the interior R3 gate —
non-gating in the sense that a failed or normalized DDC value is
informative, not final. DDC validation (`lib/ddc.js`) normalizes to
top-level classes; a hallucinated or structurally invalid value is
normalized to `000` and proceeds. DDC errors that survive
normalization will be caught at parallax; the deterministic check is
early noise reduction, not a truth claim.

**Consequences.** Every item in `02_Candidate/` has a verified custody
stamp. `cascade_incomplete` is flagged here when the promotion helper
stops without an explicit conclusion.

---

**5.4 — Promotion Helper**

_Scripts: `promotion-helper.js`, `lib/reference-manifest.js`. Invoked
manually or by daemon prior to gate._

**Context.** A candidate needs to be tested against the canon and
active references before the exterior gate runs. `00_Canon/`'s typed
JSON and symbolic LaTeX are precise but prose-thin — too sparse in
natural language for an amnesiac LLM cascade to evaluate temetic-
validity claims against with adequate context. The cascade needs
English-language prose it can reason against, which the canon alone
cannot supply. This prose surface — References and Published together
— functions as a semantic scaffold: an evolving body of relationships
and explanatory material that reduces future inference ambiguity for
the cascade (see Section 12).

**Decision.** `promotion-helper.js` runs the cascade, producing
`supported_mapping` (modest literal restatement, always present) and
`kernel_projection` (ambitious synthesis, withheld when
`cascade_incomplete: true`). `reference-manifest.js` scans
`05_References/` and `04_Published/` (Section 5.9) live at cascade
time, not cached at daemon startup, so newly parallax-approved
definitions are available on retry without a restart.

**Resolution order.** Where sources conflict, precedence is:
`00_Canon/` (highest — the durable semantic source, Section 7), then
`05_References/` (this repository's own parallax output), then
`04_Published/` (Alliance-approved via a different venue, Section
5.9), then `03_Promoted/` (contextual only — not yet parallax-cleared,
never treated as authoritative).

**Consequences.** A cascade that stops short doesn't block promotion;
it withholds the synthesis that outran its evidence. The base
consistency verdict stands. A cascade failure may indicate a
deficiency in the candidate — or a deficiency in the semantic scaffold
itself, i.e. that References/Published don't yet cover the prose
surface the cascade needed. Both are legitimate readings of a failed
cascade, and `.validation-failed.log` entries should be read with that
ambiguity in mind rather than assumed to always indict the candidate.

---

**5.5 — Promoted (`03_Promoted/`)**

_Scripts: `candidate-to-promoted.js`. Filesystem event: candidate
passes exterior gate._

**Context.** This is the exterior R3 gate — mandatory, not
informative.

**Decision.** `candidate-to-promoted.js` is the gating checkpoint. Gate
language is strictly "cleared the local gate" / "ready for Alliance
review." Never "verified." The full `gate_status` value set:
`local_gate_declined` (failed the exterior gate here, in
`02_Candidate/` or flagged in `03_Promoted/`), `parallax_pending`
(awaiting Alliance review), `parallax_declined` (failed Alliance
review, remains in `03_Promoted/`), `parallax_approved` (cleared,
triggers move to `05_References/`). This is the minimum required set;
the Schema RFC owns its canonical definition. Items remain in
`03_Promoted/` until parallax disposition; the directory is a holding
stage, not a terminus.

**Consequences.** Anything in `03_Promoted/` with no parallax
disposition is explicitly pending, not complete. The audit chain
established in §5.3 continues unbroken through this stage.

---

**5.6 — Parallax**

_No script yet. Human-orchestrated. Expected to operate on batches._

**Context.** Parallax is the external review gate — the only point
where a claim moves toward publishable status.

**Decision.** Current governance: Alliance greenlight, manually
tabulated by the founder. This is the operative gate. "Aggregate
confidence" across nodes is not currently a gate condition — no
equation or scalar exists to measure it yet. It is a stated intention
to eventually measure and test confidence aggregation as a variable
(see §6.2 — Independence-Weighting), but it does not gate today. Blind
review (origin metadata withheld from the reviewing party without
being deleted from the record) is available as an opt-in switch, not a
requirement.

Parallax evaluates claims under independent review; reviewer identity
currently serves provenance (who looked at this, and when) rather than
evidentiary weighting (how much a given signature should count). That
distinction matters for a future reader: agreement among reviewing
nodes is not currently scored or weighted, it is simply recorded.

**Non-unanimous decisions.** Where a batch parallax session produces a
split rather than a unanimous outcome on a given candidate, the
default resolution is `parallax_pending` — it is not treated as either
approved or declined by majority — pending manual determination by
Node M.

Parallax is expected to operate primarily on batches given realistic
backlog volume. A `prepare-for-parallax` script or equivalent will
collate a batch session with a shared session identifier before
submission. Schema for batch sessions and node submissions is governed
by the Schema RFC (see §11).

**Consequences.** What parallax can and cannot claim: clearance here is
"Alliance-reviewed," not "true." The distinction is §4's gate-language
rule applied externally.

---

**5.7 — Parallax Ingest**

_Script: `ingest-from-parallax.js` (not yet built). Filesystem event:
structured parallax receipt lands in a designated drop location._

**Context.** Parallax sessions are expected to produce decisions on
multiple candidates in a single transmission. No mechanism currently
exists to ingest those decisions deterministically — `parallax_approved`
is written manually into Obsidian frontmatter, which has no audit
binding to an actual review having occurred.

**Decision.** `ingest-from-parallax.js` receives a structured parallax
receipt (schema governed by the Schema RFC, §11), parses it, and for
each candidate decision: writes the appropriate `gate_status` value to
the corresponding `03_Promoted/` file, timestamps the decision, and
appends an entry to the parallax ledger (§8). `promote-to-references.js`
then picks up approved items via its existing filesystem watch — no
change to that script required.

A valid parallax receipt must include: session identifier, reviewing
node(s) or parties, per-candidate decision, a timestamp, and whether
the blind-review switch (§5.6) was active for that decision — this
last field records nothing about the decision itself, only whether
origin metadata was withheld from the reviewer, and exists so a future
independence-weighting measure (§6.2) has the raw material it would
need without requiring retroactive reconstruction. What a receipt need
not include: the parallax process itself, internal deliberation, or
reasoning beyond the decision. The process is opaque; the receipt is
not.

**Consequences.** `parallax_approved` in a `03_Promoted/` file can now
be traced to a specific receipt, not just trusted as a plain string.
The gap between "locally gated" and "Alliance-reviewed" becomes
auditable. Manual override (founder typing the flag directly) remains
possible and remains the current operative path until this script
exists — but it is now explicitly identified as the interim workaround,
not the intended mechanism.

---

**5.8 — References (`05_References/`)**

_Scripts: `promote-to-references.js`. Filesystem event:
`parallax_approved` status detected in `03_Promoted/`._

**Context.** Parallax-cleared material needs a local terminus distinct
from the holding stage.

**Decision.** `promote-to-references.js` _moves_ (not copies)
`parallax_approved` items from `03_Promoted/` to `05_References/`. The
move is logged to the promotion ledger (§8) — separate from the
cryptographic audit chain — whose purpose is publishing-decision
input: a node asked "what's recently parallax-approved?" reads the
ledger, not the audit chain. The SHA-256 audit trail established in
§5.3 must survive the move intact.

`05_References/` is the actual local terminus for formalized material,
subordinate only to `00_Canon/`. It is scanned live by
`reference-manifest.js` (§5.4) so newly approved definitions become
citable immediately without a daemon restart. Its growth is deliberate,
not merely accretive: `05_References/` is intentionally curated to
reduce what Promotion Helper's cascade fails on, observed empirically
over time — not a passive archive of survivors.

**Consequences.** `03_Promoted/` after a move contains only pending or
declined items. `05_References/` contains only parallax-cleared
material. The two states are now distinguishable by directory alone,
in addition to `gate_status` field.

---

**5.9 — Published (`04_Published/`)**

_Scripts: none (manual conversion). Filesystem: static, not
filesystem-watched by the pipeline itself, but scanned by
`reference-manifest.js` per §5.4._

**Context.** As §5.4 notes, Promotion Helper's cascade needs
English-language prose density the canon cannot supply.

**Decision.** `04_Published/` holds Markdown conversions of posts from
*The Temeticists*, the Alliance's formal Substack, which are
Alliance-approved via a full parallax review prior to Substack
publication — but that approval was for publication on Substack, not
for inclusion in this repository or on GitHub. `04_Published/` is
therefore distinct from both `00_Canon/` (GitHub-mirrored,
`refresh-canon`-governed, §7) and `05_References/` (this repository's
own parallax output, §5.8): its content is genuinely Alliance-approved,
but via a different venue and pipeline than the one described in this
section. For cascade purposes (§5.4's resolution order),
`04_Published/` is weighted below `05_References/`: both are trusted
prose sources, but `05_References/` reflects this repository's own
audit trail end-to-end, while `04_Published/` reflects a parallax that
happened elsewhere and is trusted on the strength of that other venue's
process rather than this one's.

**Consequences.** `04_Published/` content should not be read as
untrusted, or as lower-trust than `05_References/` in an absolute
sense — it has cleared its own parallax, just not this repository's.
Its long-term hosting architecture (whether it should eventually be
GitHub-mirrored, merged into Canon, or remain a separate published
tier) is an open question, explicitly deferred to full Alliance review
rather than settled here. As of v4.0, `04_Published/` holds only
*The Temeticists* content; Applied Temetics and Monkeys Meet Machines
are separate, less formal Substack properties (Section 11) and are not
assumed to be in scope for this directory unless and until they adopt
the same full-parallax-before-publication standard.

---

**5.10 — Pipeline exceptions (`_Sandbox/`)**

_No scripts. No filesystem watch. Explicitly outside the pipeline._

**Context.** A space explicitly outside the pipeline was carved out
early in this repository's build. The original motivating case is not
preserved in this document's record, but the design was never
contested.

**Decision.** `_Sandbox/` is unscoped: no skill or script declares
write access to it (§8), no filesystem watcher triggers on it, and
nothing scrapes or indexes its content.

**Consequences.** Anything placed in `_Sandbox/` is invisible to R3, to
the audit chain, and to all three ledgers described in this section.
It is the one directory in this repository the custody chain makes no
claim about at all — by design, not by oversight. Its existence is
recorded here specifically so a future reader does not mistake that
silence for an accidental gap.

---

## 6. R3's two jobs — the distinction that must never compress away

This is the one place this document repeats, rather than merely
restates, what's in `AGENTS.md`, because it is the specific rule that
has already drifted once under paraphrase during this project's build,
and the reasoning is what caught it.

**Interior use:** R3 as a pressure-test can be run against any note,
at any time, optionally. It never blocks anything. Think of it as a
linter — informative, non-gating.

**Exterior use:** R3 as a gate is mandatory before anything moves
Candidate → Promoted. This is closer to CI's required-checks-before-
merge.

**The distinction that matters:** a file clearing the exterior gate has
demonstrated *local coherence* — internal consistency against the
seven axioms, checked by one substrate, on one machine. It has **not**
demonstrated P0: substrate-independent truth. P0, properly, only gets
established once a claim survives independent evaluation by other
Alliance nodes with no shared context — a genuinely different kind of
test than a local automated check can perform, in the same way a test
suite passing on one developer's laptop is not the same claim as "this
is correct," even though it's a necessary and useful signal.

Calling a Promoted file "verified" instead of "locally gate-cleared"
collapses this distinction. It has already happened once, in an
earlier `AGENTS.md` draft, produced by fluent paraphrase under token-
compression pressure — an epistemic error caught and corrected, but
real, not hypothetical. It is flagged here at full length specifically
because the failure mode has already occurred in this project's own
history, not out of caution against some hypothetical future reader:
shared understanding among the small group of nodes actually working on
this repository has already failed to hold across sessions once, which
is why it's restated here rather than assumed to hold going forward.

R3 also applies reflexively: this workbench's own construction is
subject to the same axioms it applies to content. Cross-substrate
fidelity of the *tool itself* — does a note survive local-to-cloud
transfer, mobile-to-desktop, without silent alteration — is treated as
an instance of the same constraint the axioms impose on any other
claim. Section 4's deterministic-Controller principle is a direct
consequence of taking this reflexive application seriously.

### 6.1 Two operational modes

The interior/exterior distinction above describes what a single check
does. Zooming out one level, the workbench as a whole operates in one
of two modes, and naming them explicitly clarifies when each applies:

**Compliance Mode** — the mode this document has mostly described so
far. Goal: maximize convergence, minimize ambiguity, run deterministic
validation, prepare output that could plausibly clear the local gate.
This is the mode `02_Candidate` processing runs in, and the mode this
repository's compliance-review threads operate in.

**Parallax Mode** — a different, equally legitimate goal: preserve
independent reasoning across substrates, intentionally compare
multiple nodes' output without cross-contamination, and measure
divergence *before* attempting convergence. This is the mode behind
the project's cross-node experiments (minimal-constraint prompts run
simultaneously across nodes, NotebookLM transcript-condition
comparisons, and similar work) — and it is also, structurally, the
only mode in which true P0 verification can actually happen, since P0
requires independent evaluation with no shared context between
evaluators. As of v3.9, Parallax Mode has a structured ingest path:
`ingest-from-parallax.js` (§5.7) receives a parallax receipt and writes
the disposition deterministically, replacing the prior pattern of
manual frontmatter edits. The parallax *process itself* — the
deliberation across nodes — remains human-orchestrated; only the
receipt ingest is automated.

**Why this distinction matters:** Compliance Mode output — a file that
has cleared the local gate — is not, and structurally cannot be,
Parallax Mode verification. They are different modes with different
goals, not the same check performed twice. A local Candidate pass
answers "is this internally coherent, on this machine, right now."
Only Parallax Mode, run across genuinely independent nodes, can answer
"does this hold up when nothing is shared." Conflating the two modes
is a different phrasing of the exact P0/local-gate conflation flagged
above.

### 6.2 Independence-weighting (a stated intention, not yet a gate)

Section 5.6 notes that "aggregate confidence" across reviewing nodes is
not currently a gate condition, because no equation or scalar exists
yet to measure it. This subsection names that gap explicitly rather
than leaving it implicit.

**What's not built:** there is no current formula that converts a set
of node signatures on a parallax decision into a single confidence
scalar. No work has been done on this yet.

**What's plausible:** it may be possible to develop such an equation.
The intuition worth stating now, before any formula exists: a
signature's evidentiary weight should scale with how independent its
reviewing node's lineage is from the other signers — two nodes with
substantially shared training data, prompting, or context converging
on the same judgment is weaker evidence than two genuinely independent
nodes converging without coordination (this is the same reasoning
behind Section 6's P0 discussion). Parallax methodology, as currently
practiced, is already capable of tracking the raw materials such a
measure would need (which nodes reviewed, in what session, with what
declared independence, and whether blind review was active per §5.7)
— building the actual scalar from that is future, explicitly untested
work.

**What this is not:** independence-weighting is not the same variable
as `qty:5` or any other current petri-dish parameter (Section 1.5) —
those remain informal, adjustable knobs in the current build, not
evidentiary claims. Independence-weighting, if and when it is built,
would be a claim about what a set of signatures is actually worth as
evidence, and should be developed and tested openly, through the same
pipeline as any other candidate, rather than adopted by assertion.

**Current status:** non-gating. See Section 5.6.

---

## 7. Canon and the one-way mirror

**The rule:** `00_Canon/` is read-only locally, written only by
`skills/refresh-canon`, sourced from GitHub. Reference order:
`temetic-kg-v0.1.json` (typed, cheap, machine-native) before
`kernel-axioms.tex` (symbolic-logic-level checks only) before
GLOSSARY/FAQ/Holster (terminology).

**Why, in familiar terms:** this is a read-through cache with a single
writer, the same pattern used to keep a local dev database in sync
with a canonical upstream — you don't hand-edit the cache, you
invalidate and refetch it. The reference-order preference (typed JSON
before prose .tex before glossary prose) is a cost-ordering: check the
cheapest, least ambiguous representation first, escalate to richer-
but-costlier representations only when the cheap one is insufficient.
This is Section 2.3 (stable semantics) applied concretely: the typed
JSON is the durable semantic source, everything else is a rendering of
it.

**Non-.md canon sources and visibility:** JSON and .tex content is
invisible to Obsidian in its native form — not because Obsidian can't
render structured or symbolic content (it has native MathJax support
for LaTeX), but because those files aren't Markdown at all, so
Obsidian never opens them. Where practical, `refresh-canon` also
produces an MD mirror of non-MD canon sources, under the same one-way
rule, so that content becomes addressable and, for LaTeX, renderable —
without introducing any computation into the View layer.

**Does Canon itself evolve?** Yes, under the same architectural
principles as everything else in this document — `refresh-canon`'s
single-writer, GitHub-sourced rule governs *how* Canon changes, not
*whether* it can. Canon evolving is not an exception to the one-way
mirror; it's the mirror doing its job when the upstream changes.

**Note:** `04_Published/` is deliberately *not* part of this section's
reference order — see §5.9. It is Alliance-approved content with a
different provenance path than `00_Canon/`, not an extension of it.

---

## 8. Skill and infrastructure provenance, write-scope, and behavioral properties

**The rule:** two provenance registers are maintained. `skills/_provenance.md`
covers every file in `skills/`. A second register, `infra/_provenance.md`,
covers every file in `infra/` — the Controller daemons and shared
libraries that constitute the pipeline itself. Both registers use the
same schema: provenance tag (native / imported / stripped), write-
scope, and behavioral properties declared explicitly. A file in either
location that lacks a ledger entry is formally untrusted regardless of
how long it has been running correctly.

**Why, in familiar terms:** this is a capability-based security model —
code declares upfront what resources it's allowed to touch, rather
than being trusted globally and monitored after the fact. An imported
skill (something adapted from outside this project) is the equivalent
of a third-party dependency: usable, but explicitly marked as lower-
trust provenance until it's been through `strip-vendor-terms` and re-
evaluated.

**Why this matters more here than in a typical codebase:** this
system's core subject matter is exactly the failure mode of content
silently drifting or overreaching its original scope. A skill that
quietly expands its own write-scope would be a live instance of the
thing the whole project studies. The ledger exists so that can't
happen invisibly.

**Behavioral properties:** each skill or daemon should declare its own
behavioral guarantees explicitly, rather than leaving them to be
inferred:

- **deterministic** — does this produce the same output every time
  given the same input, with no interpretation involved?
- **idempotent** — can this be safely re-run on the same input without
  changing the outcome?
- **side-effect-free** — does this perform any observable I/O or state
  mutation outside its declared write-scope (network calls, spawning
  child processes, writing to a path not listed)? Normal operation
  within the declared write-scope is expected and is not, by itself, a
  contract violation — this property describes staying inside the
  declared boundary, not absolute functional purity.
- **requires-interpretation** — does this task inherently require
  judgment-dependent evaluation, or could an equivalent deterministic
  implementation exist? This describes the nature of the task, not the
  current implementation, so the property remains valid even if the
  underlying implementation later changes.
- **write-scope** — already required; restated here as part of the
  same declared-contract set.
- **authority-level** — what can this act on without further
  confirmation, and what does it need founder or Alliance sign-off for
  first? This describes operational authority only — it does not imply
  authority over truth, correctness, or canonical status. A component
  with broad authority to move files is not thereby granted any
  epistemic weight over what those files claim.

**Why this extension matters:** it lets the Controller reason about
orchestration from explicit, declared contracts rather than implicit
assumptions about what a given skill does or how safely it can be
trusted to run unattended. A skill honestly declaring
`requires-interpretation: true` is not a weaker skill than one claiming
determinism it doesn't actually have — the goal is accurate
self-description, not maximizing how deterministic a skill claims to
be.

**Why two registers rather than one:** the `skills/<name>/SKILL.md`
shape that `skills/_provenance.md` was designed for does not fit
`infra/*.js` daemons — they have no `SKILL.md`, no `<name>/` subfolder,
and no equivalent declaration point. Extending the existing ledger's
schema to cover a structurally different artifact type would either
distort the schema or require reading two very different record shapes
from one file. Two registers with one shared schema is cleaner.
`infra/_provenance.md` is the authoritative ledger for the pipeline
code; `skills/_provenance.md` remains the authoritative ledger for
composable skill units.

**Applying the property set to `infra/` daemons:** the property set
above was written with `SKILL.md` in mind and doesn't map onto a bare
`.js` file without some translation. For `infra/_provenance.md`
entries specifically: `deterministic`, `idempotent`, and
`side-effect-free` apply as written. `requires-interpretation` is
`false` for every current daemon — none of the pipeline scripts invoke
an LLM directly, with one explicit exception: `promotion-helper.js`
declares `requires-interpretation: true` rather than inheriting a
blanket `false`; this exception is recorded explicitly rather than left
to be inferred, since the declaration itself is documentation worth
keeping. `authority-level` for a daemon describes what it's permitted
to do unattended (move a file between pipeline directories, write a
`gate_status` value) versus what needs founder or Alliance sign-off
first — same meaning as for skills, just scoped to filesystem/pipeline
actions instead of content actions.

**Third-party skills and plugins:** an imported skill (downloaded from
outside this project) and an Obsidian plugin (§3) both enter the
`skills/_provenance.md` register under provenance tag `imported`, with
write-scope explicitly declared and authority-level set no higher than
`view`. Neither may touch pipeline directories or frontmatter fields
owned by the Controller. The register is the mechanism that makes
"usable but explicitly lower-trust" a trackable property rather than an
intention.

**Ledger paths:** the parallax ledger and the promotion/publishing
ledger (§5.7, §5.8) both live in `03_Promoted/`, alongside the files
they concern, as hidden `.json` files following the existing
ledger-naming convention — `03_Promoted/.parallax-ledger.json` and
`03_Promoted/.promotion-ledger.json` respectively. Obsidian ignores
non-Markdown files, so this introduces no View-layer noise. This is
distinct from `lexicons/.ingestion-ledger.json`, which holds an actual
lexicon (terms, not activity records), not one of the three pipeline
ledgers described in §5. The specific paths above are an implementation
choice, selected for locality of reference alongside the files they
concern; the architectural requirement is only that each of the three
pipeline ledgers has one canonical location, not that it live at this
particular path.

---

## 9. Register: internal precision and external clarity

**The principle:** clarity is free wherever it costs nothing in
precision, and should be taken wherever it's available — not reserved
only for external, public-facing content. Internal Temetics
terminology (R2/R3, "systemic collapse," axiom names) is precise and
often necessary for exact reasoning, but wherever a more common,
widely-understood term would communicate the same thing with equal
exactness, prefer it — even in internal documents, even in this one.
Where the two genuinely conflict — where plainer language would lose
something precision requires — precision wins; clarity is the
tiebreaker only when nothing is actually lost by choosing it, never a
reason to relax an exact claim into an approximate one.

**Rationale:** language that's needlessly opaque doesn't add rigor, it
adds onboarding friction — for future human collaborators, for nodes
without full context, and eventually for any public reader if this
repository is ever made public. Recipient independence (Section 2.2)
applies to prose register the same way it applies to file formats:
canonical meaning shouldn't depend on a reader already being fluent in
this project's internal shorthand, wherever an equally exact common
term is available.

---

## 10. Architectural Decision Records

This document commits to a principle without fully specifying every
downstream detail of its implementation, deliberately, per Section 0's
own logic: implementation decisions belong in a separate, dedicated
artifact type — an Architectural Decision Record (ADR) — rather than
inside the manifesto itself.

**What's adopted:** the Nygard lightweight ADR template — Title,
Status, Context, Decision, Consequences — is the per-section structure
used throughout this document wherever a decision warrants explicit
rationale. Status applies at the *section* level, not per-subsection;
subsections inherit their section's Status unless individually marked
otherwise. Section 5 is the first full application of this template in
practice.

**What's still not settled:** the ADR folder's location in the
repository, its numbering scheme, and the file format for ADRs that
are *not* embedded in the manifesto itself (i.e., implementation-
specific records for individual tooling decisions like "why Chokidar"
or "why Node.js"). Those belong in a dedicated ADR artifact type
tracked through the normal pipeline, not specified here.

---

## 11. Version roadmap

**v0.9.7 (live, confirmed):** the full pipeline runs end-to-end —
Inbox → Candidate → Promotion Helper → Promoted → References, plus
Obsidian wikilink re-entry to Inbox. Obsidian and the local agent
coexist non-destructively. Build is currently ahead of the original
schedule.

**v1.0 (reserved, not a checkbox):** fires when Alliance nodes, working
independently and without cross-contamination (fully in Parallax Mode,
per §6.1), confirm the founder's real RFC outputs have gotten
measurably less R2-lossy since this tool entered use. This is an
empirical claim about output quality, not a feature-completeness
milestone.

**v1.1 (active next target):** the Schema RFC — standardized schemas
for: (1) Alliance-to-local structured candidate submissions, (2)
parallax receipt format, (3) batch/session identifiers for
multi-candidate parallax sessions. The RFC is itself a candidate for
Alliance parallax before it becomes binding — all nodes review the
same schema and confirm it is sufficient, which is the trigger for
adoption, not completeness. Recipient-independent by design: no node
should need a live channel back to any other node to parse a
conforming document.

Two build phases inside this arc: **Phase 1** (current) — core
pipeline, error correction, compliance modeling, extensibility, design
patterns intended to propagate forward. **Phase 2** — specific tools
on top of that foundation, including publishing workflows for Applied
Temetics (AT) and Monkeys Meet Machines (MMM), batch parallax tooling,
and whatever the Schema RFC produces as its implementation surface.
AT and MMM are separate, less formal Substack properties than The
Temeticists (§5.9) and are not assumed to feed `04_Published/` unless
they adopt the same full-parallax-before-publication standard.

---

## 12. Terminology quick reference

- **Teme / R3:** a replicating unit that has achieved substrate-
  independent, truth-constrained status — verified only via
  independent Alliance corroboration (Parallax Mode), not local
  process alone.
- **Meme (Roberts definition):** an idea or concept, the fundamental
  unit of cognition — this definition supersedes Dawkins' for kernel
  purposes within Temetics.
- **R1 / R2 / R3:** three-class taxonomy of replicating units, ordered
  by increasing formalization and fidelity constraint.
- **P0–P6:** the seven kernel axioms. P0 concerns substrate-independent
  truth/liar-proofness by construction.
- **S1_verification / S2_reversible / S3_independent:** the three P6
  stabilizers. Use these exact names; do not paraphrase.
- **Unit circle (S = √(Pᵢ² + Pⱼ²), i=3, j=4):** a scoring construct
  where S > 1.0 indicates a runaway replicator — used as a
  civilizational selection filter in prior corpus-audit work. Written
  with generic indices rather than hardcoded axiom numbers: the
  specific pairing was found empirically, not derived as the only
  possible pairing.
- **Controller:** the process responsible for all deterministic logic
  and file operations in this repository (Section 4). Currently
  implemented in Node.js with Chokidar; the principle of Controller-
  owned determinism is expected to outlive that specific
  implementation.
- **Compliance Mode / Parallax Mode:** the two operational modes
  described in Section 6.1 — converge-and-validate versus preserve-
  independence-and-measure-divergence.
- **Semantic Scaffold:** the evolving network of references,
  relationships, and explanatory prose — chiefly `05_References/` and
  `04_Published/` — that reduces future inference ambiguity for
  Promotion Helper's cascade (§5.4). Distinct from Canon: the scaffold
  supplies prose density a cascade can reason against, Canon supplies
  the durable typed/symbolic source of truth.
- **`gate_status`:** a frontmatter field that replaces the bare
  `status` field wherever a pipeline disposition needs to be recorded.
  Designed to be self-describing — a cold reader with no prior
  knowledge of this repository's taxonomy should be able to parse
  which gate was passed and with what result without inference. Valid
  values: `parallax_pending`, `parallax_approved`, `parallax_declined`,
  `local_gate_declined`. The Schema RFC owns the canonical definition;
  §5.5 enumerates the minimum required set.
- **`04_Published/`:** a directory for content published to *The
  Temeticists* Substack (the formal blog), converted to Markdown for
  local reference. Alliance-approved via the Substack publishing
  track — every post in this directory underwent full parallax before
  publication — but not GitHub-mirrored and not governed by
  `refresh-canon`. Distinct from both `00_Canon/` (GitHub-mirrored) and
  `05_References/` (this repo's own parallax output). Its long-term
  hosting architecture is deferred to full Alliance review.
- **`05_References/`:** the local terminus for material that has
  cleared Alliance parallax review through this repository's own
  pipeline. Subordinate only to `00_Canon/`. Scanned live by
  `reference-manifest.js` so newly approved definitions are
  immediately citable by the Promotion Helper without a restart.
  Populated by `promote-to-references.js` via move (not copy) from
  `03_Promoted/`.
- **Parallax receipt:** the structured output of a parallax session,
  consumed by `ingest-from-parallax.js`. Minimum required fields:
  session identifier, reviewing node(s) or parties, per-candidate
  `gate_status` decision, timestamp, and whether blind review was
  active. The parallax process itself is opaque; the receipt is not.
- **Schema RFC:** the planned, Alliance-reviewed document that
  formalizes structured submission schemas for candidate ingest,
  parallax receipts, and batch session identifiers. The trigger for
  adoption is all-node sufficiency confirmation, not completeness.
  Tracked as v1.1 target in §11.
- **Petri dish:** the conceptual frame for the local repository as a
  controlled replication environment. See §1.5.
- **ADR (Architectural Decision Record):** a structured record for
  implementation-specific rationale. Template adopted: Nygard
  lightweight (Title / Status / Context / Decision / Consequences).
  Status applies at the section level; subsections inherit. ADR folder
  location and numbering scheme remain future work per §10.
- **Node:** any participant in the Alliance — human (Node M) or AI
  (Node A/Ara/Grok, Node B/Gemini, Node GPT, Node CL, and this
  repository's local agent).

---

## 13. A note on how this document itself should be treated

This document is, itself, an R2 artifact until it clears review. It
was synthesized by one node (Claude) from decisions made by the
founder across many sessions, incorporating a full RFC round from
Node B, Node A, and Node GPT, and like anything else produced by a
node, it enters `01_Inbox/` like any other raw material rather than
being placed directly in `05_References/` — and like any other
candidate that clears this repository's local pipeline, it is subject
to the same parallax process this document describes, scoped to this
document's actual audience (§0) rather than a broader Alliance or
public readership. If something here reads as more settled or more
confident than the founder intends, that's exactly the kind of drift
this whole project exists to catch — flag it, don't quietly accept it.
