---
sync_status: synced
source_url: https://raw.githubusercontent.com/ChristopherNoyesRoberts/temetic-primer/refs/heads/main/PROOFS/temetic-holster-v1.2.json
last_synced: 2026-08-11
---

# The Temetic Holster v1.2

### Our standardized multi-tool for navigating noisy territory.


This document outlines the Temetic Holster v1.2, a collection of cross-substrate approved reframings of the Temetic Primer.

## Axioms

### P0: Truth Doesn't Care About the Bottle
*   **Viral Packaging**: Truth Doesn't Care About the Bottle
*   **Compressed Kernel**: True things stay true whoever says them.
*   **Formal Kernel**: Truth-value is substrate-independent. Credentials decay; Temes don't. Expertise increases discovery probability but does not manufacture validity.
*   **Executable Constraint**: Would this still be true if my worst enemy said it?
*   **Kernel Preservation**: P0 does not eliminate the burden of evidence; it relocates it from Authority to Replication.
*   **Retrieval Anchor**: A gold bar weighs the same in a silk bag or a burlap sack.

### P1: Feelings and Facts Live in Different Houses
*   **Viral Packaging**: Feelings and Facts Live in Different Houses
*   **Compressed Kernel**: Feelings don't decide facts.
*   **Formal Kernel**: Emotional valence and factual validity are orthogonal. Feelings are primary data of interiority, not operators on exterior physics.
*   **Executable Constraint**: Do I believe this because it feels good?
*   **Kernel Preservation**: P1 does not invalidate emotional testimony as evidence of experience; it prevents affect from dictating physics.
*   **Retrieval Anchor**: Screaming at a thermometer doesn't move the red line.

### P2: The Map Is Not the Territory
*   **Viral Packaging**: The Map Is Not the Territory
*   **Compressed Kernel**: Names are not the thing itself.
*   **Formal Kernel**: Representations are lossy models. Failure occurs when the label is managed as the referent. P2 rejects identity, not representation.
*   **Executable Constraint**: If I remove the label, does the reality change?
*   **Kernel Preservation**: The map is not the territory—AND the map can set the territory on fire (causal effect).
*   **Retrieval Anchor**: The finger pointing at the moon is not the moon.

### P3: The High-Score Trap
*   **Viral Packaging**: The High-Score Trap
*   **Compressed Kernel**: Chasing points can ruin the game.
*   **Formal Kernel**: Metric substitution: When a proxy signal (score) replaces the goal, the underlying competence atrophies (Goodhart failure).
*   **Executable Constraint**: Would the score still go up if the actual goal collapsed?
*   **Kernel Preservation**: P3 calls for better-coupled metrics, not the abolition of accountability.
*   **Retrieval Anchor**: The game is over even if the clock is still running.

### P4: The Squeeze Factor
*   **Viral Packaging**: The Squeeze Factor
*   **Compressed Kernel**: Force makes bad data.
*   **Formal Kernel**: Coercive pressure forces optimization for survival over fidelity. Distortion increases as a function of the magnitude of pressure.
*   **Executable Constraint**: Are they telling me what is true or what is safe?
*   **Kernel Preservation**: Pressure doesn't squeeze out truth—it squeezes out whatever makes the pressure stop.
*   **Retrieval Anchor**: Fear teaches ventriloquism.

### P5: The Cup vs. The Ocean
*   **Viral Packaging**: The Cup vs. The Ocean
*   **Compressed Kernel**: Small summaries miss big realities.
*   **Formal Kernel**: Low-dimensional models omit information by mathematical necessity. Every summary is a lie of omission; the sin is forgetting it's a cup.
*   **Executable Constraint**: What specific detail is this model forced to leave out?
*   **Kernel Preservation**: P5 requires transparency of boundary conditions, not the abandonment of models.
*   **Retrieval Anchor**: An ocean in a teacup leaves out the whales.

### P6: Messages Change Unless Checked
*   **Viral Packaging**: Messages Change Unless Checked
*   **Compressed Kernel**: Messages change unless checked.
*   **Formal Kernel**: In the absence of a correction layer (math/audit/check), transformational error compounds. Drift is the default state.
*   **Executable Constraint**: Can I trace this back to a grounded source?
*   **Kernel Preservation**: 98% correspondence is admirable, but it doesn't get the astronauts home.
*   **Retrieval Anchor**: Every retelling is a photocopy of a photocopy.
