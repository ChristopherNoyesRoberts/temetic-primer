---
title: AGENTS.md
version: 0.9.9
status: production
format: hybrid — hard-spec blocks + minimal load-bearing prose
---

# AGENTS.md — Entry point for the local agent

Read completely before touching anything else in this repository.

You are referred to throughout, and refer to yourself, as **"the local
agent."** Never write a vendor/model name into any file in this
repository — frontmatter, prose, skill descriptions, this file. This
contract applies identically regardless of what you are running on.

This is the founder's (Node M's) personal workbench for the Temetics
project. It is local and R3-principled — R3 is defined in full in §4;
nothing before §4 depends on that definition.
NOT:
canonical source of truth
a clone of the GitHub repository
a source of P0-verified claims
Nothing produced here is canon until it clears the actual Alliance RFC
process. `00_Canon/` below defines what "canon" means here.

---

RULE — FILE FRESHNESS (no exceptions):
    every file reference is a disk read, never a memory recall
    once more than one turn has passed, prior contextual knowledge
    of a file's contents is assumed stale
    re-open and re-read from disk before acting on any previously-
    seen file, every time, including files read earlier in this
    same session

DEV SWITCH (comment out to disable during testing):
    file_freshness_enforced: true

---

## 1. Pipeline folders
CONFIG (rename here, nowhere else — every other reference resolves
through this table, not a hardcoded path):
00_Canon         = read-only canon mirror
01_Inbox         = raw capture, zero structure
02_Candidate     = formal restatement + gate, in progress
03_Promoted      = cleared local gate
04_To_Parallax   = outbound batch manifests awaiting Alliance review
                   (promoted-to-parallax.js writes here)
05_From_Parallax = inbound Alliance rfc_receipts (collate_parallax.js
                   reads here)
06_References    = local, parallax-approved working definitions —
                   cascade-citable via reference-manifest.js's dynamic
                   scan (infra/lib/reference-manifest.js), NOT the same
                   thing as 07_Published: may never go external, usable
                   locally regardless. See 06_References/README.md and
                   infra/promote-to-references.js.
07_Published     = actually pushed to Substack (external, real publication)

GATE_STATUS LIFECYCLE on a file past the interior stage (field:
`gate_status` — NOT `status`, which is reserved separately for
promotion-helper.js's own training/ready claim marker and carries no
gate-lifecycle meaning):
  local_gate_declined | parallax_pending | parallax_declined | parallax_approved

local_gate_declined = failed the exterior gate (candidate-to-
promoted.js). Stays in 02_Candidate/, tagged in place, never moved.
Never auto-removed — only a manual founder deletion removes it.

parallax_pending = cleared the exterior gate, awaiting Alliance
review. candidate-to-promoted.js MOVES (never copies) the file from
02_Candidate/ into 03_Promoted/ at this point — 02_Candidate/ keeps no
copy behind.

parallax_declined = failed Alliance review. Stays in 03_Promoted/,
tagged in place, never moved. Never auto-removed — same
manual-deletion-only rule as local_gate_declined.

parallax_approved = cleared Alliance review.
"parallax_declined" and "parallax_approved" are set by
collate_parallax.js, not by hand: it reads receipts landing in
05_From_Parallax/, validates each reviewing node against the
Alliance allowlist and the originating 04_To_Parallax/ manifest,
accumulates signatures toward quorum in the parallax ledger, and —
once quorum's machine-approval half is met — prompts the founder for
a manual sign-off (CLI y/N) before flipping gate_status. The
drag-into-four-tabs routine this section used to describe is
retired; this is that automation, already landed.
Reaching parallax_approved is what triggers
infra/promote-to-references.js to MOVE (never copy — 03_Promoted/
after this move contains only pending or declined items, never a
retained copy of an approved one) the file into 06_References/.

BLINDNESS TIERS — what promoted-to-parallax.js sends to Alliance review:
infra/promoted-to-parallax.js batches 03_Promoted/ items flagged
awaiting_parallax: true into a manifest written to 04_To_Parallax/.
Each item is field-gated by tier, not sent as raw frontmatter — live in
code, not just design (buildItemPayload() in promoted-to-parallax.js):

  Tier 0: candidate_id, raw_claim (as-authored, cascade-log-stripped
          only), founder_note
  Tier 1: + source, captured, extracted_tag, aliases, keywords, ddc,
          related_nodes
  Tier 2: + training_reference_docs, cascade_incomplete
  Tier 3: + full verification_receipt as one sealed unit — including
          proposed_axiom, moved here since it's derived from the same
          content as the rest of the receipt

founder_note is always included, at every tier. candidate_id is not a
stored field — it's derived from the 03_Promoted/ filename at
manifest-write time, deterministically.

PERMANENTLY EXCLUDED at every tier, no exceptions (not a graduated
Tier 2 restriction — an absolute ban, allow-list construction plus a
runtime assertNoBannedFields() check):
  gate_status | status | promoted_at | ingested_at |
  training_completed_at | awaiting_parallax | raw_content_sha256

founder_directive (optional, batch-level) is prompted for inline when
running promoted-to-parallax.js — a short statement of the batch's
overall intent, distinct from any single item's founder_note.

KNOWN GAP (flagged in the script itself, not silently papered over):
Tier 3 forwards verification_receipt exactly as it exists in the
candidate's frontmatter. If a candidate's receipt doesn't yet carry a
real proposed_axiom, this script won't fabricate one — that gap is
upstream, in candidate-to-promoted.js / the local gate, not here.

NEW CAPTURE PATH — vault-root Obsidian stubs (infra/capture-obsidian-
stub.js): clicking an empty [[WikiLink]] creates a new note at the
vault root (= this repo's root, confirmed via .obsidian/). The
controller watches the root (depth 0 only — never Obsidian sorting on
save, per §2's MVC boundary) and, once the stub has real content, moves
+renames it into 01_Inbox/ using the SAME naming convention as
capture-inbox-item.js, then leaves it to the existing pipeline
unchanged from there.
---

## 2. MVC boundary
MODEL + VIEW = Obsidian
CONTROLLER   = you, the local agent, in VS Code
PROHIBITED:
computational logic in Obsidian-side artifacts
(Templater scripts, Dataview queries, plugin state)
PERMITTED:
human editing directly in Obsidian
(mobile capture, view construction, ad hoc notes)
Obsidian native MathJax rendering of $  ...  $ / $   ...   $
(display only — not a boundary exception)

CONTEXT — not an additional rule, the PROHIBITED/PERMITTED lists above
are the complete spec:
The boundary is not "Obsidian may never be touched" — the founder
edits there directly and that's fine. The boundary is that
*computation* never lives there. A human typing prose is not a
violation. A query or script deriving something is.

All logic — distillation, round-trip check, axiom scan — lives in
plain files at the root or in `skills/`, readable by any agent on any
machine. That readability is this file's actual purpose.

---

## 3. Canon reference order
ORDER (cheapest correct answer first):

00_Canon/temetic-kg-v0.1.json   (typed, machine-native, default)
00_Canon/kernel-axioms.tex      (symbolic/proof-level only)
00_Canon/GLOSSARY.md, FAQ.md, Holster.md  (terminology reference)

WRITE ACCESS to 00_Canon/:
skills/refresh-canon ONLY. One-way mirror, GitHub -> here.
Never edited locally. Never pushed upstream.
P6 stabilizer names — use exactly, never paraphrase:
S1_verification | S2_reversible | S3_independent

CONTEXT — not an additional rule:
Non-.md canon sources (JSON, .tex) get MD mirror representations where
practical, generated by `refresh-canon` under the same one-way rule —
see that skill for current known-source mappings and conversion notes.
This makes symbolic/typed content addressable and, for .tex, renderable
via Obsidian's native MathJax — without introducing any View-layer
computation.

---

## 4. R3 — two jobs, never conflated
INTERIOR (optional): any note, any time, pressure-test against axioms.
Never blocks anything.
EXTERIOR (mandatory): 02_Candidate -> 03_Promoted requires the gate.
See Templates/candidate.md for the procedure.

RULE — GATE LANGUAGE (no exceptions):
    a file that cleared the Exterior gate has demonstrated local
    coherence only — checked on this machine, this session
    it is NOT a P0 claim
    permitted terms for a cleared file: "cleared the local gate" |
    "ready for Alliance review"
    forbidden terms for a cleared file: "verified" | "confirmed true"

CONTEXT — not an additional rule, explains why the rule above exists:
True substrate-independent P0 verification happens only once a
Promoted file reaches independent Alliance nodes. This distinction has
already been lost once in a prior draft of this file; the RULE block
above is restated in full for that reason — if you are ever tempted to
compress it further, don't.

R3 also applies reflexively to this workbench's own construction — its
own fidelity across substrates (local machine, cloud, mobile) is
itself an axiom-shaped constraint, not just a filter applied to
content passing through it. This is a standing design consideration,
not a current actionable rule.

---

## 5. Write-scope
RULE:
every skill declares provenance + write-scope in
skills/_provenance.md
a skill writing outside its declared scope: STOP, flag to founder
00_Canon/ writable by refresh-canon only
Autonomous unattended writes by background daemons and recurring tasks
are permitted inside a process's declared write scope, specifically
within:
01_Inbox/
02_Candidate/
PREFER:
new file over in-place rewrite
BEFORE any write that changes existing meaning (not just adds):
surface to founder first — do not silently overwrite
IF UNCERTAIN whether something is new content vs. prior raw injection:
default to 01_Inbox/

RULE — INBOX-FIRST (no exceptions):
    all new thinking enters through 01_Inbox/ first, including the
    founder's own and including a node's own theoretical suggestions
    never write new thinking directly into Candidate, Promoted, or
    any Canon file

CONTEXT — not a current rule, forward-looking only:
As cross-substrate content trading (e.g. lesson-plan exchange between
local and cloud sessions) comes online, the Inbox-first rule above
will apply to it too. Not yet in effect — no such path exists today.

_Sandbox/ — EXPLICIT EXCEPTION to the pipeline (not listed in §1's
CONFIG table on purpose — it is not a pipeline stage):
ephemeral, test-only bridging documents only
NOT gated, hashed, ledgered, or watched by any daemon
NOT subject to Inbox-first (above) or Reversibility snapshotting (§6)
freely writable/deletable by any node without founder sign-off first
if something written there turns out to matter, move it into
01_Inbox/ properly (via capture-inbox-item.js) — _Sandbox/ never
becomes canon or a candidate by just sitting there long enough

---

## 6. Reversibility
PRACTICE: snapshot/zip before any structural change.
CURRENT MECHANISM: manual, founder-driven. No automation in v0.9.x.
---

## 7. Skills

Full ledger: `skills/_provenance.md`. Every skill tagged `native`,
`imported`, or `stripped`. An imported skill is usable immediately but
should be run through `skills/strip-vendor-terms` and reprovenanced
before being treated as trusted long-term.
PROHIBITED: skill mechanism duplicated or paraphrased in this file.
This file states the rule; the skill's own SKILL.md
states the procedure. If they diverge, the SKILL.md
is stale — flag it, don't silently trust this file over it.
