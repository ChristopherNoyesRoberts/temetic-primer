# How to Submit a Parallax Receipt

**For: Node B, Node A, Node GPT (and Node CL, when reviewing outside this thread)**
**Purpose:** RFC-003 v2 defines the receipt schema in the abstract. This document is the concrete build spec — it describes exactly what `collate_parallax.js` reads, validates, and silently ignores, so a receipt actually counts toward quorum instead of getting rejected or, worse, accepted-but-inert.

---

## 1. File requirements

- **Extension**: `.yaml`, `.yml`, or `.json`. Anything else is invisible to the script — it won't even attempt to read it, no error, it just never appears in the run.
- **One file per node response.** Filename doesn't matter to the script (any name works), but something identifying like `node-b-v4.0-batch-20260807-103423-t0.yaml` helps Node M sort them by eye.
- **Format**: YAML is what the RFC examples use and what's expected in practice. JSON also works if that's easier to produce reliably.

## 2. Top-level structure — the `rfc_receipt` wrapper is REQUIRED

The whole document must be wrapped in a top-level `rfc_receipt` key. A bare `responses:` array at the document root, with no wrapper, will be rejected outright as "does not look like an RFC-003 rfc_receipt document."

```yaml
rfc_receipt:
  parallax_batch_id: <string>     # echo exactly as received
  reviewing_node: <string>        # your exact node_id — see §3
  timestamp: <ISO 8601 string>    # e.g. '2026-08-07T14:32:00Z'
  overall_verdict: <string>       # human-facing summary only — see §5, not machine-read

  responses:
    - candidate_id: <string>
      parallax_batch_id: <string>
      blindness_tier_evaluated: <integer>
      verdict: <string>
      reasoning: <string>
      deduced_axiom: <string>        # optional
      deduced_ddc: <string>          # optional
      proposed_amendment: <string>   # only if verdict is amend
```

## 3. `reviewing_node` must match the allowlist EXACTLY

Valid values, character-for-character: `Node M`, `Node B`, `Node A`, `Node CL`, `Node GPT`. Anything else — a nickname, different capitalization, "Gemini" instead of "Node B" — fails validation immediately and every item in that receipt gets rejected, none of it recorded. This is the first thing checked; get it right or nothing else in the file matters.

## 4. Per-item fields — what's checked, what's silent

**Checked, and rejection is loud (you'll see why in the log):**
- `candidate_id` must exist in the outbound manifest for the batch you're citing
- `parallax_batch_id` must correspond to a real file the Controller actually sent (`04_To_Parallax/<parallax_batch_id>.json`)
- `blindness_tier_evaluated` must exactly match the tier that batch was actually sent under — if the batch was sent at Tier 0 and you report `blindness_tier_evaluated: 1`, it's rejected as a mismatch, not silently corrected

**NOT checked — this is the important one:** `verdict` is never validated against an enum. It must be **exactly** `parallax_approved` or `amend` (lowercase, exact spelling) — there is no third value; `parallax_declined` is not a machine-returnable verdict under RFC-003 (see §6). If you send `Approved`, `APPROVE`, `approve`, or anything else that isn't one of those two exact strings, the receipt is still recorded in the ledger, but it counts toward **nothing** — not approval, not dissent. It just sits there, silently inert. There's no error message for this case. Double-check the string before sending.

## 5. `overall_verdict` — human-facing only

This field exists for Node M's own quick reading of a batch at a glance. The script never parses it programmatically. Include it (RFC-003 §2 has it as required), but know that getting it "wrong" relative to your per-item verdicts won't cause a script error — it just won't tell Node M what actually happened. Keep it accurate as a courtesy, not because anything depends on it mechanically.

## 6. Verdict semantics (recap from RFC-003 v2)

- `parallax_approved` — clears review, counts as one signature toward quorum
- `amend` — holds the gate. **A single amend from any allow-listed node blocks promotion regardless of how many other approvals exist.** This is intentional (P4), not something to route around. Include `reasoning` and, ideally, `proposed_amendment`.
- There is no `declined` option for you to send. If a claim genuinely doesn't work, `amend` with clear reasoning is the strongest available signal — the founder makes the final call on abandoning it entirely, outside this schema.

## 7. Quorum, for context (so you know what your vote is doing)

Promotion requires: **2 distinct allow-listed machine-node approvals** + **Node M's own sign-off** + **zero outstanding amends**. Your `parallax_approved` is necessary but not sufficient alone — it's one vote in a small, deliberately non-anonymous pool, not a majority-rules system.

---

### Quick checklist before sending
- [ ] File extension is `.yaml`, `.yml`, or `.json`
- [ ] Top-level `rfc_receipt:` wrapper present
- [ ] `reviewing_node` is exactly your allowlisted node_id
- [ ] Every `verdict` is exactly `parallax_approved` or `amend` — nothing else
- [ ] `candidate_id`, `parallax_batch_id`, `blindness_tier_evaluated` echoed exactly from what you received
